#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
# PulseBoard — One-command GCP deployment
# Usage: ./scripts/deploy-gcp.sh [--demo]
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

DEMO_MODE=false
for arg in "$@"; do
  [[ "$arg" == "--demo" ]] && DEMO_MODE=true
done

# ── Required env vars ──────────────────────────────────────────
: "${PROJECT_ID:?Set PROJECT_ID}"
: "${REGION:=asia-south1}"
: "${ENTRA_TENANT_ID:?Set ENTRA_TENANT_ID}"
: "${ENTRA_CLIENT_ID:?Set ENTRA_CLIENT_ID}"
: "${ENTRA_CLIENT_SECRET:?Set ENTRA_CLIENT_SECRET}"

REGISTRY="${REGION}-docker.pkg.dev/${PROJECT_ID}/pulseboard"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║         PulseBoard GCP Deployment Starting           ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  Project:  ${PROJECT_ID}"
echo "║  Region:   ${REGION}"
echo "║  Demo:     ${DEMO_MODE}"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ── 1. Set gcloud project ─────────────────────────────────────
echo "▸ Configuring gcloud..."
gcloud config set project "${PROJECT_ID}"

# ── 2. Enable APIs ────────────────────────────────────────────
echo "▸ Enabling required GCP APIs (this may take 2-3 minutes)..."
gcloud services enable \
  run.googleapis.com \
  sqladmin.googleapis.com \
  bigquery.googleapis.com \
  secretmanager.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  aiplatform.googleapis.com \
  cloudtasks.googleapis.com \
  storage.googleapis.com \
  compute.googleapis.com \
  redis.googleapis.com \
  vpcaccess.googleapis.com \
  servicenetworking.googleapis.com \
  --quiet

# ── 3. Terraform ──────────────────────────────────────────────
echo ""
echo "▸ Running Terraform (infrastructure provisioning)..."
cd infra/terraform
terraform init -input=false -upgrade

terraform apply -auto-approve \
  -var="project_id=${PROJECT_ID}" \
  -var="region=${REGION}" \
  -var="entra_tenant_id=${ENTRA_TENANT_ID}" \
  -var="entra_client_id=${ENTRA_CLIENT_ID}" \
  -var="entra_client_secret=${ENTRA_CLIENT_SECRET}"

# Capture outputs
API_URL=$(terraform output -raw api_url 2>/dev/null || echo "")
WEB_URL=$(terraform output -raw web_url 2>/dev/null || echo "")
REGISTRY_PREFIX=$(terraform output -raw artifact_registry 2>/dev/null || echo "${REGISTRY}")

cd ../..

# ── 4. Build & push Docker images ────────────────────────────
echo ""
echo "▸ Building and pushing Docker images via Cloud Build..."

gcloud builds submit apps/api \
  --tag="${REGISTRY_PREFIX}/api:latest" \
  --quiet

gcloud builds submit apps/web \
  --tag="${REGISTRY_PREFIX}/web:latest" \
  --quiet

gcloud builds submit . \
  --tag="${REGISTRY_PREFIX}/worker:latest" \
  --config=apps/worker/Dockerfile \
  --quiet

# ── 5. Deploy Cloud Run services ─────────────────────────────
echo ""
echo "▸ Deploying Cloud Run services..."

gcloud run deploy pulseboard-api \
  --image="${REGISTRY_PREFIX}/api:latest" \
  --region="${REGION}" \
  --quiet

gcloud run deploy pulseboard-web \
  --image="${REGISTRY_PREFIX}/web:latest" \
  --region="${REGION}" \
  --quiet

gcloud run deploy pulseboard-worker \
  --image="${REGISTRY_PREFIX}/worker:latest" \
  --region="${REGION}" \
  --quiet

# ── 6. Run Alembic migrations ────────────────────────────────
echo ""
echo "▸ Running database migrations..."
gcloud run jobs create pulseboard-migrate \
  --image="${REGISTRY_PREFIX}/api:latest" \
  --region="${REGION}" \
  --command="alembic" \
  --args="upgrade,head" \
  --set-secrets="DATABASE_URL=pulseboard-db-url:latest" \
  --quiet 2>/dev/null || true

gcloud run jobs execute pulseboard-migrate \
  --region="${REGION}" \
  --wait \
  --quiet

# ── 7. Seed demo data ────────────────────────────────────────
if [ "${DEMO_MODE}" = true ]; then
  echo ""
  echo "▸ Loading demo data..."
  gcloud run jobs create pulseboard-seed \
    --image="${REGISTRY_PREFIX}/api:latest" \
    --region="${REGION}" \
    --command="python" \
    --args="scripts/seed.py,--demo" \
    --set-secrets="DATABASE_URL=pulseboard-db-url:latest" \
    --quiet 2>/dev/null || true

  gcloud run jobs execute pulseboard-seed \
    --region="${REGION}" \
    --wait \
    --quiet
fi

# ── 8. Final output ──────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║         ✅  PulseBoard Deployed!                     ║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║"
echo "║  🌐 Web App:  ${WEB_URL:-https://pulseboard-web-<hash>-<region>.a.run.app}"
echo "║  🔌 API:      ${API_URL:-https://pulseboard-api-<hash>-<region>.a.run.app}"
echo "║"
echo "╠══════════════════════════════════════════════════════╣"
echo "║  NEXT STEPS (do these now):                          ║"
echo "║"
echo "║  1. Copy the Web URL above                           ║"
echo "║  2. In Entra ID app registration → Authentication:   ║"
echo "║     Add redirect URI:  <WEB_URL>/auth/callback       ║"
echo "║  3. Open the Web URL → Entra SSO sign-in             ║"
echo "║  4. Settings → Identity → Map Entra groups           ║"
echo "║  5. Settings → Integrations → Add Jira Instance      ║"
echo "║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
