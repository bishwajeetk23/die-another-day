#!/usr/bin/env python3
"""
PulseBoard Demo Seed Script
Usage: python scripts/seed.py --demo
Creates realistic AI portfolio data for demonstration.
"""
from __future__ import annotations

import argparse
import asyncio
import random
import uuid
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

# ---------------------------------------------------------------------------
LIFECYCLE_STAGES = ["ideation", "qualification", "poc", "pilot", "production", "scale", "sunset"]
AI_PATTERNS = ["predictive_ml", "gen_ai", "agentic", "cv", "nlp", "recommendation", "optimization", "rpa_ai"]
FOUNDATION_MODELS = ["gemini-2.5-pro", "gemini-2.0-flash", "claude-sonnet-3.5", "gpt-4o", "in_house_ft", "classical_ml"]
RAG_STATUSES = ["green", "amber", "red"]
SENSITIVITIES = ["public", "internal", "confidential", "restricted"]
RISK_TIERS = ["tier1", "tier2", "tier3"]
RAI_STATUSES = ["not_started", "in_review", "approved", "conditional"]
DPIA_STATUSES = ["not_required", "in_progress", "completed"]

BUSINESS_UNITS = ["Retail", "Wealth", "Corporate Banking", "Insurance", "Group"]
FUNCTIONS = ["HR", "Procurement", "Finance", "Risk", "Legal", "Operations", "IT", "Marketing"]

DEMO_PROJECTS = [
    # Core named projects from the spec
    {"name": "HR Policy Bot", "function": "HR", "bu": "Group", "pattern": "gen_ai", "stage": "production", "rag": "green", "model": "gemini-2.5-pro", "tier": "tier2", "expected_value": 2500000, "realized_value": 2100000},
    {"name": "Procurement Contract Summarizer", "function": "Procurement", "bu": "Group", "pattern": "gen_ai", "stage": "pilot", "rag": "amber", "model": "gemini-2.5-pro", "tier": "tier2", "expected_value": 1800000},
    {"name": "Loan Risk Scorer v2", "function": "Risk", "bu": "Corporate Banking", "pattern": "predictive_ml", "stage": "production", "rag": "amber", "model": "classical_ml", "tier": "tier1", "expected_value": 8000000, "realized_value": 5200000},
    {"name": "Wealth Advisor Copilot", "function": "Finance", "bu": "Wealth", "pattern": "agentic", "stage": "pilot", "rag": "amber", "model": "gemini-2.5-pro", "tier": "tier2", "expected_value": 3200000},
    {"name": "KYC Document Intelligence", "function": "Risk", "bu": "Corporate Banking", "pattern": "cv", "stage": "scale", "rag": "green", "model": "in_house_ft", "tier": "tier1", "expected_value": 5000000, "realized_value": 4400000},
    {"name": "Hiring Match", "function": "HR", "bu": "Group", "pattern": "recommendation", "stage": "poc", "rag": "green", "model": "classical_ml", "tier": "tier3", "expected_value": 900000},
    {"name": "Invoice Anomaly Detection", "function": "Finance", "bu": "Group", "pattern": "predictive_ml", "stage": "production", "rag": "green", "model": "classical_ml", "tier": "tier2", "expected_value": 4200000, "realized_value": 3900000},
    {"name": "Marketing Content Studio", "function": "Marketing", "bu": "Retail", "pattern": "gen_ai", "stage": "pilot", "rag": "green", "model": "gemini-2.0-flash", "tier": "tier3", "expected_value": 1200000},
    # Additional 32 realistic projects
    {"name": "Claims Fraud Detector", "function": "Risk", "bu": "Insurance", "pattern": "predictive_ml", "stage": "production", "rag": "green", "model": "classical_ml", "tier": "tier1", "expected_value": 6500000, "realized_value": 5800000},
    {"name": "Customer Churn Predictor — Retail", "function": "Marketing", "bu": "Retail", "pattern": "predictive_ml", "stage": "scale", "rag": "green", "model": "classical_ml", "tier": "tier2", "expected_value": 3800000, "realized_value": 3500000},
    {"name": "Legal Contract Review Bot", "function": "Legal", "bu": "Group", "pattern": "gen_ai", "stage": "pilot", "rag": "amber", "model": "claude-sonnet-3.5", "tier": "tier2", "expected_value": 2200000},
    {"name": "IT Helpdesk AI Agent", "function": "IT", "bu": "Group", "pattern": "agentic", "stage": "production", "rag": "green", "model": "gemini-2.0-flash", "tier": "tier3", "expected_value": 1500000, "realized_value": 1350000},
    {"name": "Wealth Portfolio Optimizer", "function": "Finance", "bu": "Wealth", "pattern": "optimization", "stage": "poc", "rag": "green", "model": "classical_ml", "tier": "tier1", "expected_value": 12000000},
    {"name": "Trade Surveillance AI", "function": "Risk", "bu": "Corporate Banking", "pattern": "predictive_ml", "stage": "pilot", "rag": "red", "model": "in_house_ft", "tier": "tier1", "expected_value": 9000000},
    {"name": "Procurement Spend Optimizer", "function": "Procurement", "bu": "Group", "pattern": "optimization", "stage": "ideation", "rag": "green", "model": "classical_ml", "tier": "tier3", "expected_value": 2800000},
    {"name": "Retail Product Recommender", "function": "Marketing", "bu": "Retail", "pattern": "recommendation", "stage": "scale", "rag": "green", "model": "in_house_ft", "tier": "tier2", "expected_value": 5500000, "realized_value": 5100000},
    {"name": "Operations Predictive Maintenance", "function": "Operations", "bu": "Insurance", "pattern": "predictive_ml", "stage": "pilot", "rag": "green", "model": "classical_ml", "tier": "tier2", "expected_value": 3100000},
    {"name": "Insurance Policy Chatbot", "function": "Operations", "bu": "Insurance", "pattern": "gen_ai", "stage": "production", "rag": "amber", "model": "gemini-2.5-pro", "tier": "tier2", "expected_value": 2700000, "realized_value": 1800000},
    {"name": "AML Transaction Monitoring", "function": "Risk", "bu": "Corporate Banking", "pattern": "predictive_ml", "stage": "production", "rag": "green", "model": "in_house_ft", "tier": "tier1", "expected_value": 11000000, "realized_value": 9500000},
    {"name": "Corporate Credit Risk AI", "function": "Risk", "bu": "Corporate Banking", "pattern": "predictive_ml", "stage": "qualification", "rag": "green", "model": "classical_ml", "tier": "tier1", "expected_value": 7500000},
    {"name": "HR Leave Pattern Analyzer", "function": "HR", "bu": "Group", "pattern": "predictive_ml", "stage": "poc", "rag": "green", "model": "classical_ml", "tier": "tier3", "expected_value": 600000},
    {"name": "Regulatory Reporting Automation", "function": "Finance", "bu": "Group", "pattern": "rpa_ai", "stage": "pilot", "rag": "green", "model": "gemini-2.0-flash", "tier": "tier2", "expected_value": 4000000},
    {"name": "Mortgage Underwriting Assist", "function": "Risk", "bu": "Retail", "pattern": "predictive_ml", "stage": "production", "rag": "green", "model": "in_house_ft", "tier": "tier1", "expected_value": 8500000, "realized_value": 7800000},
    {"name": "Retail Bank Chatbot v2", "function": "Operations", "bu": "Retail", "pattern": "gen_ai", "stage": "scale", "rag": "green", "model": "gemini-2.5-pro", "tier": "tier2", "expected_value": 4500000, "realized_value": 4200000},
    {"name": "Supplier Risk Scorer", "function": "Procurement", "bu": "Group", "pattern": "predictive_ml", "stage": "poc", "rag": "amber", "model": "classical_ml", "tier": "tier2", "expected_value": 1600000},
    {"name": "Executive Briefing Generator", "function": "Operations", "bu": "Group", "pattern": "gen_ai", "stage": "pilot", "rag": "green", "model": "gemini-2.5-pro", "tier": "tier3", "expected_value": 800000},
    {"name": "Insurance Telematics Scorer", "function": "Risk", "bu": "Insurance", "pattern": "predictive_ml", "stage": "production", "rag": "green", "model": "classical_ml", "tier": "tier2", "expected_value": 6200000, "realized_value": 5700000},
    {"name": "Wealth Client Sentiment AI", "function": "Finance", "bu": "Wealth", "pattern": "nlp", "stage": "qualification", "rag": "green", "model": "in_house_ft", "tier": "tier2", "expected_value": 2100000},
    {"name": "Document OCR & Extraction Platform", "function": "Operations", "bu": "Corporate Banking", "pattern": "cv", "stage": "scale", "rag": "green", "model": "in_house_ft", "tier": "tier2", "expected_value": 7200000, "realized_value": 6900000},
    {"name": "Legal Jurisdiction Risk Analyzer", "function": "Legal", "bu": "Group", "pattern": "nlp", "stage": "ideation", "rag": "green", "model": "gemini-2.5-pro", "tier": "tier2", "expected_value": 1400000},
    {"name": "Retail Store Footfall Predictor", "function": "Operations", "bu": "Retail", "pattern": "predictive_ml", "stage": "pilot", "rag": "green", "model": "classical_ml", "tier": "tier3", "expected_value": 2400000},
    {"name": "Corporate FX Hedging AI", "function": "Finance", "bu": "Corporate Banking", "pattern": "optimization", "stage": "poc", "rag": "red", "model": "classical_ml", "tier": "tier1", "expected_value": 15000000},
    {"name": "Email Phishing Detector", "function": "IT", "bu": "Group", "pattern": "nlp", "stage": "production", "rag": "green", "model": "in_house_ft", "tier": "tier2", "expected_value": 3300000, "realized_value": 3100000},
    {"name": "Insurance Quote Optimizer", "function": "Operations", "bu": "Insurance", "pattern": "optimization", "stage": "pilot", "rag": "amber", "model": "classical_ml", "tier": "tier2", "expected_value": 4800000},
    {"name": "Procurement Invoice Extractor", "function": "Procurement", "bu": "Group", "pattern": "cv", "stage": "production", "rag": "green", "model": "in_house_ft", "tier": "tier3", "expected_value": 1900000, "realized_value": 1750000},
    {"name": "Sunset — Legacy Scoring Engine", "function": "Risk", "bu": "Retail", "pattern": "predictive_ml", "stage": "sunset", "rag": "green", "model": "classical_ml", "tier": "tier1", "expected_value": 0},
    {"name": "Marketing Attribution AI", "function": "Marketing", "bu": "Retail", "pattern": "predictive_ml", "stage": "production", "rag": "green", "model": "classical_ml", "tier": "tier2", "expected_value": 3600000, "realized_value": 3400000},
    {"name": "HR Skills Gap Analyzer", "function": "HR", "bu": "Group", "pattern": "nlp", "stage": "poc", "rag": "green", "model": "gemini-2.0-flash", "tier": "tier3", "expected_value": 750000},
    {"name": "Wealth Tax Optimizer AI", "function": "Finance", "bu": "Wealth", "pattern": "optimization", "stage": "ideation", "rag": "green", "model": "classical_ml", "tier": "tier2", "expected_value": 5500000},
    {"name": "Branch Network Optimizer", "function": "Operations", "bu": "Retail", "pattern": "optimization", "stage": "qualification", "rag": "green", "model": "classical_ml", "tier": "tier3", "expected_value": 2000000},
]

KPI_TEMPLATES = [
    {"name": "Weekly Active Users", "slug": "wau", "category": "usage", "metric_type": "count", "unit": "users", "direction": "higher_is_better"},
    {"name": "Daily Active Users", "slug": "dau", "category": "usage", "metric_type": "count", "unit": "users", "direction": "higher_is_better"},
    {"name": "Thumbs-Up Rate", "slug": "thumbs_up_rate", "category": "quality", "metric_type": "percentage", "unit": "%", "direction": "higher_is_better"},
    {"name": "CSAT Score", "slug": "csat", "category": "quality", "metric_type": "ratio", "unit": "score", "direction": "higher_is_better"},
    {"name": "Escalation Rate", "slug": "escalation_rate", "category": "quality", "metric_type": "percentage", "unit": "%", "direction": "lower_is_better"},
    {"name": "Activation Rate", "slug": "activation_rate", "category": "funnel", "metric_type": "percentage", "unit": "%", "direction": "higher_is_better"},
    {"name": "Hours Saved", "slug": "hours_saved", "category": "value_realization", "metric_type": "count", "unit": "hours/week", "direction": "higher_is_better"},
    {"name": "Deflection Rate", "slug": "deflection_rate", "category": "value_realization", "metric_type": "percentage", "unit": "%", "direction": "higher_is_better"},
    {"name": "Error Rate", "slug": "error_rate", "category": "health", "metric_type": "percentage", "unit": "%", "direction": "lower_is_better"},
    {"name": "P95 Latency", "slug": "p95_latency_ms", "category": "health", "metric_type": "duration", "unit": "ms", "direction": "lower_is_better"},
]


async def seed_demo(db_url: str) -> None:
    from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
    from sqlalchemy.orm import sessionmaker
    from pulseboard.models.organization import Organization, BusinessUnit, Function
    from pulseboard.models.user import User
    from pulseboard.models.project import AIProject, AIProjectHistorySnapshot, AIProjectRisk, AIProjectMilestone
    from pulseboard.models.adoption import AdoptionKPI, AdoptionKPIValue
    import pulseboard.models.organization  # ensure table creation
    import pulseboard.models.user
    import pulseboard.models.project
    import pulseboard.models.adoption
    import pulseboard.models.jira
    import pulseboard.models.audit
    from pulseboard.database import Base

    engine = create_async_engine(db_url, echo=False)
    async_session = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with async_session() as db:
        # Organization
        org = Organization(id=uuid.uuid4(), name="Enterprise AI Corp", entra_tenant_id="demo-tenant-id")
        db.add(org)
        await db.flush()

        # Business Units
        bu_map = {}
        for bu_name in BUSINESS_UNITS:
            bu = BusinessUnit(id=uuid.uuid4(), org_id=org.id, name=bu_name)
            db.add(bu)
            bu_map[bu_name] = bu
        await db.flush()

        # Functions
        fn_map = {}
        for fn_name in FUNCTIONS:
            fn = Function(id=uuid.uuid4(), org_id=org.id, name=fn_name)
            db.add(fn)
            fn_map[fn_name] = fn
        await db.flush()

        # Users
        user_specs = [
            ("Priya Sharma", "Chief AI Officer", "PulseBoard.Admin"),
            ("Rahul Mehta", "AI Product Manager", "PulseBoard.Contributor"),
            ("Ananya Singh", "AI Engineering Lead", "PulseBoard.Contributor"),
            ("Vikram Nair", "AI Product Manager", "PulseBoard.Contributor"),
            ("Deepa Rao", "Head of HR", "PulseBoard.Viewer"),
            ("Suresh Kumar", "Head of Procurement", "PulseBoard.Viewer"),
            ("Meera Patel", "CFO / Head of Finance", "PulseBoard.Viewer"),
            ("Arjun Gupta", "Head of Risk", "PulseBoard.Viewer"),
            ("Kavitha Reddy", "Head of Legal", "PulseBoard.Viewer"),
            ("Ravi Chandran", "Head of Operations", "PulseBoard.Viewer"),
            ("Sanjay Iyer", "Head of IT", "PulseBoard.Contributor"),
            ("Neha Agarwal", "Head of Marketing", "PulseBoard.Viewer"),
            ("Amit Joshi", "AI Engineer", "PulseBoard.Contributor"),
            ("Preethi Kumar", "Data Scientist", "PulseBoard.Contributor"),
            ("Kiran Shah", "ML Engineer", "PulseBoard.Contributor"),
            ("Divya Menon", "AI Product Analyst", "PulseBoard.Viewer"),
            ("Rohan Desai", "AI Ethics Lead", "PulseBoard.Contributor"),
            ("Lakshmi Nair", "Governance Officer", "PulseBoard.Viewer"),
            ("Sunil Verma", "Head of Retail BU", "PulseBoard.Viewer"),
            ("Geeta Krishnan", "Head of Wealth BU", "PulseBoard.Viewer"),
            ("Mohan Das", "Head of Corporate Banking", "PulseBoard.Viewer"),
            ("Usha Pillai", "Head of Insurance BU", "PulseBoard.Viewer"),
            ("Nitin Bhat", "AI Solutions Architect", "PulseBoard.Contributor"),
            ("Anjali Sharma", "Change Management Lead", "PulseBoard.Viewer"),
            ("Rajesh Kapoor", "CTO", "PulseBoard.Admin"),
        ]

        users = []
        for i, (name, title, role) in enumerate(user_specs):
            first = name.split()[0].lower()
            last = name.split()[-1].lower()
            user = User(
                id=uuid.uuid4(),
                org_id=org.id,
                entra_object_id=str(uuid.uuid4()),
                email=f"{first}.{last}@enterpriseai.example.com",
                name=name,
                job_title=title,
                app_role=role,
            )
            db.add(user)
            users.append(user)
        await db.flush()

        contributor_users = [u for u in users if u.app_role in ("PulseBoard.Admin", "PulseBoard.Contributor")]
        caio = users[0]

        # Projects
        today = date.today()
        projects_created = []
        for proj_spec in DEMO_PROJECTS:
            stage = proj_spec["stage"]
            stage_idx = LIFECYCLE_STAGES.index(stage)

            # Compute realistic dates
            start_offset = random.randint(-180, -30)
            duration = random.randint(60, 365)
            start_dt = today + timedelta(days=start_offset)
            baseline_end = start_dt + timedelta(days=duration)
            slip_days = 0 if proj_spec["rag"] == "green" else random.randint(7, 45)
            forecast_end = baseline_end + timedelta(days=slip_days)

            slug = proj_spec["name"].lower().replace(" ", "-").replace("—", "").replace(".", "").replace(",", "")[:80]

            project = AIProject(
                id=uuid.uuid4(),
                org_id=org.id,
                name=proj_spec["name"],
                slug=f"{slug}-{uuid.uuid4().hex[:4]}",
                description=f"AI initiative for {proj_spec['function']} function — {proj_spec['pattern'].replace('_', ' ')} approach.",
                ai_pattern=proj_spec["pattern"],
                foundation_model=proj_spec["model"],
                data_sensitivity=random.choice(SENSITIVITIES),
                model_risk_tier=proj_spec["tier"],
                responsible_ai_status=random.choice(RAI_STATUSES) if stage_idx >= 3 else "not_started",
                dpia_status=random.choice(DPIA_STATUSES) if stage_idx >= 3 else "not_required",
                lifecycle_stage=stage,
                status="active" if stage not in ("sunset",) else "closed",
                rag_status=proj_spec["rag"],
                sponsoring_function_id=fn_map[proj_spec["function"]].id if proj_spec["function"] in fn_map else None,
                sponsoring_bu_id=bu_map[proj_spec["bu"]].id if proj_spec["bu"] in bu_map else None,
                delivering_team="Central AI Team",
                product_owner_user_id=random.choice(contributor_users).id,
                tech_lead_user_id=random.choice(contributor_users).id,
                business_sponsor_user_id=caio.id,
                start_date=start_dt,
                baseline_end_date=baseline_end,
                forecast_end_date=forecast_end,
                actual_end_date=forecast_end if stage in ("production", "scale", "sunset") else None,
                baseline_budget=Decimal(str(random.randint(200, 2000) * 1000)),
                actual_spend=Decimal(str(random.randint(200, 2500) * 1000)),
                expected_value_amount=Decimal(str(proj_spec.get("expected_value", 1000000))),
                expected_value_unit="USD_annual",
                expected_value_currency="USD",
                realized_value_amount=Decimal(str(proj_spec["realized_value"])) if proj_spec.get("realized_value") else None,
                source="jira" if random.random() > 0.4 else "manual",
            )
            db.add(project)
            projects_created.append(project)

        await db.flush()

        # 60 days of history snapshots per project
        for project in projects_created:
            for days_ago in range(60, 0, -1):
                snap_date = today - timedelta(days=days_ago)
                rag_progression = _simulate_rag(project.rag_status, days_ago)
                variance = None
                if project.forecast_end_date and project.baseline_end_date:
                    base_variance = (project.forecast_end_date - project.baseline_end_date).days
                    variance = max(0, base_variance - days_ago // 7)

                snap = AIProjectHistorySnapshot(
                    id=uuid.uuid4(),
                    project_id=project.id,
                    snapshot_date=snap_date,
                    lifecycle_stage=project.lifecycle_stage,
                    rag=rag_progression,
                    schedule_variance_days=variance,
                    budget_variance_pct=Decimal(str(round(random.uniform(-5, 15), 2))),
                    realized_value_amount=project.realized_value_amount,
                )
                db.add(snap)

        # Risks for each project
        RISK_CATEGORIES = ["data_access", "model_accuracy", "governance", "integration", "vendor_dependency", "hallucination", "latency"]
        for project in projects_created[:20]:  # First 20 projects
            num_risks = random.randint(1, 4)
            for _ in range(num_risks):
                risk = AIProjectRisk(
                    id=uuid.uuid4(),
                    project_id=project.id,
                    title=random.choice([
                        "Data access not yet approved by data steward",
                        "Model accuracy degrading in shadow testing",
                        "RAI review pending — Q3 board slate",
                        "Integration with core banking system unconfirmed",
                        "Gemini API rate limits could affect production throughput",
                        "Ground truth labeling quality insufficient for fine-tuning",
                        "Business user training not yet scheduled",
                    ]),
                    risk_category=random.choice(RISK_CATEGORIES),
                    severity=random.choice(["low", "medium", "high", "critical"]),
                    likelihood=random.choice(["low", "medium", "high"]),
                    status=random.choice(["open", "mitigated", "accepted"]),
                    mitigation="Engaged data governance team. Escalated to CISO for expedited approval.",
                )
                db.add(risk)

        await db.flush()

        # KPIs for production/scale projects
        live_projects = [p for p in projects_created if p.lifecycle_stage in ("production", "scale")]
        for project in live_projects[:10]:
            for kpi_tmpl in random.sample(KPI_TEMPLATES, k=random.randint(2, 5)):
                slug = f"{kpi_tmpl['slug']}-{uuid.uuid4().hex[:4]}"
                target = _kpi_target(kpi_tmpl["slug"])
                kpi = AdoptionKPI(
                    id=uuid.uuid4(),
                    ai_project_id=project.id,
                    name=kpi_tmpl["name"],
                    slug=slug,
                    description=f"{kpi_tmpl['name']} for {project.name}",
                    kpi_category=kpi_tmpl["category"],
                    metric_type=kpi_tmpl["metric_type"],
                    unit=kpi_tmpl["unit"],
                    target_value=Decimal(str(target)),
                    target_direction=kpi_tmpl["direction"],
                    ingestion_mode="api_push",
                    created_by=caio.id,
                )
                db.add(kpi)
                await db.flush()

                # 90 days of synthetic time-series
                base_value = _kpi_base_value(kpi_tmpl["slug"])
                drift_project = project.name == "Loan Risk Scorer v2" and kpi_tmpl["slug"] in ("thumbs_up_rate", "csat")
                jump_day = random.randint(30, 60)  # adoption jump day

                for day in range(90, 0, -1):
                    ts = datetime.now(timezone.utc) - timedelta(days=day)
                    # Weekend dips
                    is_weekend = ts.weekday() >= 5
                    # Weekly seasonality (Mon-Tue peak)
                    day_factor = 0.7 if is_weekend else (1.15 if ts.weekday() <= 1 else 1.0)
                    # Adoption jump
                    jump_factor = 1.3 if day < jump_day else 1.0
                    # Model drift event (for Loan Risk Scorer)
                    drift_factor = 0.82 if (drift_project and day < 14) else 1.0
                    # Random noise
                    noise = random.uniform(0.92, 1.08)

                    value = base_value * day_factor * jump_factor * drift_factor * noise
                    kpi_val = AdoptionKPIValue(
                        id=uuid.uuid4(),
                        kpi_id=kpi.id,
                        ts=ts,
                        value=Decimal(str(round(value, 2))),
                        dimensions_json={"region": random.choice(["APAC", "EMEA", "AMER"])},
                    )
                    db.add(kpi_val)

        await db.commit()
        print(f"\n✅ Demo data seeded successfully!")
        print(f"   Organization: {org.name}")
        print(f"   BUs: {len(BUSINESS_UNITS)} | Functions: {len(FUNCTIONS)}")
        print(f"   Users: {len(users)}")
        print(f"   AI Projects: {len(projects_created)}")
        print(f"   Live projects with KPIs: {len(live_projects[:10])}")
        print(f"   History snapshots: {len(projects_created) * 60}")


def _simulate_rag(current_rag: str, days_ago: int) -> str:
    """Simulate realistic RAG progression over time."""
    if current_rag == "green":
        return "green" if days_ago < 45 else random.choice(["green", "amber"])
    elif current_rag == "amber":
        if days_ago > 30:
            return random.choice(["green", "green", "amber"])
        return random.choice(["amber", "amber", "red"])
    else:  # red
        if days_ago > 20:
            return random.choice(["green", "amber"])
        return "red"


def _kpi_target(slug: str) -> float:
    targets = {
        "wau": 5000, "dau": 1200, "thumbs_up_rate": 85.0, "csat": 4.2,
        "escalation_rate": 8.0, "activation_rate": 65.0, "hours_saved": 500,
        "deflection_rate": 72.0, "error_rate": 1.5, "p95_latency_ms": 2000,
    }
    base_slug = slug.split("-")[0]
    return targets.get(base_slug, 100)


def _kpi_base_value(slug: str) -> float:
    bases = {
        "wau": 3800, "dau": 900, "thumbs_up_rate": 82.0, "csat": 4.0,
        "escalation_rate": 10.0, "activation_rate": 55.0, "hours_saved": 380,
        "deflection_rate": 68.0, "error_rate": 2.0, "p95_latency_ms": 1800,
    }
    base_slug = slug.split("-")[0]
    return bases.get(base_slug, 80)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true", help="Load demo data")
    parser.add_argument("--db-url", default=None, help="Override DATABASE_URL")
    args = parser.parse_args()

    if not args.demo:
        print("No flag given. Use --demo to load demo data.")
        return

    import os
    db_url = args.db_url or os.environ.get(
        "DATABASE_URL",
        "postgresql+asyncpg://postgres:postgres@localhost:5432/pulseboard"
    )
    print(f"🌱 Seeding demo data to: {db_url.split('@')[-1]}")
    asyncio.run(seed_demo(db_url))


if __name__ == "__main__":
    main()
