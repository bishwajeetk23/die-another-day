"""PulseBoard Agent Orchestrator — tool-calling loop over Gemini / Gemma."""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, AsyncGenerator

import structlog
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.auth.rbac import RBACContext
from pulseboard.config import get_settings
from pulseboard.models.user import User
from pulseboard.agent.prompts import SYSTEM_PROMPT, build_user_context_prompt
from pulseboard.agent.tools import AgentTools, TOOL_REGISTRY

log = structlog.get_logger()
settings = get_settings()

# Gemini tool function declarations
GEMINI_TOOL_DECLARATIONS = [
    {
        "name": "query_projects",
        "description": "Query the AI project portfolio. Use for any question about project status, lifecycle stage, RAG, AI pattern, or schedule.",
        "parameters": {
            "type": "object",
            "properties": {
                "lifecycle_stage": {"type": "string", "enum": ["ideation", "qualification", "poc", "pilot", "production", "scale", "sunset"]},
                "rag_status": {"type": "string", "enum": ["green", "amber", "red"]},
                "ai_pattern": {"type": "string"},
                "function_name": {"type": "string"},
                "bu_name": {"type": "string"},
                "search": {"type": "string"},
                "limit": {"type": "integer", "default": 20},
            },
        },
    },
    {
        "name": "query_adoption_metric",
        "description": "Query adoption KPI time-series data for a project. Use for DAU/WAU, CSAT, thumbs-up rate, error rate, latency, and any usage/quality/health metric.",
        "parameters": {
            "type": "object",
            "properties": {
                "kpi_slug": {"type": "string"},
                "project_name": {"type": "string"},
                "days": {"type": "integer", "default": 30},
                "dimension": {"type": "string", "description": "Dimension to group by, e.g. region, employee_grade"},
            },
        },
    },
    {
        "name": "get_project_baseline_vs_actual",
        "description": "Get a project's baseline vs actual schedule/budget. Use for 'why did X slip' or 'is X on track' questions.",
        "parameters": {
            "type": "object",
            "properties": {"project_name": {"type": "string"}},
            "required": ["project_name"],
        },
    },
    {
        "name": "get_risk_register",
        "description": "Get risks for a project or across the portfolio, optionally filtered by category or severity.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_name": {"type": "string"},
                "risk_category": {"type": "string", "enum": ["data_access", "data_quality", "model_accuracy", "bias", "hallucination", "latency", "cost", "governance", "change_mgmt", "integration", "vendor_dependency"]},
                "severity": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
            },
        },
    },
    {
        "name": "get_model_drift_signal",
        "description": "Detect model quality drift — declining quality or health KPIs. Use for 'is X drifting' or 'which models are showing drift'.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_name": {"type": "string"},
                "days": {"type": "integer", "default": 30},
            },
        },
    },
    {
        "name": "get_value_realization",
        "description": "Get expected vs realized business value for live AI projects.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_name": {"type": "string"},
                "function_name": {"type": "string"},
            },
        },
    },
    {
        "name": "lookup_owner",
        "description": "Find the product owner, tech lead, and business sponsor for a project.",
        "parameters": {
            "type": "object",
            "properties": {"project_name": {"type": "string"}},
            "required": ["project_name"],
        },
    },
    {
        "name": "render_chart",
        "description": "Produce a chart specification to visualize data. Call this after gathering data to render a chart inline.",
        "parameters": {
            "type": "object",
            "properties": {
                "chart_type": {"type": "string", "enum": ["line", "bar", "funnel", "heatmap", "scatter", "area"]},
                "title": {"type": "string"},
                "data": {"type": "array", "items": {"type": "object"}},
                "x_key": {"type": "string"},
                "y_keys": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["chart_type", "title", "data", "x_key", "y_keys"],
        },
    },
    {
        "name": "summarize_governance_status",
        "description": "Get governance / compliance status across projects — RAI status, DPIA, model risk tier.",
        "parameters": {
            "type": "object",
            "properties": {
                "project_name": {"type": "string"},
                "risk_tier": {"type": "string", "enum": ["tier1", "tier2", "tier3"]},
            },
        },
    },
]


class AgentOrchestrator:
    """Tool-calling agent loop. Streams partial results as SSE events."""

    MAX_TOOL_ROUNDS = 5

    def __init__(self, db: AsyncSession, user: User, rbac: RBACContext) -> None:
        self.db = db
        self.user = user
        self.rbac = rbac
        self.tools = AgentTools(db=db, rbac=rbac)

    async def run(
        self,
        query: str,
        conversation_id: uuid.UUID | None = None,
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Run the agent and yield SSE chunks."""
        log.info("agent.run_start", user_id=str(self.user.id), query_preview=query[:80])

        # Save user message
        conv_id = await self._ensure_conversation(query, conversation_id)

        # Build context prompt
        context_prompt = await self._build_context_prompt()
        full_system = SYSTEM_PROMPT + "\n\n" + context_prompt

        messages = await self._load_history(conv_id)
        messages.append({"role": "user", "content": query})

        tool_calls_log: list[dict] = []
        final_text = ""

        try:
            if settings.llm_provider == "gemini":
                async for chunk in self._run_gemini(full_system, messages, tool_calls_log):
                    if chunk.get("type") == "text_delta":
                        final_text += chunk.get("delta", "")
                    yield chunk
            else:
                # Gemma fallback — simple non-streaming completion
                result = await self._run_gemma_fallback(full_system, messages)
                final_text = result
                yield {"type": "text_delta", "delta": result}

        except Exception as exc:
            log.error("agent.run_error", error=str(exc))
            yield {"type": "error", "message": str(exc)}
            return

        # Persist assistant message
        await self._save_message(conv_id, "assistant", final_text, tool_calls_log)
        yield {"type": "done", "conversation_id": str(conv_id)}

    async def _run_gemini(
        self,
        system_prompt: str,
        messages: list[dict],
        tool_calls_log: list[dict],
    ) -> AsyncGenerator[dict[str, Any], None]:
        """Run Gemini with function calling."""
        try:
            import vertexai  # type: ignore
            from vertexai.generative_models import GenerativeModel, Tool, FunctionDeclaration, Content, Part  # type: ignore
        except ImportError:
            # Fallback to mock in dev
            yield {"type": "text_delta", "delta": await self._mock_response(messages[-1]["content"])}
            return

        vertexai.init(project=settings.vertex_ai_project, location=settings.vertex_ai_location)

        tools = [Tool(function_declarations=[FunctionDeclaration(**decl) for decl in GEMINI_TOOL_DECLARATIONS])]

        # Convert messages to Gemini format
        gemini_contents = []
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            gemini_contents.append(Content(role=role, parts=[Part.from_text(msg["content"])]))

        model = GenerativeModel(
            settings.gemini_model,
            system_instruction=system_prompt,
            tools=tools,
        )

        for round_num in range(self.MAX_TOOL_ROUNDS):
            response = await model.generate_content_async(
                gemini_contents,
                stream=True,
                generation_config={"temperature": 0.2, "max_output_tokens": 4096},
            )

            # Stream text
            full_response = ""
            function_calls: list[dict] = []
            async for chunk in response:
                for part in chunk.candidates[0].content.parts:
                    if hasattr(part, "text") and part.text:
                        full_response += part.text
                        yield {"type": "text_delta", "delta": part.text}
                    if hasattr(part, "function_call") and part.function_call:
                        function_calls.append({
                            "name": part.function_call.name,
                            "args": dict(part.function_call.args),
                        })

            if not function_calls:
                break  # No more tool calls — done

            # Execute tools
            tool_results = []
            start_ms = __import__("time").time() * 1000
            for fc in function_calls:
                tool_name = fc["name"]
                tool_args = fc["args"]
                log.info("agent.tool_call", tool=tool_name, args=tool_args)
                yield {"type": "tool_call", "tool": tool_name, "args": tool_args}

                result = await self._execute_tool(tool_name, tool_args)
                duration_ms = round(__import__("time").time() * 1000 - start_ms, 1)
                tool_calls_log.append({"tool": tool_name, "duration_ms": duration_ms})
                tool_results.append({"tool": tool_name, "result": result})
                yield {"type": "tool_result", "tool": tool_name, "result": result, "duration_ms": duration_ms}

            # Feed results back
            tool_result_text = "\n".join(
                f"[{r['tool']} result]: {json.dumps(r['result'], default=str)}"
                for r in tool_results
            )
            gemini_contents.append(Content(role="model", parts=[Part.from_text(full_response)]))
            gemini_contents.append(Content(role="user", parts=[Part.from_text(f"Tool results:\n{tool_result_text}\n\nNow synthesize your final answer with citations.")]))

    async def _execute_tool(self, tool_name: str, args: dict) -> Any:
        """Execute a named tool with the given args."""
        handler_name, input_schema = TOOL_REGISTRY.get(tool_name, (None, None))
        if not handler_name or not input_schema:
            return {"error": f"Unknown tool: {tool_name}"}

        handler = getattr(self.tools, handler_name, None)
        if not handler:
            return {"error": f"Tool handler not found: {handler_name}"}

        try:
            inp = input_schema(**args)
            import asyncio
            if asyncio.iscoroutinefunction(handler):
                return await handler(inp)
            return handler(inp)
        except Exception as exc:
            return {"error": str(exc)}

    async def _run_gemma_fallback(self, system_prompt: str, messages: list[dict]) -> str:
        """Simple Gemma inference via Cloud Run endpoint."""
        import httpx
        from pulseboard.config import get_settings
        s = get_settings()
        gemma_endpoint = getattr(s, "gemma_endpoint", None)
        if not gemma_endpoint:
            return await self._mock_response(messages[-1]["content"])

        prompt = f"{system_prompt}\n\nUser: {messages[-1]['content']}\nAssistant:"
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                gemma_endpoint,
                json={"prompt": prompt, "max_tokens": 1024, "temperature": 0.2},
            )
            resp.raise_for_status()
            return resp.json().get("text", "")

    async def _mock_response(self, query: str) -> str:
        """Dev-mode mock response when no LLM is configured."""
        return (
            f"[Demo mode — LLM not configured] You asked: '{query}'. "
            "In production, this would be answered by Gemini 2.5 Pro with live tool calls "
            "against your portfolio data. Set VERTEX_AI_PROJECT and LLM_PROVIDER=gemini to enable."
        )

    async def _build_context_prompt(self) -> str:
        from pulseboard.models.project import AIProject
        from sqlalchemy import func as sqlfunc

        # Portfolio summary
        counts = await self.db.execute(
            select(AIProject.rag_status, sqlfunc.count(AIProject.id)).group_by(AIProject.rag_status)
        )
        rag_counts = {row[0]: row[1] for row in counts}
        total = sum(rag_counts.values())

        return build_user_context_prompt(
            user_name=self.user.name,
            user_role=self.user.app_role,
            bu_names=[],
            function_names=[],
            portfolio_summary={
                "total_projects": total,
                "red_count": rag_counts.get("red", 0),
                "amber_count": rag_counts.get("amber", 0),
                "green_count": rag_counts.get("green", 0),
                "live_count": 0,
            },
        )

    async def _ensure_conversation(self, query: str, conversation_id: uuid.UUID | None) -> uuid.UUID:
        from pulseboard.models.user import AIConversation, AIMessage

        if conversation_id:
            result = await self.db.execute(
                select(AIConversation).where(
                    AIConversation.id == conversation_id,
                    AIConversation.user_id == self.user.id,
                )
            )
            conv = result.scalar_one_or_none()
            if conv:
                return conv.id

        # Create new conversation
        title = query[:80] + ("…" if len(query) > 80 else "")
        conv = AIConversation(user_id=self.user.id, title=title)
        self.db.add(conv)
        await self.db.flush()
        return conv.id

    async def _load_history(self, conversation_id: uuid.UUID) -> list[dict]:
        from pulseboard.models.user import AIMessage

        result = await self.db.execute(
            select(AIMessage)
            .where(AIMessage.conversation_id == conversation_id)
            .order_by(AIMessage.created_at)
            .limit(20)
        )
        return [
            {"role": m.role, "content": m.content}
            for m in result.scalars()
        ]

    async def _save_message(
        self,
        conversation_id: uuid.UUID,
        role: str,
        content: str,
        tool_calls: list[dict],
    ) -> None:
        from pulseboard.models.user import AIMessage

        msg = AIMessage(
            conversation_id=conversation_id,
            role=role,
            content=content,
            tool_calls_json=tool_calls,
        )
        self.db.add(msg)
        await self.db.commit()
