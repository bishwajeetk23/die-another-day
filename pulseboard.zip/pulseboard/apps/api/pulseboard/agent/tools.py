"""Agent tools — typed Pydantic schemas + implementation for every tool the agent can call."""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from pydantic import BaseModel, Field
from sqlalchemy import and_, desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.auth.rbac import RBACContext
from pulseboard.models.adoption import AdoptionKPI, AdoptionKPIValue
from pulseboard.models.project import (
    AIProject,
    AIProjectHistorySnapshot,
    AIProjectRisk,
)
from pulseboard.models.user import User


# ---------------------------------------------------------------------------
# Tool input schemas
# ---------------------------------------------------------------------------


class QueryProjectsInput(BaseModel):
    lifecycle_stage: str | None = Field(None, description="Filter by lifecycle stage")
    rag_status: str | None = Field(None, description="green | amber | red")
    ai_pattern: str | None = None
    function_name: str | None = None
    bu_name: str | None = None
    search: str | None = Field(None, description="Name search")
    limit: int = Field(20, le=100)


class QueryAdoptionMetricInput(BaseModel):
    kpi_slug: str | None = None
    project_name: str | None = None
    days: int = Field(30, ge=1, le=365)
    dimension: str | None = Field(None, description="Dimension key to group by")


class GetProjectBaselineInput(BaseModel):
    project_name: str


class GetRiskRegisterInput(BaseModel):
    project_name: str | None = None
    risk_category: str | None = None
    severity: str | None = None


class GetModelDriftSignalInput(BaseModel):
    project_name: str | None = None
    days: int = Field(30, ge=7, le=90)


class GetValueRealizationInput(BaseModel):
    project_name: str | None = None
    function_name: str | None = None


class CompareCohortsInput(BaseModel):
    kpi_slug: str
    dimension: str
    days: int = Field(30, ge=7, le=90)


class LookupOwnerInput(BaseModel):
    project_name: str


class RenderChartInput(BaseModel):
    chart_type: str = Field(..., description="line | bar | funnel | heatmap | scatter")
    title: str
    data: list[dict[str, Any]]
    x_key: str
    y_keys: list[str]
    colors: list[str] = Field(default_factory=lambda: ["#8B5CF6", "#10B981", "#F59E0B", "#EF4444"])


class SummarizeGovernanceInput(BaseModel):
    project_name: str | None = None
    risk_tier: str | None = None


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------


class AgentTools:
    def __init__(self, db: AsyncSession, rbac: RBACContext) -> None:
        self.db = db
        self.rbac = rbac

    async def query_projects(self, inp: QueryProjectsInput) -> dict[str, Any]:
        filters = []
        if inp.lifecycle_stage:
            filters.append(AIProject.lifecycle_stage == inp.lifecycle_stage)
        if inp.rag_status:
            filters.append(AIProject.rag_status == inp.rag_status)
        if inp.ai_pattern:
            filters.append(AIProject.ai_pattern == inp.ai_pattern)
        if inp.search:
            filters.append(AIProject.name.ilike(f"%{inp.search}%"))

        stmt = select(AIProject)
        if filters:
            stmt = stmt.where(and_(*filters))
        stmt = stmt.order_by(AIProject.name).limit(inp.limit)

        result = await self.db.execute(stmt)
        projects = result.scalars().all()

        rows = [
            {
                "id": str(p.id),
                "name": p.name,
                "lifecycle_stage": p.lifecycle_stage,
                "rag_status": p.rag_status,
                "ai_pattern": p.ai_pattern,
                "status": p.status,
                "baseline_end_date": p.baseline_end_date.isoformat() if p.baseline_end_date else None,
                "forecast_end_date": p.forecast_end_date.isoformat() if p.forecast_end_date else None,
                "schedule_variance_days": (
                    (p.forecast_end_date - p.baseline_end_date).days
                    if p.forecast_end_date and p.baseline_end_date
                    else None
                ),
            }
            for p in projects
        ]
        return {
            "count": len(rows),
            "projects": rows,
            "_citation_type": "project_list",
            "_tool": "query_projects",
        }

    async def query_adoption_metric(self, inp: QueryAdoptionMetricInput) -> dict[str, Any]:
        since = datetime.now(timezone.utc) - timedelta(days=inp.days)
        filters = [AdoptionKPIValue.ts >= since]
        kpi_filters = []
        if inp.kpi_slug:
            kpi_filters.append(AdoptionKPI.slug == inp.kpi_slug)

        # Join KPI values with KPI definitions
        stmt = (
            select(AdoptionKPIValue, AdoptionKPI)
            .join(AdoptionKPI, AdoptionKPIValue.kpi_id == AdoptionKPI.id)
            .where(and_(*filters))
            .order_by(AdoptionKPIValue.ts.desc())
            .limit(200)
        )
        if kpi_filters:
            stmt = stmt.where(and_(*kpi_filters))

        result = await self.db.execute(stmt)
        rows = result.all()

        data_points = [
            {
                "ts": str(v.ts),
                "value": float(v.value),
                "kpi_name": k.name,
                "kpi_slug": k.slug,
                "unit": k.unit,
                "dimensions": v.dimensions_json,
                "_citation": {"type": "kpi_value", "kpi_id": str(k.id), "ts": str(v.ts)},
            }
            for v, k in rows
        ]

        latest = data_points[0]["value"] if data_points else None
        return {
            "data": data_points,
            "latest_value": latest,
            "days_requested": inp.days,
            "_tool": "query_adoption_metric",
        }

    async def get_project_baseline_vs_actual(self, inp: GetProjectBaselineInput) -> dict[str, Any]:
        result = await self.db.execute(
            select(AIProject).where(AIProject.name.ilike(f"%{inp.project_name}%")).limit(1)
        )
        project = result.scalar_one_or_none()
        if not project:
            return {"error": f"No project found matching '{inp.project_name}'", "_tool": "get_project_baseline_vs_actual"}

        history_result = await self.db.execute(
            select(AIProjectHistorySnapshot)
            .where(AIProjectHistorySnapshot.project_id == project.id)
            .order_by(AIProjectHistorySnapshot.snapshot_date)
            .limit(90)
        )
        history = history_result.scalars().all()

        return {
            "project_id": str(project.id),
            "project_name": project.name,
            "lifecycle_stage": project.lifecycle_stage,
            "rag_status": project.rag_status,
            "baseline_end_date": project.baseline_end_date.isoformat() if project.baseline_end_date else None,
            "forecast_end_date": project.forecast_end_date.isoformat() if project.forecast_end_date else None,
            "schedule_variance_days": (
                (project.forecast_end_date - project.baseline_end_date).days
                if project.forecast_end_date and project.baseline_end_date
                else None
            ),
            "budget_variance_pct": float(
                (project.actual_spend - project.baseline_budget) / project.baseline_budget * 100
            ) if project.actual_spend and project.baseline_budget else None,
            "history": [
                {
                    "date": h.snapshot_date.isoformat(),
                    "rag": h.rag,
                    "schedule_variance_days": h.schedule_variance_days,
                }
                for h in history
            ],
            "_citation": {"type": "project", "project_id": str(project.id)},
            "_tool": "get_project_baseline_vs_actual",
        }

    async def get_risk_register(self, inp: GetRiskRegisterInput) -> dict[str, Any]:
        filters = []
        project_id = None

        if inp.project_name:
            proj_result = await self.db.execute(
                select(AIProject).where(AIProject.name.ilike(f"%{inp.project_name}%")).limit(1)
            )
            project = proj_result.scalar_one_or_none()
            if project:
                project_id = project.id
                filters.append(AIProjectRisk.project_id == project.id)

        if inp.risk_category:
            filters.append(AIProjectRisk.risk_category == inp.risk_category)
        if inp.severity:
            filters.append(AIProjectRisk.severity == inp.severity)

        stmt = select(AIProjectRisk)
        if filters:
            stmt = stmt.where(and_(*filters))
        stmt = stmt.order_by(AIProjectRisk.severity, AIProjectRisk.created_at.desc()).limit(50)

        result = await self.db.execute(stmt)
        risks = result.scalars().all()

        return {
            "risks": [
                {
                    "id": str(r.id),
                    "title": r.title,
                    "risk_category": r.risk_category,
                    "severity": r.severity,
                    "likelihood": r.likelihood,
                    "status": r.status,
                    "mitigation": r.mitigation,
                }
                for r in risks
            ],
            "count": len(risks),
            "_tool": "get_risk_register",
        }

    async def get_model_drift_signal(self, inp: GetModelDriftSignalInput) -> dict[str, Any]:
        """Detect declining quality KPIs over the given window — proxy for model drift."""
        since = datetime.now(timezone.utc) - timedelta(days=inp.days)
        quality_categories = ("quality", "health")

        stmt = (
            select(AdoptionKPI, AdoptionKPIValue)
            .join(AdoptionKPIValue, AdoptionKPIValue.kpi_id == AdoptionKPI.id)
            .where(
                and_(
                    AdoptionKPI.kpi_category.in_(quality_categories),
                    AdoptionKPIValue.ts >= since,
                )
            )
            .order_by(AdoptionKPI.id, AdoptionKPIValue.ts)
        )

        result = await self.db.execute(stmt)
        rows = result.all()

        # Group by KPI and compute trend
        from collections import defaultdict
        kpi_values: dict[str, list[float]] = defaultdict(list)
        kpi_meta: dict[str, dict] = {}
        for kpi, val in rows:
            key = str(kpi.id)
            kpi_values[key].append(float(val.value))
            kpi_meta[key] = {"name": kpi.name, "slug": kpi.slug, "unit": kpi.unit, "target_direction": kpi.target_direction}

        drift_signals = []
        for kpi_id, values in kpi_values.items():
            if len(values) < 5:
                continue
            meta = kpi_meta[kpi_id]
            # Simple: compare first half vs second half average
            mid = len(values) // 2
            first_half_avg = sum(values[:mid]) / mid
            second_half_avg = sum(values[mid:]) / (len(values) - mid)
            change_pct = ((second_half_avg - first_half_avg) / first_half_avg * 100) if first_half_avg else 0

            is_drift = (
                (meta["target_direction"] == "higher_is_better" and change_pct < -5)
                or (meta["target_direction"] == "lower_is_better" and change_pct > 5)
            )
            if is_drift:
                drift_signals.append({
                    "kpi_name": meta["name"],
                    "kpi_slug": meta["slug"],
                    "change_pct": round(change_pct, 1),
                    "direction": "declining" if meta["target_direction"] == "higher_is_better" else "increasing",
                    "severity": "high" if abs(change_pct) > 15 else "medium",
                })

        return {
            "drift_signals": drift_signals,
            "has_drift": len(drift_signals) > 0,
            "days_analyzed": inp.days,
            "_tool": "get_model_drift_signal",
        }

    async def get_value_realization(self, inp: GetValueRealizationInput) -> dict[str, Any]:
        stmt = select(AIProject).where(AIProject.lifecycle_stage.in_(["production", "scale"]))
        if inp.project_name:
            stmt = stmt.where(AIProject.name.ilike(f"%{inp.project_name}%"))
        stmt = stmt.order_by(AIProject.name)

        result = await self.db.execute(stmt)
        projects = result.scalars().all()

        return {
            "projects": [
                {
                    "id": str(p.id),
                    "name": p.name,
                    "expected_value": float(p.expected_value_amount) if p.expected_value_amount else None,
                    "realized_value": float(p.realized_value_amount) if p.realized_value_amount else None,
                    "value_currency": p.expected_value_currency,
                    "value_unit": p.expected_value_unit,
                    "realization_pct": (
                        round(float(p.realized_value_amount) / float(p.expected_value_amount) * 100, 1)
                        if p.realized_value_amount and p.expected_value_amount
                        else None
                    ),
                    "_citation": {"type": "project", "project_id": str(p.id)},
                }
                for p in projects
            ],
            "_tool": "get_value_realization",
        }

    async def lookup_owner(self, inp: LookupOwnerInput) -> dict[str, Any]:
        stmt = select(AIProject).where(AIProject.name.ilike(f"%{inp.project_name}%")).limit(1)
        result = await self.db.execute(stmt)
        project = result.scalar_one_or_none()
        if not project:
            return {"error": f"Project '{inp.project_name}' not found", "_tool": "lookup_owner"}

        # Fetch owners
        owner_ids = [
            project.product_owner_user_id,
            project.tech_lead_user_id,
            project.business_sponsor_user_id,
        ]
        owner_ids = [oid for oid in owner_ids if oid]

        owners: list[dict] = []
        if owner_ids:
            users_result = await self.db.execute(select(User).where(User.id.in_(owner_ids)))
            for user in users_result.scalars():
                role = "Product Owner" if user.id == project.product_owner_user_id else \
                       "Tech Lead" if user.id == project.tech_lead_user_id else "Business Sponsor"
                owners.append({"role": role, "name": user.name, "email": user.email})

        return {"project_name": project.name, "owners": owners, "_tool": "lookup_owner"}

    def render_chart(self, inp: RenderChartInput) -> dict[str, Any]:
        """Return a chart specification for the frontend to render."""
        return {
            "type": "chart",
            "spec": {
                "chart_type": inp.chart_type,
                "title": inp.title,
                "data": inp.data,
                "x_key": inp.x_key,
                "y_keys": inp.y_keys,
                "colors": inp.colors,
            },
            "_tool": "render_chart",
        }

    async def summarize_governance_status(self, inp: SummarizeGovernanceInput) -> dict[str, Any]:
        stmt = select(AIProject)
        if inp.project_name:
            stmt = stmt.where(AIProject.name.ilike(f"%{inp.project_name}%"))
        if inp.risk_tier:
            stmt = stmt.where(AIProject.model_risk_tier == inp.risk_tier)
        stmt = stmt.limit(20)

        result = await self.db.execute(stmt)
        projects = result.scalars().all()

        return {
            "governance": [
                {
                    "id": str(p.id),
                    "name": p.name,
                    "model_risk_tier": p.model_risk_tier,
                    "responsible_ai_status": p.responsible_ai_status,
                    "dpia_status": p.dpia_status,
                    "data_sensitivity": p.data_sensitivity,
                }
                for p in projects
            ],
            "count": len(projects),
            "_tool": "summarize_governance_status",
        }


# Tool registry for the orchestrator
TOOL_REGISTRY = {
    "query_projects": ("query_projects", QueryProjectsInput),
    "query_adoption_metric": ("query_adoption_metric", QueryAdoptionMetricInput),
    "get_project_baseline_vs_actual": ("get_project_baseline_vs_actual", GetProjectBaselineInput),
    "get_risk_register": ("get_risk_register", GetRiskRegisterInput),
    "get_model_drift_signal": ("get_model_drift_signal", GetModelDriftSignalInput),
    "get_value_realization": ("get_value_realization", GetValueRealizationInput),
    "compare_cohorts": ("query_adoption_metric", QueryAdoptionMetricInput),  # reuse with dimension
    "lookup_owner": ("lookup_owner", LookupOwnerInput),
    "render_chart": ("render_chart", RenderChartInput),
    "summarize_governance_status": ("summarize_governance_status", SummarizeGovernanceInput),
}
