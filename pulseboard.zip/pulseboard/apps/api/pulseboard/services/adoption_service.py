"""Adoption KPI service."""
from __future__ import annotations

import hashlib
import uuid
from typing import Any

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.auth.rbac import RBACContext
from pulseboard.models.adoption import AdoptionKPI
from pulseboard.models.user import User
from pulseboard.schemas.adoption import KPICreate


class AdoptionService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def list_kpis(
        self,
        rbac: RBACContext,
        project_id: uuid.UUID | None = None,
        category: str | None = None,
    ) -> list[AdoptionKPI]:
        from sqlalchemy import and_
        filters = []
        if project_id:
            filters.append(AdoptionKPI.ai_project_id == project_id)
        if category:
            filters.append(AdoptionKPI.kpi_category == category)
        stmt = select(AdoptionKPI)
        if filters:
            stmt = stmt.where(and_(*filters))
        stmt = stmt.order_by(AdoptionKPI.name)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def create_kpi(self, payload: KPICreate, creator: User) -> AdoptionKPI:
        kpi = AdoptionKPI(
            created_by=creator.id,
            **payload.model_dump(),
        )
        self.db.add(kpi)
        await self.db.commit()
        await self.db.refresh(kpi)
        return kpi

    async def validate_ingest_token(self, kpi_id: uuid.UUID, authorization: str | None) -> AdoptionKPI:
        result = await self.db.execute(select(AdoptionKPI).where(AdoptionKPI.id == kpi_id))
        kpi = result.scalar_one_or_none()
        if not kpi:
            raise HTTPException(status_code=404, detail="KPI not found")

        if not authorization or not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="Missing bearer token")

        token = authorization.split(" ", 1)[1]
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        config = kpi.source_config_json or {}
        stored_hash = config.get("ingest_token_hash")

        if not stored_hash or token_hash != stored_hash:
            raise HTTPException(status_code=401, detail="Invalid ingest token")

        return kpi
