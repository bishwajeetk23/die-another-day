"""Project service — business logic for AI project management."""
from __future__ import annotations

import uuid
from datetime import date
from typing import Any

from fastapi import HTTPException, status
from sqlalchemy import and_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from pulseboard.auth.rbac import RBACContext
from pulseboard.models.project import AIProject, AIProjectHistorySnapshot
from pulseboard.models.user import User
from pulseboard.schemas.project import ProjectCreate, ProjectUpdate, StageAdvance

LIFECYCLE_STAGES = [
    "ideation", "qualification", "poc", "pilot", "production", "scale", "sunset"
]

# Stage-gate requirements: what must be true before advancing
STAGE_GATES: dict[str, list[str]] = {
    "qualification": ["business_hypothesis_defined", "feasibility_assessed"],
    "poc": ["go_no_go_approved", "data_availability_confirmed", "success_criteria_defined"],
    "pilot": ["poc_success_criteria_met", "target_user_group_identified"],
    "production": ["responsible_ai_approved", "load_test_passed", "rollback_plan_documented", "training_material_ready"],
    "scale": ["production_kpis_met", "value_realization_measured"],
    "sunset": ["stakeholder_notified", "data_retention_policy_confirmed"],
}


class ProjectService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def list_projects(
        self,
        rbac: RBACContext,
        bu_id: uuid.UUID | None = None,
        function_id: uuid.UUID | None = None,
        lifecycle_stage: str | None = None,
        rag_status: str | None = None,
        ai_pattern: str | None = None,
        source: str | None = None,
        search: str | None = None,
        page: int = 1,
        page_size: int = 50,
    ) -> list[AIProject]:
        stmt = select(AIProject)
        filters = []

        # RBAC: non-admins only see their BU/function's projects
        if not rbac.is_admin and rbac.accessible_bu_ids:
            filters.append(
                or_(
                    AIProject.sponsoring_bu_id.in_(rbac.accessible_bu_ids),
                    AIProject.sponsoring_function_id.in_(rbac.accessible_function_ids),
                )
            )

        if bu_id:
            filters.append(AIProject.sponsoring_bu_id == bu_id)
        if function_id:
            filters.append(AIProject.sponsoring_function_id == function_id)
        if lifecycle_stage:
            filters.append(AIProject.lifecycle_stage == lifecycle_stage)
        if rag_status:
            filters.append(AIProject.rag_status == rag_status)
        if ai_pattern:
            filters.append(AIProject.ai_pattern == ai_pattern)
        if source:
            filters.append(AIProject.source == source)
        if search:
            filters.append(AIProject.name.ilike(f"%{search}%"))

        if filters:
            stmt = stmt.where(and_(*filters))

        stmt = stmt.order_by(AIProject.name).offset((page - 1) * page_size).limit(page_size)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def create_project(self, payload: ProjectCreate, creator: User) -> AIProject:
        slug = payload.slug or _slugify(payload.name)
        # Ensure unique slug
        existing = await self.db.execute(select(AIProject).where(AIProject.slug == slug))
        if existing.scalar_one_or_none():
            slug = f"{slug}-{uuid.uuid4().hex[:6]}"

        project = AIProject(
            org_id=creator.org_id,
            slug=slug,
            **payload.model_dump(exclude={"slug"}),
        )
        self.db.add(project)
        await self.db.commit()
        await self.db.refresh(project)
        return project

    async def get_project_or_404(self, project_id: uuid.UUID, rbac: RBACContext) -> AIProject:
        result = await self.db.execute(select(AIProject).where(AIProject.id == project_id))
        project = result.scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        if not rbac.can_access_project(project):
            raise HTTPException(status_code=403, detail="Access denied")
        return project

    async def update_project(self, project_id: uuid.UUID, payload: ProjectUpdate, rbac: RBACContext) -> AIProject:
        project = await self.get_project_or_404(project_id, rbac)
        for field, value in payload.model_dump(exclude_unset=True).items():
            setattr(project, field, value)
        await self.db.commit()
        await self.db.refresh(project)
        return project

    async def delete_project(self, project_id: uuid.UUID, rbac: RBACContext) -> None:
        project = await self.get_project_or_404(project_id, rbac)
        await self.db.delete(project)
        await self.db.commit()

    async def advance_stage(self, project_id: uuid.UUID, payload: StageAdvance, rbac: RBACContext) -> AIProject:
        project = await self.get_project_or_404(project_id, rbac)
        current_idx = LIFECYCLE_STAGES.index(project.lifecycle_stage) if project.lifecycle_stage in LIFECYCLE_STAGES else 0
        target_idx = LIFECYCLE_STAGES.index(payload.target_stage) if payload.target_stage in LIFECYCLE_STAGES else -1

        if target_idx != current_idx + 1:
            raise HTTPException(
                status_code=400,
                detail=f"Can only advance one stage at a time. Current: {project.lifecycle_stage}, requested: {payload.target_stage}",
            )

        # Record snapshot before advance
        snapshot = AIProjectHistorySnapshot(
            project_id=project_id,
            snapshot_date=date.today(),
            lifecycle_stage=project.lifecycle_stage,
            rag=project.rag_status,
            schedule_variance_days=_calc_schedule_variance(project),
        )
        self.db.add(snapshot)

        project.lifecycle_stage = payload.target_stage
        await self.db.commit()
        await self.db.refresh(project)
        return project

    async def rag_override(self, project_id: uuid.UUID, rag_status: str, reason: str | None, rbac: RBACContext) -> AIProject:
        project = await self.get_project_or_404(project_id, rbac)
        if rag_status not in ("green", "amber", "red"):
            raise HTTPException(status_code=400, detail="RAG status must be green, amber, or red")
        project.rag_status = rag_status
        await self.db.commit()
        await self.db.refresh(project)
        return project


def _slugify(name: str) -> str:
    import re
    slug = name.lower()
    slug = re.sub(r"[^a-z0-9\s-]", "", slug)
    slug = re.sub(r"[\s]+", "-", slug.strip())
    return slug[:100]


def _calc_schedule_variance(project: AIProject) -> int | None:
    if project.forecast_end_date and project.baseline_end_date:
        return (project.forecast_end_date - project.baseline_end_date).days
    return None
