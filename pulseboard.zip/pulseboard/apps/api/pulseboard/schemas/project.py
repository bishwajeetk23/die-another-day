"""Project-related Pydantic schemas."""

from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Literal

from pydantic import BaseModel, Field, field_validator


LifecycleStage = Literal[
    "ideation", "qualification", "poc", "pilot", "production", "scale", "sunset"
]
AIPattern = Literal[
    "predictive_ml", "gen_ai", "agentic", "cv", "nlp", "recommendation", "optimization", "rpa_ai"
]
RAGStatus = Literal["green", "amber", "red"]
RiskSeverity = Literal["low", "medium", "high", "critical"]
RiskLikelihood = Literal["low", "medium", "high"]
RiskStatus = Literal["open", "mitigated", "accepted", "closed"]
IssueSeverity = Literal["low", "medium", "high", "critical"]
MilestoneStatus = Literal["pending", "in_progress", "complete", "delayed"]


# Stage gate advancement ordering
STAGE_ORDER: list[LifecycleStage] = [
    "ideation", "qualification", "poc", "pilot", "production", "scale", "sunset"
]

# Stage gate checklist requirements (at minimum these fields must be populated)
STAGE_GATE_REQUIREMENTS: dict[str, list[str]] = {
    "qualification": ["ai_pattern", "product_owner_user_id", "business_sponsor_user_id"],
    "poc": ["foundation_model", "data_sensitivity", "tech_lead_user_id"],
    "pilot": ["model_risk_tier", "responsible_ai_status", "baseline_budget", "start_date"],
    "production": ["dpia_status", "actual_spend", "expected_value_amount"],
    "scale": ["realized_value_amount"],
    "sunset": ["actual_end_date"],
}


class MilestoneBase(BaseModel):
    name: str
    baseline_date: date | None = None
    forecast_date: date | None = None
    actual_date: date | None = None
    status: MilestoneStatus = "pending"
    stage_gate: bool = False


class MilestoneCreate(MilestoneBase):
    pass


class MilestoneRead(MilestoneBase):
    id: uuid.UUID
    project_id: uuid.UUID

    model_config = {"from_attributes": True}


class RiskBase(BaseModel):
    title: str
    risk_category: str | None = None
    severity: RiskSeverity = "medium"
    likelihood: RiskLikelihood = "medium"
    mitigation: str | None = None
    owner_user_id: uuid.UUID | None = None
    status: RiskStatus = "open"


class RiskCreate(RiskBase):
    pass


class RiskRead(RiskBase):
    id: uuid.UUID
    project_id: uuid.UUID
    created_at: datetime

    model_config = {"from_attributes": True}


class IssueBase(BaseModel):
    title: str
    severity: IssueSeverity = "medium"
    owner_user_id: uuid.UUID | None = None


class IssueCreate(IssueBase):
    pass


class IssueRead(IssueBase):
    id: uuid.UUID
    project_id: uuid.UUID
    raised_at: datetime
    resolved_at: datetime | None

    model_config = {"from_attributes": True}


class HistorySnapshotRead(BaseModel):
    id: uuid.UUID
    project_id: uuid.UUID
    snapshot_date: date
    lifecycle_stage: str
    rag: str
    schedule_variance_days: int | None
    budget_variance_pct: Decimal | None
    realized_value_amount: Decimal | None

    model_config = {"from_attributes": True}


class ProjectBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    ai_pattern: AIPattern | None = None
    foundation_model: str | None = None
    data_sensitivity: Literal["public", "internal", "confidential", "restricted"] | None = None
    model_risk_tier: Literal["tier1", "tier2", "tier3"] | None = None
    responsible_ai_status: str | None = None
    dpia_status: str | None = None
    lifecycle_stage: LifecycleStage = "ideation"
    rag_status: RAGStatus = "green"
    sponsoring_function_id: uuid.UUID | None = None
    sponsoring_bu_id: uuid.UUID | None = None
    delivering_team: str | None = None
    product_owner_user_id: uuid.UUID | None = None
    tech_lead_user_id: uuid.UUID | None = None
    business_sponsor_user_id: uuid.UUID | None = None
    start_date: date | None = None
    baseline_end_date: date | None = None
    forecast_end_date: date | None = None
    actual_end_date: date | None = None
    baseline_budget: Decimal | None = None
    actual_spend: Decimal | None = None
    expected_value_amount: Decimal | None = None
    expected_value_unit: str | None = None
    expected_value_currency: str | None = "USD"
    realized_value_amount: Decimal | None = None
    source: str | None = None
    jira_project_key: str | None = None


class ProjectCreate(ProjectBase):
    slug: str | None = None  # auto-generated if omitted


class ProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    ai_pattern: AIPattern | None = None
    foundation_model: str | None = None
    data_sensitivity: str | None = None
    model_risk_tier: str | None = None
    responsible_ai_status: str | None = None
    dpia_status: str | None = None
    rag_status: RAGStatus | None = None
    sponsoring_function_id: uuid.UUID | None = None
    sponsoring_bu_id: uuid.UUID | None = None
    delivering_team: str | None = None
    product_owner_user_id: uuid.UUID | None = None
    tech_lead_user_id: uuid.UUID | None = None
    business_sponsor_user_id: uuid.UUID | None = None
    start_date: date | None = None
    baseline_end_date: date | None = None
    forecast_end_date: date | None = None
    actual_end_date: date | None = None
    baseline_budget: Decimal | None = None
    actual_spend: Decimal | None = None
    expected_value_amount: Decimal | None = None
    expected_value_unit: str | None = None
    expected_value_currency: str | None = None
    realized_value_amount: Decimal | None = None
    jira_project_key: str | None = None


class ProjectRead(ProjectBase):
    id: uuid.UUID
    org_id: uuid.UUID
    slug: str
    status: str
    realized_value_last_measured_at: datetime | None = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class AdvanceStageRequest(BaseModel):
    target_stage: LifecycleStage
    notes: str | None = None
    override_checklist: bool = False


class RAGOverrideRequest(BaseModel):
    rag_status: RAGStatus
    reason: str = Field(..., min_length=5)


class ProjectFilters(BaseModel):
    bu: uuid.UUID | None = None
    function: uuid.UUID | None = None
    stage: LifecycleStage | None = None
    rag: RAGStatus | None = None
    pattern: AIPattern | None = None
    source: str | None = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=25, ge=1, le=100)
