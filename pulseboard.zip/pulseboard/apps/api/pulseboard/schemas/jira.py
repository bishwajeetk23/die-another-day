"""Jira integration Pydantic schemas."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import AnyHttpUrl, BaseModel, Field


AuthType = Literal["api_token", "oauth2", "pat"]


class JiraInstanceCreate(BaseModel):
    base_url: str = Field(..., description="Base URL of the Jira instance, e.g. https://company.atlassian.net")
    auth_type: AuthType
    secret_ref: str = Field(..., description="Secret Manager path or env var name for credentials")


class JiraInstanceRead(BaseModel):
    id: uuid.UUID
    org_id: uuid.UUID
    base_url: str
    auth_type: AuthType
    status: str
    last_sync_at: datetime | None

    model_config = {"from_attributes": True}


class JiraInstanceTestResult(BaseModel):
    success: bool
    message: str
    server_info: dict | None = None


class JiraProjectInfo(BaseModel):
    key: str
    name: str
    project_type: str | None = None
    lead: str | None = None


class JiraLinkCreate(BaseModel):
    jira_instance_id: uuid.UUID
    jira_project_key: str
    ai_project_id: uuid.UUID
    sync_enabled: bool = True


class JiraLinkRead(BaseModel):
    id: uuid.UUID
    jira_instance_id: uuid.UUID
    jira_project_key: str
    ai_project_id: uuid.UUID
    sync_enabled: bool

    model_config = {"from_attributes": True}


class JiraSyncRequest(BaseModel):
    jira_instance_id: uuid.UUID | None = None  # None = sync all
    force: bool = False


class JiraSyncResult(BaseModel):
    synced_instances: int
    synced_tickets: int
    errors: list[str] = Field(default_factory=list)
