"""Adoption KPI Pydantic schemas."""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal
from typing import Any, Literal

from pydantic import BaseModel, Field


KPICategory = Literal["adoption", "quality", "efficiency", "value", "risk"]
MetricType = Literal["count", "rate", "ratio", "score", "duration", "currency", "percent"]
TargetDirection = Literal["up", "down", "maintain"]
IngestionMode = Literal["push", "pull", "manual"]


class KPIBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    slug: str | None = None
    description: str | None = None
    kpi_category: KPICategory
    metric_type: MetricType
    unit: str | None = None
    target_value: Decimal | None = None
    target_direction: TargetDirection = "up"
    ingestion_mode: IngestionMode = "push"
    schedule_cron: str | None = None
    source_config_json: dict[str, Any] | None = None


class KPICreate(KPIBase):
    ai_project_id: uuid.UUID


class KPIRead(KPIBase):
    id: uuid.UUID
    ai_project_id: uuid.UUID
    slug: str
    created_by: uuid.UUID | None
    created_at: datetime

    model_config = {"from_attributes": True}


class KPIValueIngest(BaseModel):
    ts: datetime
    value: Decimal
    dimensions: dict[str, Any] | None = None


class KPIValueRead(BaseModel):
    id: uuid.UUID
    kpi_id: uuid.UUID
    ts: datetime
    value: Decimal
    dimensions_json: dict[str, Any] | None

    model_config = {"from_attributes": True}


class KPIPipelineStatusRead(BaseModel):
    id: uuid.UUID
    kpi_id: uuid.UUID
    pipeline_type: str
    status: str
    last_run_at: datetime | None
    last_error: str | None

    model_config = {"from_attributes": True}
