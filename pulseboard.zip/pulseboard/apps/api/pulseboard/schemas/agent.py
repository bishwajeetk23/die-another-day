"""Agent conversation Pydantic schemas."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str  # user | assistant | tool
    content: str | None = None
    tool_calls: list[dict[str, Any]] | None = None
    citations: list[dict[str, Any]] | None = None


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=10000)
    conversation_id: uuid.UUID | None = None


class ConversationRead(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    title: str | None
    created_at: datetime
    message_count: int = 0

    model_config = {"from_attributes": True}


class ConversationDetail(ConversationRead):
    messages: list[ChatMessageRead] = Field(default_factory=list)


class ChatMessageRead(BaseModel):
    id: uuid.UUID
    conversation_id: uuid.UUID
    role: str
    content: str | None
    tool_calls_json: list[dict[str, Any]] | None
    citations_json: list[dict[str, Any]] | None
    created_at: datetime

    model_config = {"from_attributes": True}


class Citation(BaseModel):
    """A traceable citation to a data source."""
    type: str  # project | kpi | jira_ticket | risk
    id: str  # project_id, kpi_id+timestamp, ticket_key, risk_id
    label: str
    value: Any | None = None
    ts: datetime | None = None


class StreamEvent(BaseModel):
    """Server-sent event payload."""
    event: str  # token | tool_call | tool_result | done | error
    data: dict[str, Any]
