"""User-related Pydantic schemas."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field


AppRole = Literal["PulseBoard.Admin", "PulseBoard.Contributor", "PulseBoard.Viewer"]


class UserBase(BaseModel):
    email: EmailStr
    name: str
    job_title: str | None = None
    photo_url: str | None = None


class UserCreate(UserBase):
    entra_object_id: str
    org_id: uuid.UUID
    app_role: AppRole = "PulseBoard.Viewer"


class UserRead(UserBase):
    id: uuid.UUID
    org_id: uuid.UUID
    entra_object_id: str
    manager_entra_id: str | None
    app_role: AppRole
    last_login_at: datetime | None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class UserUpdate(BaseModel):
    name: str | None = None
    job_title: str | None = None
    photo_url: str | None = None


class UserRoleUpdate(BaseModel):
    app_role: AppRole


class TokenClaims(BaseModel):
    """Parsed claims from a validated Entra JWT."""

    sub: str  # Entra object ID
    oid: str  # Object ID (same as sub in v2 tokens)
    email: str | None = Field(default=None, alias="preferred_username")
    name: str | None = None
    tid: str  # Tenant ID
    roles: list[str] = Field(default_factory=list)
    groups: list[str] = Field(default_factory=list)

    model_config = {"populate_by_name": True}

    @property
    def app_role(self) -> AppRole:
        role_priority: list[AppRole] = [
            "PulseBoard.Admin",
            "PulseBoard.Contributor",
            "PulseBoard.Viewer",
        ]
        for role in role_priority:
            if role in self.roles:
                return role
        return "PulseBoard.Viewer"
