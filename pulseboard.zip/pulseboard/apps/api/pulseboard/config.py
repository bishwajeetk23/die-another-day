"""Application configuration using pydantic-settings."""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import AnyHttpUrl, Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # App
    app_name: str = "PulseBoard API"
    app_version: str = "0.1.0"
    environment: Literal["development", "staging", "production"] = "development"
    debug: bool = False
    log_level: str = "INFO"

    # Database
    database_url: str = Field(
        default="postgresql+asyncpg://postgres:postgres@localhost:5432/pulseboard"
    )
    db_pool_size: int = 10
    db_max_overflow: int = 20
    db_pool_timeout: int = 30

    # Microsoft Entra ID (Azure AD)
    entra_tenant_id: str = Field(default="")
    entra_client_id: str = Field(default="")
    entra_client_secret: SecretStr = Field(default=SecretStr(""))
    entra_audience: str = Field(default="")  # API audience (app URI or client_id)

    # Google Cloud / Vertex AI
    vertex_ai_project: str = Field(default="")
    vertex_ai_location: str = Field(default="us-central1")
    gcs_bucket: str = Field(default="pulseboard-uploads")

    # LLM Provider
    llm_provider: Literal["gemini", "gemma"] = "gemini"
    gemini_model: str = "gemini-1.5-pro-002"

    # Redis
    redis_url: str = Field(default="redis://localhost:6379/0")

    # Celery
    celery_broker_url: str = Field(default="redis://localhost:6379/1")
    celery_result_backend: str = Field(default="redis://localhost:6379/2")

    # Rate limiting
    agent_rate_limit_rpm: int = 10  # requests per minute per user

    # JWKS cache TTL (seconds)
    jwks_cache_ttl: int = 3600

    # Secrets backend (for Jira credentials)
    secrets_backend: Literal["env", "gcp_secret_manager"] = "env"
    gcp_project_id: str = Field(default="")

    # CORS
    cors_origins: list[str] = Field(default=["http://localhost:3000", "http://localhost:5173"])

    @property
    def entra_jwks_uri(self) -> str:
        return f"https://login.microsoftonline.com/{self.entra_tenant_id}/discovery/v2.0/keys"

    @property
    def entra_issuer(self) -> str:
        return f"https://login.microsoftonline.com/{self.entra_tenant_id}/v2.0"

    @property
    def is_production(self) -> bool:
        return self.environment == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()
