"""Jira Cloud REST API v3 client."""
from __future__ import annotations

from typing import Any

import httpx

from pulseboard.models.jira import JiraInstance


class JiraClient:
    def __init__(self, instance: JiraInstance) -> None:
        self.base_url = instance.base_url.rstrip("/")
        self.auth_type = instance.auth_type
        self._secret_ref = instance.secret_ref

    def _get_token(self) -> str:
        """Resolve token from secret_ref. In prod, this reads from Secret Manager."""
        # For now, treat secret_ref as the raw token (dev mode)
        return self._secret_ref or ""

    def _auth_headers(self) -> dict[str, str]:
        token = self._get_token()
        if ":" in token:
            # email:api_token — basic auth
            import base64
            encoded = base64.b64encode(token.encode()).decode()
            return {"Authorization": f"Basic {encoded}"}
        # PAT / Bearer
        return {"Authorization": f"Bearer {token}"}

    async def _get(self, path: str, params: dict | None = None) -> Any:
        url = f"{self.base_url}/rest/api/3{path}"
        headers = {**self._auth_headers(), "Accept": "application/json"}
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(url, headers=headers, params=params or {})
            resp.raise_for_status()
            return resp.json()

    async def get_myself(self) -> dict[str, Any]:
        return await self._get("/myself")

    async def list_projects(self) -> list[dict[str, Any]]:
        data = await self._get("/project/search", {"maxResults": 200, "expand": "description"})
        return data.get("values", [])

    async def get_project_issues(
        self,
        project_key: str,
        max_results: int = 100,
        start_at: int = 0,
    ) -> dict[str, Any]:
        jql = f"project = {project_key} ORDER BY updated DESC"
        return await self._get(
            "/search",
            {
                "jql": jql,
                "maxResults": max_results,
                "startAt": start_at,
                "fields": "summary,status,assignee,story_points,sprint,updated,priority",
            },
        )

    async def sync_project(self, project_key: str) -> list[dict[str, Any]]:
        """Fetch all issues for a project key."""
        all_issues: list[dict] = []
        start_at = 0
        while True:
            data = await self.get_project_issues(project_key, max_results=100, start_at=start_at)
            issues = data.get("issues", [])
            all_issues.extend(issues)
            if start_at + len(issues) >= data.get("total", 0):
                break
            start_at += len(issues)
        return all_issues
