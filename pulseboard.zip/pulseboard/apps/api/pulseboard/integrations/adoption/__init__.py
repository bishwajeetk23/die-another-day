# Adoption ingestion
