"""Microsoft Entra ID JWT validation with JWKS caching."""

from __future__ import annotations

import time
from typing import Any

import httpx
from jose import JWTError, jwt
from jose.backends import RSAKey

from pulseboard.config import get_settings

settings = get_settings()

# Simple in-memory JWKS cache: {jwks_uri: (keys_dict, cached_at)}
_jwks_cache: dict[str, tuple[dict[str, Any], float]] = {}


async def _fetch_jwks() -> dict[str, Any]:
    """Fetch JWKS from Entra and cache for jwks_cache_ttl seconds."""
    uri = settings.entra_jwks_uri
    now = time.monotonic()

    if uri in _jwks_cache:
        keys, cached_at = _jwks_cache[uri]
        if now - cached_at < settings.jwks_cache_ttl:
            return keys

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(uri)
        resp.raise_for_status()
        keys = resp.json()

    _jwks_cache[uri] = (keys, now)
    return keys


def _get_kid_from_token(token: str) -> str | None:
    """Peek at JWT header to find kid without verifying signature."""
    try:
        header = jwt.get_unverified_header(token)
        return header.get("kid")
    except JWTError:
        return None


async def validate_entra_token(token: str) -> dict[str, Any]:
    """
    Validate a Microsoft Entra ID JWT.

    Steps:
    1. Fetch JWKS (cached).
    2. Match kid from token header to a key in JWKS.
    3. Validate signature, iss, aud, exp, nbf.
    4. Return decoded claims.

    Raises jose.JWTError on any validation failure.
    """
    jwks = await _fetch_jwks()
    kid = _get_kid_from_token(token)

    # Find the matching public key
    matching_key: dict[str, Any] | None = None
    for key in jwks.get("keys", []):
        if kid is None or key.get("kid") == kid:
            matching_key = key
            break

    if matching_key is None:
        raise JWTError(f"No matching public key found for kid={kid!r}")

    audience = settings.entra_audience or settings.entra_client_id

    claims: dict[str, Any] = jwt.decode(
        token,
        matching_key,
        algorithms=["RS256"],
        audience=audience,
        issuer=settings.entra_issuer,
        options={
            "verify_exp": True,
            "verify_nbf": True,
            "verify_iat": True,
            "verify_aud": True,
            "verify_iss": True,
        },
    )
    return claims


def invalidate_jwks_cache() -> None:
    """Force JWKS cache refresh on next request (useful in tests)."""
    _jwks_cache.clear()
