"""Role-based access control — RBACContext and helper functions."""
from __future__ import annotations

import uuid
from typing import TYPE_CHECKING

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

if TYPE_CHECKING:
    from pulseboard.models.project import AIProject
    from pulseboard.models.user import User

# Role hierarchy — higher = more privilege
ROLE_LEVEL: dict[str, int] = {
    "PulseBoard.Viewer": 0,
    "PulseBoard.Contributor": 1,
    "PulseBoard.Admin": 2,
}


class AppRole:
    admin = "PulseBoard.Admin"
    contributor = "PulseBoard.Contributor"
    viewer = "PulseBoard.Viewer"


class RBACContext:
    """Built once per request — holds the user's accessible BU/function IDs."""

    def __init__(
        self,
        user: "User",
        accessible_bu_ids: list[uuid.UUID],
        accessible_function_ids: list[uuid.UUID],
    ) -> None:
        self.user = user
        self.accessible_bu_ids = accessible_bu_ids
        self.accessible_function_ids = accessible_function_ids

    @property
    def is_admin(self) -> bool:
        return self.user.app_role == AppRole.admin

    @property
    def is_contributor_or_above(self) -> bool:
        return ROLE_LEVEL.get(self.user.app_role, 0) >= ROLE_LEVEL[AppRole.contributor]

    def can_access_project(self, project: "AIProject") -> bool:
        if self.is_admin:
            return True
        if not self.accessible_bu_ids and not self.accessible_function_ids:
            return True  # No restrictions for viewers without group mapping
        bu_ok = project.sponsoring_bu_id in self.accessible_bu_ids if project.sponsoring_bu_id else False
        fn_ok = project.sponsoring_function_id in self.accessible_function_ids if project.sponsoring_function_id else False
        return bu_ok or fn_ok

    @classmethod
    async def from_user(cls, user: "User", db: AsyncSession) -> "RBACContext":
        """Resolve Entra group mappings → accessible BU/function IDs for this user."""
        from pulseboard.models.organization import EntraGroupMapping

        # Admins get everything
        if user.app_role == AppRole.admin:
            return cls(user=user, accessible_bu_ids=[], accessible_function_ids=[])

        # TODO: In production, fetch the user's Entra group memberships via Graph API
        # and look up EntraGroupMapping. For now, allow all (no group mapping configured).
        result = await db.execute(
            select(EntraGroupMapping).where(EntraGroupMapping.org_id == user.org_id)
        )
        mappings = result.scalars().all()

        bu_ids: list[uuid.UUID] = []
        fn_ids: list[uuid.UUID] = []
        for m in mappings:
            if m.mapped_to_type == "business_unit":
                bu_ids.append(m.mapped_to_id)
            elif m.mapped_to_type == "function":
                fn_ids.append(m.mapped_to_id)

        return cls(user=user, accessible_bu_ids=bu_ids, accessible_function_ids=fn_ids)


def check_role(user: "User", minimum_role: str) -> None:
    user_level = ROLE_LEVEL.get(user.app_role, -1)
    required_level = ROLE_LEVEL.get(minimum_role, 999)
    if user_level < required_level:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Requires role '{minimum_role}', current role is '{user.app_role}'",
        )


def is_admin(user: "User") -> bool:
    return user.app_role == AppRole.admin


def is_contributor_or_above(user: "User") -> bool:
    return ROLE_LEVEL.get(user.app_role, -1) >= ROLE_LEVEL[AppRole.contributor]
