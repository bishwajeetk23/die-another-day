"""FastAPI shared dependencies — auth, DB session, RBAC."""
from __future__ import annotations

from typing import Annotated

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.auth.entra import validate_entra_token
from pulseboard.auth.rbac import AppRole, RBACContext, ROLE_LEVEL
from pulseboard.database import get_session
from pulseboard.models.user import User

_bearer = HTTPBearer(auto_error=False)

# ---------------------------------------------------------------------------
# DB session
# ---------------------------------------------------------------------------
DBSession = Annotated[AsyncSession, Depends(get_session)]


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
async def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
    db: DBSession,
) -> User:
    """Validate Entra JWT and return (or upsert) the caller's User record."""
    if not credentials:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing authorization token")

    token = credentials.credentials
    claims = await validate_entra_token(token)

    from datetime import datetime, timezone
    oid = claims.get("oid") or claims.get("sub")
    if not oid:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token missing oid claim")

    stmt = select(User).where(User.entra_object_id == oid)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    # Auto-provision on first login
    if user is None:
        from pulseboard.models.organization import Organization
        # Find or create org by tenant
        tenant_id = claims.get("tid", "")
        org_result = await db.execute(select(Organization).where(Organization.entra_tenant_id == tenant_id))
        org = org_result.scalar_one_or_none()
        if not org:
            org = Organization(name="My Organization", entra_tenant_id=tenant_id)
            db.add(org)
            await db.flush()

        user = User(
            org_id=org.id,
            entra_object_id=oid,
            email=claims.get("preferred_username") or claims.get("email") or "",
            name=claims.get("name") or "",
            job_title=claims.get("jobTitle") or "",
            app_role=_extract_role(claims),
        )
        db.add(user)
        await db.flush()

    # Update last login
    user.last_login_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(user)
    return user


def _extract_role(claims: dict) -> str:
    roles: list[str] = claims.get("roles", [])
    if AppRole.admin in roles:
        return AppRole.admin
    if AppRole.contributor in roles:
        return AppRole.contributor
    return AppRole.viewer


CurrentUser = Annotated[User, Depends(get_current_user)]


def _require_role_dep(*roles: str):
    async def _check(user: CurrentUser) -> User:
        if user.app_role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires one of: {list(roles)}",
            )
        return user
    return Depends(_check)


RequireAdmin = _require_role_dep(AppRole.admin)
RequireContributor = _require_role_dep(AppRole.admin, AppRole.contributor)


async def get_rbac_context(user: CurrentUser, db: DBSession) -> RBACContext:
    return await RBACContext.from_user(user, db)


RBACCtx = Annotated[RBACContext, Depends(get_rbac_context)]
