"""Self-serve onboarding router — manual uploads, KPI token generation."""
from __future__ import annotations

import uuid
import secrets

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RequireContributor
from pulseboard.models.project import ManualUpload
from pulseboard.schemas.project import ManualUploadRead

router = APIRouter()


@router.post("/upload", response_model=ManualUploadRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def upload_project_tracker(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_session),
) -> ManualUploadRead:
    """Accept CSV/XLSX upload, store in GCS, queue parse job."""
    from pulseboard.config import get_settings
    from pulseboard.services.project_service import ProjectService

    settings = get_settings()
    allowed = {"text/csv", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    if file.content_type not in allowed:
        raise HTTPException(status_code=400, detail="Only CSV and XLSX files are accepted")

    # Upload to GCS
    contents = await file.read()
    gcs_path = f"uploads/{current_user.org_id}/{project_id}/{uuid.uuid4()}/{file.filename}"

    try:
        from google.cloud import storage  # type: ignore
        client = storage.Client()
        bucket = client.bucket(settings.gcs_bucket)
        blob = bucket.blob(gcs_path)
        blob.upload_from_string(contents, content_type=file.content_type)
    except Exception:
        # In dev without GCS, store locally
        gcs_path = f"local://{gcs_path}"

    upload = ManualUpload(
        ai_project_id=project_id,
        uploaded_by=current_user.id,
        file_gcs_path=gcs_path,
        parse_status="pending",
    )
    db.add(upload)
    await db.commit()
    await db.refresh(upload)

    # Queue parse job
    try:
        from pulseboard.worker.tasks import parse_upload_task  # noqa: PLC0415
        parse_upload_task.delay(str(upload.id))
    except Exception:
        pass  # Worker not available in all environments

    return ManualUploadRead.model_validate(upload)


@router.post("/kpi-token/{kpi_id}")
async def generate_kpi_ingest_token(
    kpi_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    """Generate a bearer token for the push-API ingestion endpoint."""
    from sqlalchemy import select
    from pulseboard.models.adoption import AdoptionKPI

    result = await db.execute(select(AdoptionKPI).where(AdoptionKPI.id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail="KPI not found")

    token = secrets.token_urlsafe(32)
    # Store hashed token in source_config_json
    import hashlib
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    config = kpi.source_config_json or {}
    config["ingest_token_hash"] = token_hash
    kpi.source_config_json = config
    await db.commit()

    from pulseboard.config import get_settings
    s = get_settings()
    endpoint = f"/adoption/kpis/{kpi_id}/ingest"

    return {
        "token": token,
        "endpoint": endpoint,
        "curl_example": (
            f'curl -X POST "{endpoint}" \\\n'
            f'  -H "Authorization: Bearer {token}" \\\n'
            f'  -H "Content-Type: application/json" \\\n'
            f'  -d \'{{"ts": "2024-01-15T10:00:00Z", "value": 1234, "dimensions": {{"region": "APAC"}}}}\''
        ),
    }


@router.get("/kpi-starter-library")
async def get_kpi_starter_library() -> list[dict]:
    """Return the built-in KPI library that users can clone."""
    return [
        {"name": "Daily Active Users", "slug": "dau", "category": "usage", "metric_type": "count", "unit": "users", "description": "Unique users who interacted with the AI system today"},
        {"name": "Weekly Active Users", "slug": "wau", "category": "usage", "metric_type": "count", "unit": "users", "description": "Unique users in the last 7 days"},
        {"name": "Invocations per Day", "slug": "invocations_day", "category": "usage", "metric_type": "count", "unit": "calls", "description": "Total AI API calls per day"},
        {"name": "Thumbs-Up Rate", "slug": "thumbs_up_rate", "category": "quality", "metric_type": "percentage", "unit": "%", "description": "% of responses rated positively"},
        {"name": "CSAT Score", "slug": "csat", "category": "quality", "metric_type": "ratio", "unit": "score", "description": "Customer satisfaction score on AI responses (1–5)"},
        {"name": "Escalation-to-Human Rate", "slug": "escalation_rate", "category": "quality", "metric_type": "percentage", "unit": "%", "description": "% of sessions escalated to human agent"},
        {"name": "Eligible → Activated Funnel", "slug": "activation_rate", "category": "funnel", "metric_type": "percentage", "unit": "%", "description": "% of eligible users who have used the AI at least once"},
        {"name": "Activated → Recurring", "slug": "recurring_rate", "category": "funnel", "metric_type": "percentage", "unit": "%", "description": "% of activated users using the AI in 2+ weeks"},
        {"name": "Hours Saved", "slug": "hours_saved", "category": "value_realization", "metric_type": "count", "unit": "hours", "description": "Estimated hours saved vs pre-AI baseline"},
        {"name": "Deflection Rate", "slug": "deflection_rate", "category": "value_realization", "metric_type": "percentage", "unit": "%", "description": "% of queries resolved without human escalation"},
        {"name": "Error Rate", "slug": "error_rate", "category": "health", "metric_type": "percentage", "unit": "%", "description": "% of API calls returning an error"},
        {"name": "P95 Latency", "slug": "p95_latency_ms", "category": "health", "metric_type": "duration", "unit": "ms", "description": "95th percentile response time"},
        {"name": "Cost per 1K Calls", "slug": "cost_per_1k", "category": "health", "metric_type": "currency", "unit": "USD", "description": "LLM + infrastructure cost per 1000 invocations"},
        {"name": "Flagged Response Rate", "slug": "flagged_rate", "category": "trust_safety", "metric_type": "percentage", "unit": "%", "description": "% of responses flagged by safety filters"},
        {"name": "Policy Override Rate", "slug": "override_rate", "category": "trust_safety", "metric_type": "percentage", "unit": "%", "description": "% of safety guardrail overrides by users"},
    ]
