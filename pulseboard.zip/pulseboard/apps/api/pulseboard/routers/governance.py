"""Governance module router — risk tiers, compliance heatmap, sunset candidates."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RBACCtx
from pulseboard.models.project import AIProject

router = APIRouter()


@router.get("/risk-tiers")
async def get_risk_tiers(
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> dict:
    """Return project counts and list grouped by model risk tier."""
    stmt = select(AIProject.model_risk_tier, func.count(AIProject.id)).group_by(AIProject.model_risk_tier)
    result = await db.execute(stmt)
    tiers = {row[0] or "unclassified": row[1] for row in result}

    projects_stmt = select(AIProject).order_by(AIProject.model_risk_tier, AIProject.name)
    projects_result = await db.execute(projects_stmt)
    projects = projects_result.scalars().all()

    by_tier: dict[str, list] = {}
    for p in projects:
        tier = p.model_risk_tier or "unclassified"
        if tier not in by_tier:
            by_tier[tier] = []
        by_tier[tier].append({
            "id": str(p.id),
            "name": p.name,
            "lifecycle_stage": p.lifecycle_stage,
            "rag_status": p.rag_status,
            "responsible_ai_status": p.responsible_ai_status,
            "dpia_status": p.dpia_status,
        })

    return {"summary": tiers, "by_tier": by_tier}


@router.get("/compliance-heatmap")
async def get_compliance_heatmap(
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> list[dict]:
    """Return compliance status for every project across key attestations."""
    stmt = select(AIProject).order_by(AIProject.name)
    result = await db.execute(stmt)
    projects = result.scalars().all()

    heatmap = []
    for p in projects:
        heatmap.append({
            "project_id": str(p.id),
            "project_name": p.name,
            "lifecycle_stage": p.lifecycle_stage,
            "model_risk_tier": p.model_risk_tier,
            "attestations": {
                "responsible_ai": p.responsible_ai_status or "not_started",
                "dpia": p.dpia_status or "not_required",
                "security": "pending",  # Extend with actual security model field
                "legal": "pending",
            },
        })
    return heatmap


@router.get("/sunset-candidates")
async def get_sunset_candidates(
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> list[dict]:
    """Return projects that show sunset signals: declining adoption, status, or stale stage."""
    from sqlalchemy import and_
    from datetime import date, timedelta

    stale_cutoff = date.today() - timedelta(days=180)

    # Projects in production/scale with red RAG or stale forecast dates
    stmt = select(AIProject).where(
        and_(
            AIProject.lifecycle_stage.in_(["production", "scale"]),
            AIProject.rag_status == "red",
        )
    )
    result = await db.execute(stmt)
    red_prod_projects = result.scalars().all()

    candidates = []
    for p in red_prod_projects:
        candidates.append({
            "project_id": str(p.id),
            "name": p.name,
            "lifecycle_stage": p.lifecycle_stage,
            "rag_status": p.rag_status,
            "signal": "red_rag_in_production",
            "last_updated": p.updated_at.isoformat() if p.updated_at else None,
        })
    return candidates
