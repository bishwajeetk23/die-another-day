"""Auth router — login callback, /me, logout."""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser
from pulseboard.models.audit import AuditEvent
from pulseboard.schemas.user import UserRead

router = APIRouter()


@router.get("/me", response_model=UserRead)
async def get_me(current_user: CurrentUser) -> UserRead:
    """Return the authenticated user's profile."""
    return UserRead.model_validate(current_user)


@router.post("/logout")
async def logout(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    """Record logout audit event."""
    event = AuditEvent(
        org_id=current_user.org_id,
        actor_user_id=current_user.id,
        event_type="user.logout",
        target_type="user",
        target_id=str(current_user.id),
        payload_json={},
    )
    db.add(event)
    await db.commit()
    return {"status": "logged_out"}
