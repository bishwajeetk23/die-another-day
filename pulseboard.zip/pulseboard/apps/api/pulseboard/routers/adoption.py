"""Adoption KPI router — CRUD, data ingestion, pipeline status."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RequireContributor, RBACCtx
from pulseboard.models.adoption import AdoptionKPI, AdoptionKPIValue, AdoptionKPIPipeline
from pulseboard.schemas.adoption import (
    KPICreate,
    KPIRead,
    KPIUpdate,
    KPIValueRead,
    KPIIngestPayload,
    PipelineStatusRead,
)
from pulseboard.services.adoption_service import AdoptionService

router = APIRouter()


@router.get("/kpis", response_model=list[KPIRead])
async def list_kpis(
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
    project_id: uuid.UUID | None = Query(None),
    category: str | None = Query(None),
) -> list[KPIRead]:
    svc = AdoptionService(db)
    kpis = await svc.list_kpis(rbac=rbac, project_id=project_id, category=category)
    return [KPIRead.model_validate(k) for k in kpis]


@router.post("/kpis", response_model=KPIRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_kpi(
    payload: KPICreate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> KPIRead:
    svc = AdoptionService(db)
    kpi = await svc.create_kpi(payload, current_user)
    return KPIRead.model_validate(kpi)


@router.get("/kpis/{kpi_id}", response_model=KPIRead)
async def get_kpi(
    kpi_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> KPIRead:
    result = await db.execute(select(AdoptionKPI).where(AdoptionKPI.id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail="KPI not found")
    return KPIRead.model_validate(kpi)


@router.put("/kpis/{kpi_id}", response_model=KPIRead, dependencies=[RequireContributor])
async def update_kpi(
    kpi_id: uuid.UUID,
    payload: KPIUpdate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> KPIRead:
    result = await db.execute(select(AdoptionKPI).where(AdoptionKPI.id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail="KPI not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(kpi, field, value)
    await db.commit()
    await db.refresh(kpi)
    return KPIRead.model_validate(kpi)


@router.get("/kpis/{kpi_id}/values", response_model=list[KPIValueRead])
async def get_kpi_values(
    kpi_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
    days: int = Query(90, ge=1, le=365),
    dimension_filter: str | None = Query(None, description="JSON-encoded dimension filter"),
) -> list[KPIValueRead]:
    from datetime import timedelta
    from sqlalchemy import and_
    since = datetime.now(timezone.utc) - timedelta(days=days)
    stmt = (
        select(AdoptionKPIValue)
        .where(and_(AdoptionKPIValue.kpi_id == kpi_id, AdoptionKPIValue.ts >= since))
        .order_by(AdoptionKPIValue.ts)
    )
    result = await db.execute(stmt)
    return [KPIValueRead.model_validate(v) for v in result.scalars()]


@router.post("/kpis/{kpi_id}/ingest", status_code=status.HTTP_202_ACCEPTED)
async def ingest_kpi_value(
    kpi_id: uuid.UUID,
    payload: KPIIngestPayload,
    db: AsyncSession = Depends(get_session),
    authorization: str | None = None,
) -> dict[str, str]:
    """Push API ingestion endpoint — no user auth, uses KPI bearer token instead."""
    svc = AdoptionService(db)
    # Validate the KPI-specific bearer token
    kpi = await svc.validate_ingest_token(kpi_id, authorization)
    value = AdoptionKPIValue(
        kpi_id=kpi_id,
        ts=payload.ts or datetime.now(timezone.utc),
        value=payload.value,
        dimensions_json=payload.dimensions or {},
    )
    db.add(value)
    await db.commit()
    return {"status": "accepted", "kpi_id": str(kpi_id)}


@router.get("/kpis/{kpi_id}/pipeline-status", response_model=PipelineStatusRead)
async def get_pipeline_status(
    kpi_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> PipelineStatusRead:
    result = await db.execute(
        select(AdoptionKPIPipeline).where(AdoptionKPIPipeline.kpi_id == kpi_id)
    )
    pipeline = result.scalar_one_or_none()
    if not pipeline:
        raise HTTPException(status_code=404, detail="No pipeline configured for this KPI")
    return PipelineStatusRead.model_validate(pipeline)
