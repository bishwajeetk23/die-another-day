"""Admin router — user management, Entra group mappings, org settings."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RequireAdmin
from pulseboard.models.organization import EntraGroupMapping
from pulseboard.models.user import User
from pulseboard.schemas.user import UserRead, UserRoleUpdate

router = APIRouter()


@router.get("/users", response_model=list[UserRead], dependencies=[RequireAdmin])
async def list_users(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> list[UserRead]:
    result = await db.execute(
        select(User).where(User.org_id == current_user.org_id).order_by(User.name)
    )
    return [UserRead.model_validate(u) for u in result.scalars()]


@router.put("/users/{user_id}/role", response_model=UserRead, dependencies=[RequireAdmin])
async def update_user_role(
    user_id: uuid.UUID,
    payload: UserRoleUpdate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> UserRead:
    result = await db.execute(
        select(User).where(User.id == user_id, User.org_id == current_user.org_id)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.app_role = payload.app_role
    await db.commit()
    await db.refresh(user)
    return UserRead.model_validate(user)


@router.get("/entra-groups", dependencies=[RequireAdmin])
async def list_entra_groups(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> list[dict]:
    result = await db.execute(
        select(EntraGroupMapping).where(EntraGroupMapping.org_id == current_user.org_id)
    )
    mappings = result.scalars().all()
    return [
        {
            "id": str(m.id),
            "entra_group_id": m.entra_group_id,
            "mapped_to_type": m.mapped_to_type,
            "mapped_to_id": str(m.mapped_to_id),
        }
        for m in mappings
    ]


@router.post("/entra-group-mappings", status_code=status.HTTP_201_CREATED, dependencies=[RequireAdmin])
async def create_entra_group_mapping(
    entra_group_id: str,
    mapped_to_type: str,
    mapped_to_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> dict:
    mapping = EntraGroupMapping(
        org_id=current_user.org_id,
        entra_group_id=entra_group_id,
        mapped_to_type=mapped_to_type,
        mapped_to_id=mapped_to_id,
    )
    db.add(mapping)
    await db.commit()
    await db.refresh(mapping)
    return {"id": str(mapping.id), "status": "created"}
