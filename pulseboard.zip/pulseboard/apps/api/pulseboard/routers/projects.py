"""AI Projects router — CRUD, milestones, risks, issues, history, stage advance."""
from __future__ import annotations

import uuid
from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RequireContributor, RBACCtx
from pulseboard.models.audit import AuditEvent
from pulseboard.models.project import (
    AIProject,
    AIProjectHistorySnapshot,
    AIProjectIssue,
    AIProjectMilestone,
    AIProjectRisk,
)
from pulseboard.schemas.project import (
    ProjectCreate,
    ProjectHistoryRead,
    ProjectIssueCreate,
    ProjectIssueRead,
    ProjectMilestoneCreate,
    ProjectMilestoneRead,
    ProjectRead,
    ProjectRiskCreate,
    ProjectRiskRead,
    ProjectUpdate,
    RAGOverride,
    StageAdvance,
)
from pulseboard.services.project_service import ProjectService

router = APIRouter()

# ---------------------------------------------------------------------------
# Portfolio
# ---------------------------------------------------------------------------


@router.get("/", response_model=list[ProjectRead])
async def list_projects(
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
    bu_id: uuid.UUID | None = Query(None),
    function_id: uuid.UUID | None = Query(None),
    lifecycle_stage: str | None = Query(None),
    rag_status: str | None = Query(None),
    ai_pattern: str | None = Query(None),
    source: str | None = Query(None),
    search: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
) -> list[ProjectRead]:
    svc = ProjectService(db)
    projects = await svc.list_projects(
        rbac=rbac,
        bu_id=bu_id,
        function_id=function_id,
        lifecycle_stage=lifecycle_stage,
        rag_status=rag_status,
        ai_pattern=ai_pattern,
        source=source,
        search=search,
        page=page,
        page_size=page_size,
    )
    return [ProjectRead.model_validate(p) for p in projects]


@router.post("/", response_model=ProjectRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_project(
    payload: ProjectCreate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> ProjectRead:
    svc = ProjectService(db)
    project = await svc.create_project(payload, current_user)
    await _audit(db, current_user, "project.created", "ai_project", str(project.id), payload.model_dump())
    return ProjectRead.model_validate(project)


# ---------------------------------------------------------------------------
# Single project
# ---------------------------------------------------------------------------


@router.get("/{project_id}", response_model=ProjectRead)
async def get_project(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectRead:
    svc = ProjectService(db)
    project = await svc.get_project_or_404(project_id, rbac)
    return ProjectRead.model_validate(project)


@router.put("/{project_id}", response_model=ProjectRead, dependencies=[RequireContributor])
async def update_project(
    project_id: uuid.UUID,
    payload: ProjectUpdate,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectRead:
    svc = ProjectService(db)
    project = await svc.update_project(project_id, payload, rbac)
    await _audit(db, current_user, "project.updated", "ai_project", str(project_id), payload.model_dump(exclude_unset=True))
    return ProjectRead.model_validate(project)


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[RequireContributor])
async def delete_project(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> None:
    svc = ProjectService(db)
    await svc.delete_project(project_id, rbac)
    await _audit(db, current_user, "project.deleted", "ai_project", str(project_id), {})


# ---------------------------------------------------------------------------
# Stage advance
# ---------------------------------------------------------------------------


@router.post("/{project_id}/advance-stage", response_model=ProjectRead, dependencies=[RequireContributor])
async def advance_stage(
    project_id: uuid.UUID,
    payload: StageAdvance,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectRead:
    svc = ProjectService(db)
    project = await svc.advance_stage(project_id, payload, rbac)
    await _audit(db, current_user, "project.stage_advanced", "ai_project", str(project_id), {"new_stage": payload.target_stage})
    return ProjectRead.model_validate(project)


# ---------------------------------------------------------------------------
# RAG override
# ---------------------------------------------------------------------------


@router.post("/{project_id}/rag-override", response_model=ProjectRead, dependencies=[RequireContributor])
async def rag_override(
    project_id: uuid.UUID,
    payload: RAGOverride,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectRead:
    svc = ProjectService(db)
    project = await svc.rag_override(project_id, payload.rag_status, payload.reason, rbac)
    await _audit(db, current_user, "project.rag_override", "ai_project", str(project_id), payload.model_dump())
    return ProjectRead.model_validate(project)


# ---------------------------------------------------------------------------
# Milestones
# ---------------------------------------------------------------------------


@router.get("/{project_id}/milestones", response_model=list[ProjectMilestoneRead])
async def list_milestones(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> list[ProjectMilestoneRead]:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    result = await db.execute(select(AIProjectMilestone).where(AIProjectMilestone.project_id == project_id))
    return [ProjectMilestoneRead.model_validate(m) for m in result.scalars()]


@router.post("/{project_id}/milestones", response_model=ProjectMilestoneRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_milestone(
    project_id: uuid.UUID,
    payload: ProjectMilestoneCreate,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectMilestoneRead:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    milestone = AIProjectMilestone(project_id=project_id, **payload.model_dump())
    db.add(milestone)
    await db.commit()
    await db.refresh(milestone)
    return ProjectMilestoneRead.model_validate(milestone)


# ---------------------------------------------------------------------------
# Risks
# ---------------------------------------------------------------------------


@router.get("/{project_id}/risks", response_model=list[ProjectRiskRead])
async def list_risks(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> list[ProjectRiskRead]:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    result = await db.execute(select(AIProjectRisk).where(AIProjectRisk.project_id == project_id))
    return [ProjectRiskRead.model_validate(r) for r in result.scalars()]


@router.post("/{project_id}/risks", response_model=ProjectRiskRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_risk(
    project_id: uuid.UUID,
    payload: ProjectRiskCreate,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectRiskRead:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    risk = AIProjectRisk(project_id=project_id, **payload.model_dump())
    db.add(risk)
    await db.commit()
    await db.refresh(risk)
    return ProjectRiskRead.model_validate(risk)


# ---------------------------------------------------------------------------
# Issues
# ---------------------------------------------------------------------------


@router.get("/{project_id}/issues", response_model=list[ProjectIssueRead])
async def list_issues(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> list[ProjectIssueRead]:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    result = await db.execute(select(AIProjectIssue).where(AIProjectIssue.project_id == project_id))
    return [ProjectIssueRead.model_validate(i) for i in result.scalars()]


@router.post("/{project_id}/issues", response_model=ProjectIssueRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_issue(
    project_id: uuid.UUID,
    payload: ProjectIssueCreate,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> ProjectIssueRead:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    issue = AIProjectIssue(project_id=project_id, **payload.model_dump())
    db.add(issue)
    await db.commit()
    await db.refresh(issue)
    return ProjectIssueRead.model_validate(issue)


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------


@router.get("/{project_id}/history", response_model=list[ProjectHistoryRead])
async def list_history(
    project_id: uuid.UUID,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
    days: int = Query(90, ge=7, le=365),
) -> list[ProjectHistoryRead]:
    svc = ProjectService(db)
    await svc.get_project_or_404(project_id, rbac)
    from datetime import datetime, timedelta, timezone
    since = date.today() - timedelta(days=days)
    result = await db.execute(
        select(AIProjectHistorySnapshot)
        .where(
            and_(
                AIProjectHistorySnapshot.project_id == project_id,
                AIProjectHistorySnapshot.snapshot_date >= since,
            )
        )
        .order_by(AIProjectHistorySnapshot.snapshot_date)
    )
    return [ProjectHistoryRead.model_validate(h) for h in result.scalars()]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _audit(
    db: AsyncSession,
    user: CurrentUser,
    event_type: str,
    target_type: str,
    target_id: str,
    payload: dict,
) -> None:
    event = AuditEvent(
        org_id=user.org_id,
        actor_user_id=user.id,
        event_type=event_type,
        target_type=target_type,
        target_id=target_id,
        payload_json=payload,
    )
    db.add(event)
    await db.commit()
