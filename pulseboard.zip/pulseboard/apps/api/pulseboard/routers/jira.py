"""Jira integration router."""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RequireContributor, RBACCtx
from pulseboard.models.jira import JiraInstance, JiraProjectLink
from pulseboard.schemas.jira import (
    JiraInstanceCreate,
    JiraInstanceRead,
    JiraProjectLinkCreate,
    JiraProjectLinkRead,
    JiraProjectListItem,
)
from pulseboard.integrations.jira.client import JiraClient

router = APIRouter()


@router.get("/instances", response_model=list[JiraInstanceRead])
async def list_jira_instances(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> list[JiraInstanceRead]:
    result = await db.execute(select(JiraInstance).where(JiraInstance.org_id == current_user.org_id))
    return [JiraInstanceRead.model_validate(i) for i in result.scalars()]


@router.post("/instances", response_model=JiraInstanceRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_jira_instance(
    payload: JiraInstanceCreate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> JiraInstanceRead:
    instance = JiraInstance(
        org_id=current_user.org_id,
        base_url=str(payload.base_url),
        auth_type=payload.auth_type,
        secret_ref=payload.secret_ref,
        status="pending",
    )
    db.add(instance)
    await db.commit()
    await db.refresh(instance)
    return JiraInstanceRead.model_validate(instance)


@router.post("/instances/{instance_id}/test")
async def test_jira_connection(
    instance_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    result = await db.execute(select(JiraInstance).where(JiraInstance.id == instance_id))
    instance = result.scalar_one_or_none()
    if not instance:
        raise HTTPException(status_code=404, detail="Jira instance not found")

    client = JiraClient(instance)
    try:
        myself = await client.get_myself()
        instance.status = "connected"
        await db.commit()
        return {"status": "connected", "display_name": myself.get("displayName", "")}
    except Exception as exc:
        instance.status = "error"
        await db.commit()
        raise HTTPException(status_code=400, detail=f"Connection failed: {exc}") from exc


@router.get("/instances/{instance_id}/projects", response_model=list[JiraProjectListItem])
async def list_jira_projects(
    instance_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> list[JiraProjectListItem]:
    result = await db.execute(select(JiraInstance).where(JiraInstance.id == instance_id))
    instance = result.scalar_one_or_none()
    if not instance:
        raise HTTPException(status_code=404, detail="Jira instance not found")

    client = JiraClient(instance)
    raw_projects = await client.list_projects()
    return [
        JiraProjectListItem(key=p["key"], name=p["name"], project_type=p.get("projectTypeKey", ""))
        for p in raw_projects
    ]


@router.post("/links", response_model=JiraProjectLinkRead, status_code=status.HTTP_201_CREATED, dependencies=[RequireContributor])
async def create_jira_link(
    payload: JiraProjectLinkCreate,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> JiraProjectLinkRead:
    link = JiraProjectLink(
        jira_instance_id=payload.jira_instance_id,
        jira_project_key=payload.jira_project_key,
        ai_project_id=payload.ai_project_id,
        sync_enabled=True,
    )
    db.add(link)
    await db.commit()
    await db.refresh(link)
    return JiraProjectLinkRead.model_validate(link)


@router.post("/sync")
async def trigger_sync(
    current_user: CurrentUser,
    instance_id: uuid.UUID | None = None,
    db: AsyncSession = Depends(get_session),
) -> dict[str, str]:
    """Trigger an immediate Jira sync (dispatches Celery task)."""
    from pulseboard.worker.tasks import jira_sync_task  # noqa: PLC0415 — lazy import
    jira_sync_task.delay(str(instance_id) if instance_id else None)
    return {"status": "sync_queued"}
