"""AI Agent router — streaming chat, conversation history."""
from __future__ import annotations

import json
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from pulseboard.database import get_session
from pulseboard.dependencies import CurrentUser, RBACCtx
from pulseboard.models.adoption import AdoptionKPI
from pulseboard.models.project import AIProject
from pulseboard.schemas.agent import (
    ChatRequest,
    ConversationRead,
    MessageRead,
)
from pulseboard.agent.orchestrator import AgentOrchestrator
from pulseboard.config import get_settings

router = APIRouter()
settings = get_settings()

# Simple in-memory rate limiter: {user_id: [timestamps]}
_rate_limit_store: dict[str, list[float]] = defaultdict(list)


def _check_rate_limit(user_id: str) -> None:
    now = time.time()
    window = 60.0
    limit = settings.agent_rate_limit_rpm
    timestamps = _rate_limit_store[user_id]
    # Remove old
    _rate_limit_store[user_id] = [t for t in timestamps if now - t < window]
    if len(_rate_limit_store[user_id]) >= limit:
        raise HTTPException(
            status_code=429,
            detail=f"Rate limit exceeded: {limit} requests/minute. Please wait.",
        )
    _rate_limit_store[user_id].append(now)


# ---------------------------------------------------------------------------
# Chat (streaming SSE)
# ---------------------------------------------------------------------------


@router.post("/chat")
async def chat(
    payload: ChatRequest,
    current_user: CurrentUser,
    rbac: RBACCtx,
    db: AsyncSession = Depends(get_session),
) -> StreamingResponse:
    _check_rate_limit(str(current_user.id))

    async def event_stream() -> AsyncGenerator[str, None]:
        orchestrator = AgentOrchestrator(db=db, user=current_user, rbac=rbac)
        async for chunk in orchestrator.run(
            query=payload.message,
            conversation_id=payload.conversation_id,
        ):
            yield f"data: {json.dumps(chunk)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ---------------------------------------------------------------------------
# Conversations
# ---------------------------------------------------------------------------


@router.get("/conversations", response_model=list[ConversationRead])
async def list_conversations(
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> list[ConversationRead]:
    from pulseboard.models.project import AIProject  # avoid circular
    from pulseboard.models.adoption import AdoptionKPI
    from sqlalchemy.orm import selectinload
    from pulseboard.models.user import AIConversation

    result = await db.execute(
        select(AIConversation)
        .where(AIConversation.user_id == current_user.id)
        .order_by(AIConversation.created_at.desc())
        .limit(50)
    )
    return [ConversationRead.model_validate(c) for c in result.scalars()]


@router.get("/conversations/{conversation_id}", response_model=list[MessageRead])
async def get_conversation_messages(
    conversation_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> list[MessageRead]:
    from pulseboard.models.user import AIConversation, AIMessage

    # Verify ownership
    conv_result = await db.execute(
        select(AIConversation).where(
            AIConversation.id == conversation_id,
            AIConversation.user_id == current_user.id,
        )
    )
    conv = conv_result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")

    msg_result = await db.execute(
        select(AIMessage)
        .where(AIMessage.conversation_id == conversation_id)
        .order_by(AIMessage.created_at)
    )
    return [MessageRead.model_validate(m) for m in msg_result.scalars()]


@router.delete("/conversations/{conversation_id}", status_code=204)
async def delete_conversation(
    conversation_id: uuid.UUID,
    current_user: CurrentUser,
    db: AsyncSession = Depends(get_session),
) -> None:
    from pulseboard.models.user import AIConversation

    conv_result = await db.execute(
        select(AIConversation).where(
            AIConversation.id == conversation_id,
            AIConversation.user_id == current_user.id,
        )
    )
    conv = conv_result.scalar_one_or_none()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    await db.delete(conv)
    await db.commit()
