"""Adoption KPI models."""

from __future__ import annotations

import uuid
from datetime import datetime
from decimal import Decimal

from sqlalchemy import DateTime, ForeignKey, JSON, Numeric, String, Text, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from pulseboard.database import Base
from pulseboard.models.base import UUIDMixin


class AdoptionKPI(Base, UUIDMixin):
    __tablename__ = "adoption_kpis"

    ai_project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    kpi_category: Mapped[str] = mapped_column(String(50), nullable=False)
    # adoption | quality | efficiency | value | risk
    metric_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # count | rate | ratio | score | duration | currency | percent
    unit: Mapped[str | None] = mapped_column(String(50), nullable=True)
    target_value: Mapped[Decimal | None] = mapped_column(Numeric(18, 4), nullable=True)
    target_direction: Mapped[str] = mapped_column(String(10), nullable=False, default="up")
    # up | down | maintain
    ingestion_mode: Mapped[str] = mapped_column(String(20), nullable=False, default="push")
    # push | pull | manual
    schedule_cron: Mapped[str | None] = mapped_column(String(100), nullable=True)
    source_config_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_by: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    project: Mapped["AIProject"] = relationship("AIProject", back_populates="adoption_kpis")  # type: ignore[name-defined]  # noqa: F821
    values: Mapped[list["AdoptionKPIValue"]] = relationship(
        "AdoptionKPIValue", back_populates="kpi", cascade="all, delete-orphan"
    )
    pipelines: Mapped[list["AdoptionKPIPipeline"]] = relationship(
        "AdoptionKPIPipeline", back_populates="kpi", cascade="all, delete-orphan"
    )


class AdoptionKPIValue(Base, UUIDMixin):
    __tablename__ = "adoption_kpi_values"

    kpi_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("adoption_kpis.id", ondelete="CASCADE"), nullable=False, index=True
    )
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    value: Mapped[Decimal] = mapped_column(Numeric(18, 4), nullable=False)
    dimensions_json: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    kpi: Mapped[AdoptionKPI] = relationship("AdoptionKPI", back_populates="values")


class AdoptionKPIPipeline(Base, UUIDMixin):
    __tablename__ = "adoption_kpi_pipelines"

    kpi_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("adoption_kpis.id", ondelete="CASCADE"), nullable=False, index=True
    )
    pipeline_type: Mapped[str] = mapped_column(String(50), nullable=False)
    # bigquery | gcs | api | manual
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="idle")
    # idle | running | success | failed
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str | None] = mapped_column(Text, nullable=True)

    kpi: Mapped[AdoptionKPI] = relationship("AdoptionKPI", back_populates="pipelines")
