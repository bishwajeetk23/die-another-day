"""AI Project and related models."""

from __future__ import annotations

import uuid
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Numeric,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from pulseboard.database import Base
from pulseboard.models.base import UUIDMixin, TimestampMixin


class AIProject(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "ai_projects"

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    sponsoring_function_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("functions.id", ondelete="SET NULL"), nullable=True
    )
    sponsoring_bu_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("business_units.id", ondelete="SET NULL"), nullable=True
    )
    delivering_team: Mapped[str | None] = mapped_column(String(255), nullable=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    slug: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    # AI metadata
    ai_pattern: Mapped[str | None] = mapped_column(String(50), nullable=True)
    # predictive_ml | gen_ai | agentic | cv | nlp | recommendation | optimization | rpa_ai
    foundation_model: Mapped[str | None] = mapped_column(String(100), nullable=True)
    data_sensitivity: Mapped[str | None] = mapped_column(String(50), nullable=True)  # public | internal | confidential | restricted
    model_risk_tier: Mapped[str | None] = mapped_column(String(10), nullable=True)  # tier1 | tier2 | tier3
    responsible_ai_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    dpia_status: Mapped[str | None] = mapped_column(String(50), nullable=True)

    # Lifecycle
    lifecycle_stage: Mapped[str] = mapped_column(
        String(50), nullable=False, default="ideation"
    )
    # ideation | qualification | poc | pilot | production | scale | sunset
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="active")
    rag_status: Mapped[str] = mapped_column(String(10), nullable=False, default="green")
    # green | amber | red

    # Ownership
    product_owner_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    tech_lead_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    business_sponsor_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    # Dates
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    baseline_end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    forecast_end_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    actual_end_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    # Financials
    baseline_budget: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)
    actual_spend: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)
    expected_value_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)
    expected_value_unit: Mapped[str | None] = mapped_column(String(50), nullable=True)
    expected_value_currency: Mapped[str | None] = mapped_column(String(3), nullable=True, default="USD")
    realized_value_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)
    realized_value_last_measured_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Source
    source: Mapped[str | None] = mapped_column(String(50), nullable=True)  # manual | jira | api
    jira_project_key: Mapped[str | None] = mapped_column(String(50), nullable=True, index=True)

    # Relationships
    milestones: Mapped[list["AIProjectMilestone"]] = relationship(
        "AIProjectMilestone", back_populates="project", cascade="all, delete-orphan"
    )
    risks: Mapped[list["AIProjectRisk"]] = relationship(
        "AIProjectRisk", back_populates="project", cascade="all, delete-orphan"
    )
    issues: Mapped[list["AIProjectIssue"]] = relationship(
        "AIProjectIssue", back_populates="project", cascade="all, delete-orphan"
    )
    history_snapshots: Mapped[list["AIProjectHistorySnapshot"]] = relationship(
        "AIProjectHistorySnapshot", back_populates="project", cascade="all, delete-orphan"
    )
    adoption_kpis: Mapped[list["AdoptionKPI"]] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "AdoptionKPI", back_populates="project", cascade="all, delete-orphan"
    )
    jira_project_links: Mapped[list["JiraProjectLink"]] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "JiraProjectLink", back_populates="ai_project"
    )
    manual_uploads: Mapped[list["ManualUpload"]] = relationship(  # type: ignore[name-defined]  # noqa: F821
        "ManualUpload", back_populates="ai_project", cascade="all, delete-orphan"
    )


class AIProjectMilestone(Base, UUIDMixin):
    __tablename__ = "ai_project_milestones"

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    baseline_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    forecast_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    actual_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(50), nullable=False, default="pending")
    # pending | in_progress | complete | delayed
    stage_gate: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)

    project: Mapped[AIProject] = relationship("AIProject", back_populates="milestones")


class AIProjectRisk(Base, UUIDMixin):
    __tablename__ = "ai_project_risks"

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    risk_category: Mapped[str | None] = mapped_column(String(50), nullable=True)
    # technical | data | compliance | resourcing | commercial | model_risk
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    # low | medium | high | critical
    likelihood: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    mitigation: Mapped[str | None] = mapped_column(Text, nullable=True)
    owner_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="open")
    # open | mitigated | accepted | closed
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    project: Mapped[AIProject] = relationship("AIProject", back_populates="risks")


class AIProjectIssue(Base, UUIDMixin):
    __tablename__ = "ai_project_issues"

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    severity: Mapped[str] = mapped_column(String(20), nullable=False, default="medium")
    raised_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    owner_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    project: Mapped[AIProject] = relationship("AIProject", back_populates="issues")


class AIProjectHistorySnapshot(Base, UUIDMixin):
    __tablename__ = "ai_project_history_snapshots"

    project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    snapshot_date: Mapped[date] = mapped_column(Date, nullable=False)
    lifecycle_stage: Mapped[str] = mapped_column(String(50), nullable=False)
    rag: Mapped[str] = mapped_column(String(10), nullable=False)
    schedule_variance_days: Mapped[int | None] = mapped_column(nullable=True)
    budget_variance_pct: Mapped[Decimal | None] = mapped_column(Numeric(8, 4), nullable=True)
    realized_value_amount: Mapped[Decimal | None] = mapped_column(Numeric(18, 2), nullable=True)

    project: Mapped[AIProject] = relationship("AIProject", back_populates="history_snapshots")


class ManualUpload(Base, UUIDMixin):
    __tablename__ = "manual_uploads"

    ai_project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    uploaded_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    file_gcs_path: Mapped[str] = mapped_column(String(2048), nullable=False)
    parsed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    parse_status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    # pending | processing | complete | failed
    row_count: Mapped[int | None] = mapped_column(nullable=True)

    ai_project: Mapped[AIProject] = relationship("AIProject", back_populates="manual_uploads")
