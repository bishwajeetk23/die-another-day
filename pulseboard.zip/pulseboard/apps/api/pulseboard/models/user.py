"""User model."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from pulseboard.database import Base
from pulseboard.models.base import UUIDMixin, TimestampMixin


class User(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "users"

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    entra_object_id: Mapped[str] = mapped_column(String(36), nullable=False, unique=True, index=True)
    email: Mapped[str] = mapped_column(String(320), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    job_title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    manager_entra_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    photo_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    # App roles: PulseBoard.Admin | PulseBoard.Contributor | PulseBoard.Viewer
    app_role: Mapped[str] = mapped_column(String(50), nullable=False, default="PulseBoard.Viewer")
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    organization: Mapped["Organization"] = relationship("Organization", back_populates="users")  # type: ignore[name-defined]  # noqa: F821
    conversations: Mapped[list["AIConversation"]] = relationship("AIConversation", back_populates="user", cascade="all, delete-orphan")  # type: ignore[name-defined]  # noqa: F821


class AIConversation(Base, UUIDMixin):
    __tablename__ = "ai_conversations"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    user: Mapped["User"] = relationship("User", back_populates="conversations")
    messages: Mapped[list["AIMessage"]] = relationship("AIMessage", back_populates="conversation", cascade="all, delete-orphan")


class AIMessage(Base, UUIDMixin):
    __tablename__ = "ai_messages"

    conversation_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_conversations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    role: Mapped[str] = mapped_column(String(20), nullable=False)  # user | assistant | tool
    content: Mapped[str] = mapped_column(String(65535), nullable=False, default="")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    from sqlalchemy import JSON
    tool_calls_json: Mapped[list] = mapped_column(JSON, nullable=True, default=list)
    citations_json: Mapped[list] = mapped_column(JSON, nullable=True, default=list)

    conversation: Mapped["AIConversation"] = relationship("AIConversation", back_populates="messages")
