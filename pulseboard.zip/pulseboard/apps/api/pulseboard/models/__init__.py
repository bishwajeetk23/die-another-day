"""ORM models package — import all models so Alembic can discover them."""

from pulseboard.models.organization import Organization, EntraGroupMapping, BusinessUnit, Function
from pulseboard.models.user import User
from pulseboard.models.project import (
    AIProject,
    AIProjectMilestone,
    AIProjectRisk,
    AIProjectIssue,
    AIProjectHistorySnapshot,
    ManualUpload,
)
from pulseboard.models.adoption import AdoptionKPI, AdoptionKPIValue, AdoptionKPIPipeline
from pulseboard.models.jira import JiraInstance, JiraProjectLink, JiraTicketCache
from pulseboard.models.audit import AuditEvent, AIConversation, AIMessage

__all__ = [
    "Organization",
    "EntraGroupMapping",
    "BusinessUnit",
    "Function",
    "User",
    "AIProject",
    "AIProjectMilestone",
    "AIProjectRisk",
    "AIProjectIssue",
    "AIProjectHistorySnapshot",
    "ManualUpload",
    "AdoptionKPI",
    "AdoptionKPIValue",
    "AdoptionKPIPipeline",
    "JiraInstance",
    "JiraProjectLink",
    "JiraTicketCache",
    "AuditEvent",
    "AIConversation",
    "AIMessage",
]
