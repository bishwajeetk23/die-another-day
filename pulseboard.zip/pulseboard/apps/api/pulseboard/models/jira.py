"""Jira integration models."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from pulseboard.database import Base
from pulseboard.models.base import UUIDMixin


class JiraInstance(Base, UUIDMixin):
    __tablename__ = "jira_instances"

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False, index=True
    )
    base_url: Mapped[str] = mapped_column(String(2048), nullable=False)
    auth_type: Mapped[str] = mapped_column(String(20), nullable=False)
    # api_token | oauth2 | pat
    secret_ref: Mapped[str] = mapped_column(String(512), nullable=False)
    # Secret Manager path or env var name
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    # pending | connected | error
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    organization: Mapped["Organization"] = relationship("Organization", back_populates="jira_instances")  # type: ignore[name-defined]  # noqa: F821
    project_links: Mapped[list["JiraProjectLink"]] = relationship(
        "JiraProjectLink", back_populates="jira_instance", cascade="all, delete-orphan"
    )


class JiraProjectLink(Base, UUIDMixin):
    __tablename__ = "jira_project_links"

    jira_instance_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("jira_instances.id", ondelete="CASCADE"), nullable=False, index=True
    )
    jira_project_key: Mapped[str] = mapped_column(String(50), nullable=False)
    ai_project_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_projects.id", ondelete="CASCADE"), nullable=False, index=True
    )
    sync_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    jira_instance: Mapped[JiraInstance] = relationship("JiraInstance", back_populates="project_links")
    ai_project: Mapped["AIProject"] = relationship("AIProject", back_populates="jira_project_links")  # type: ignore[name-defined]  # noqa: F821
    tickets: Mapped[list["JiraTicketCache"]] = relationship(
        "JiraTicketCache", back_populates="project_link", cascade="all, delete-orphan"
    )


class JiraTicketCache(Base, UUIDMixin):
    __tablename__ = "jira_tickets_cache"

    jira_project_link_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("jira_project_links.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    ticket_key: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)
    summary: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    status: Mapped[str | None] = mapped_column(String(100), nullable=True)
    assignee: Mapped[str | None] = mapped_column(String(255), nullable=True)
    story_points: Mapped[float | None] = mapped_column(nullable=True)
    sprint: Mapped[str | None] = mapped_column(String(255), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    project_link: Mapped[JiraProjectLink] = relationship("JiraProjectLink", back_populates="tickets")
