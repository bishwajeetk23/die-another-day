"""Organization, BusinessUnit, Function, and Entra group mapping models."""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from pulseboard.database import Base
from pulseboard.models.base import UUIDMixin


class Organization(Base, UUIDMixin):
    __tablename__ = "organizations"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    entra_tenant_id: Mapped[str] = mapped_column(String(36), nullable=False, unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # Relationships
    users: Mapped[list["User"]] = relationship("User", back_populates="organization")  # type: ignore[name-defined]  # noqa: F821
    business_units: Mapped[list["BusinessUnit"]] = relationship("BusinessUnit", back_populates="organization")
    functions: Mapped[list["Function"]] = relationship("Function", back_populates="organization")
    entra_group_mappings: Mapped[list["EntraGroupMapping"]] = relationship(
        "EntraGroupMapping", back_populates="organization"
    )
    jira_instances: Mapped[list["JiraInstance"]] = relationship("JiraInstance", back_populates="organization")  # type: ignore[name-defined]  # noqa: F821


class EntraGroupMapping(Base, UUIDMixin):
    __tablename__ = "entra_group_mappings"

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    entra_group_id: Mapped[str] = mapped_column(String(36), nullable=False, index=True)
    mapped_to_type: Mapped[str] = mapped_column(String(50), nullable=False)  # "business_unit" | "function"
    mapped_to_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), nullable=False)

    organization: Mapped[Organization] = relationship("Organization", back_populates="entra_group_mappings")


class BusinessUnit(Base, UUIDMixin):
    __tablename__ = "business_units"

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    head_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    organization: Mapped[Organization] = relationship("Organization", back_populates="business_units")
    functions: Mapped[list["Function"]] = relationship("Function", back_populates="business_unit")


class Function(Base, UUIDMixin):
    __tablename__ = "functions"

    org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    head_user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    business_unit_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("business_units.id", ondelete="SET NULL"), nullable=True
    )

    organization: Mapped[Organization] = relationship("Organization", back_populates="functions")
    business_unit: Mapped[BusinessUnit | None] = relationship("BusinessUnit", back_populates="functions")
