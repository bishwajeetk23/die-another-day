"""
Tests for /adoption endpoints — KPI definition and ingestion.
"""
import uuid
from datetime import datetime, timezone

import pytest
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


@pytest.fixture()
async def sample_kpi(authed_client: AsyncClient, sample_project):
    """Create a test KPI and return the response data (includes ingest_token)."""
    response = await authed_client.post(
        "/adoption/kpis",
        json={
            "project_id": str(sample_project.id),
            "name": "Weekly Active Users",
            "category": "usage",
            "unit": "users",
            "target_value": 5000,
            "direction": "higher_is_better",
            "ingestion_mode": "push",
            "dimension_schema": ["region", "department"],
        },
    )
    assert response.status_code == 201
    return response.json()


class TestKPICreate:
    async def test_create_kpi_success(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            "/adoption/kpis",
            json={
                "project_id": str(sample_project.id),
                "name": "CSAT Score",
                "category": "quality",
                "unit": "score (1-5)",
                "target_value": 4.2,
                "direction": "higher_is_better",
                "ingestion_mode": "push",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "CSAT Score"
        assert "id" in data

    async def test_create_kpi_returns_ingest_token(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            "/adoption/kpis",
            json={
                "project_id": str(sample_project.id),
                "name": "Error Rate",
                "category": "health",
                "unit": "%",
                "target_value": 1.0,
                "direction": "lower_is_better",
                "ingestion_mode": "push",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert "ingest_endpoint" in data
        assert "ingest_token" in data
        assert data["ingest_token"].startswith("pb_kpi_")

    async def test_create_kpi_invalid_category(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            "/adoption/kpis",
            json={
                "project_id": str(sample_project.id),
                "name": "Test",
                "category": "invalid_category",
                "unit": "count",
                "target_value": 100,
                "direction": "higher_is_better",
                "ingestion_mode": "push",
            },
        )
        assert response.status_code in (400, 422)

    async def test_create_kpi_invalid_direction(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            "/adoption/kpis",
            json={
                "project_id": str(sample_project.id),
                "name": "Test",
                "category": "usage",
                "unit": "count",
                "target_value": 100,
                "direction": "sideways_is_better",
                "ingestion_mode": "push",
            },
        )
        assert response.status_code in (400, 422)

    async def test_requires_auth(self, client: AsyncClient, sample_project):
        response = await client.post(
            "/adoption/kpis",
            json={
                "project_id": str(sample_project.id),
                "name": "Test",
                "category": "usage",
                "unit": "count",
                "target_value": 100,
                "direction": "higher_is_better",
                "ingestion_mode": "push",
            },
        )
        assert response.status_code in (401, 403)


class TestKPIList:
    async def test_list_kpis(self, authed_client: AsyncClient, sample_kpi):
        response = await authed_client.get("/adoption/kpis")
        assert response.status_code == 200
        data = response.json()
        assert "items" in data
        assert any(k["id"] == sample_kpi["id"] for k in data["items"])

    async def test_filter_by_project(
        self, authed_client: AsyncClient, sample_project, sample_kpi
    ):
        response = await authed_client.get(
            f"/adoption/kpis?project_id={sample_project.id}"
        )
        assert response.status_code == 200
        data = response.json()
        for item in data["items"]:
            assert item["project_id"] == str(sample_project.id)


class TestKPIIngest:
    async def test_ingest_data_point(
        self, client: AsyncClient, sample_kpi
    ):
        """Push a KPI data point using the bearer token."""
        token = sample_kpi["ingest_token"]
        kpi_id = sample_kpi["id"]

        response = await client.post(
            f"/adoption/kpis/{kpi_id}/ingest",
            headers={"Authorization": f"Bearer {token}"},
            json={
                "ts": "2024-04-20T09:00:00Z",
                "value": 4287,
                "dimensions": {"region": "APAC", "department": "HR"},
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert data["kpi_id"] == kpi_id
        assert data["value"] == 4287

    async def test_ingest_invalid_token(
        self, client: AsyncClient, sample_kpi
    ):
        response = await client.post(
            f"/adoption/kpis/{sample_kpi['id']}/ingest",
            headers={"Authorization": "Bearer pb_kpi_wrongtoken"},
            json={
                "ts": "2024-04-20T09:00:00Z",
                "value": 100,
            },
        )
        assert response.status_code == 401

    async def test_ingest_missing_ts(
        self, client: AsyncClient, sample_kpi
    ):
        token = sample_kpi["ingest_token"]
        response = await client.post(
            f"/adoption/kpis/{sample_kpi['id']}/ingest",
            headers={"Authorization": f"Bearer {token}"},
            json={"value": 100},
        )
        assert response.status_code == 422

    async def test_ingest_missing_value(
        self, client: AsyncClient, sample_kpi
    ):
        token = sample_kpi["ingest_token"]
        response = await client.post(
            f"/adoption/kpis/{sample_kpi['id']}/ingest",
            headers={"Authorization": f"Bearer {token}"},
            json={"ts": "2024-04-20T09:00:00Z"},
        )
        assert response.status_code == 422

    async def test_ingest_multiple_points(
        self, client: AsyncClient, sample_kpi
    ):
        """Send multiple data points — all should be accepted."""
        token = sample_kpi["ingest_token"]
        kpi_id = sample_kpi["id"]

        for i in range(5):
            response = await client.post(
                f"/adoption/kpis/{kpi_id}/ingest",
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "ts": f"2024-04-{15 + i:02d}T09:00:00Z",
                    "value": 4000 + (i * 100),
                },
            )
            assert response.status_code == 200


class TestKPIValues:
    async def test_get_values_empty(
        self, authed_client: AsyncClient, sample_kpi, client
    ):
        response = await authed_client.get(
            f"/adoption/kpis/{sample_kpi['id']}/values"
        )
        assert response.status_code == 200
        data = response.json()
        assert "series" in data
        assert "target_value" in data
        assert data["target_value"] == 5000

    async def test_get_values_after_ingest(
        self, authed_client: AsyncClient, client, sample_kpi
    ):
        """Push a data point then verify it appears in /values."""
        token = sample_kpi["ingest_token"]
        kpi_id = sample_kpi["id"]

        await client.post(
            f"/adoption/kpis/{kpi_id}/ingest",
            headers={"Authorization": f"Bearer {token}"},
            json={"ts": "2024-04-20T09:00:00Z", "value": 3500},
        )

        response = await authed_client.get(f"/adoption/kpis/{kpi_id}/values")
        assert response.status_code == 200
        data = response.json()
        assert len(data["series"]) >= 1

    async def test_granularity_parameter(
        self, authed_client: AsyncClient, sample_kpi
    ):
        for gran in ["day", "week"]:
            response = await authed_client.get(
                f"/adoption/kpis/{sample_kpi['id']}/values?granularity={gran}"
            )
            assert response.status_code == 200


class TestStarterLibrary:
    async def test_starter_library(self, authed_client: AsyncClient):
        response = await authed_client.get("/adoption/kpis/starter-library")
        assert response.status_code == 200
        data = response.json()
        assert "templates" in data
        assert len(data["templates"]) > 0

        template = data["templates"][0]
        assert "id" in template
        assert "name" in template
        assert "category" in template
        assert "direction" in template

    async def test_starter_library_has_usage_kpis(self, authed_client: AsyncClient):
        response = await authed_client.get("/adoption/kpis/starter-library")
        data = response.json()
        categories = [t["category"] for t in data["templates"]]
        assert "usage" in categories

    async def test_starter_library_has_quality_kpis(self, authed_client: AsyncClient):
        response = await authed_client.get("/adoption/kpis/starter-library")
        data = response.json()
        categories = [t["category"] for t in data["templates"]]
        assert "quality" in categories
