"""
Tests for /projects endpoints.
"""
import uuid
from unittest.mock import AsyncMock, patch

import pytest
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


class TestHealthEndpoint:
    async def test_health_ok(self, client: AsyncClient):
        response = await client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data


class TestProjectList:
    async def test_requires_auth(self, client: AsyncClient):
        response = await client.get("/projects")
        assert response.status_code in (401, 403)

    async def test_returns_empty_list(self, authed_client: AsyncClient):
        response = await authed_client.get("/projects")
        assert response.status_code == 200
        data = response.json()
        assert "items" in data
        assert isinstance(data["items"], list)
        assert data["total"] >= 0

    async def test_filter_by_stage(self, authed_client: AsyncClient, sample_project):
        response = await authed_client.get("/projects?stage=pilot")
        assert response.status_code == 200
        data = response.json()
        for item in data["items"]:
            assert item["lifecycle_stage"] == "pilot"

    async def test_filter_by_rag(self, authed_client: AsyncClient, sample_project):
        response = await authed_client.get("/projects?rag=green")
        assert response.status_code == 200
        data = response.json()
        for item in data["items"]:
            assert item["rag_status"] == "green"

    async def test_pagination(self, authed_client: AsyncClient):
        response = await authed_client.get("/projects?skip=0&limit=5")
        assert response.status_code == 200
        data = response.json()
        assert len(data["items"]) <= 5

    async def test_search(self, authed_client: AsyncClient, sample_project):
        response = await authed_client.get("/projects?search=HR+Policy")
        assert response.status_code == 200
        data = response.json()
        if data["total"] > 0:
            assert any("HR Policy" in item["name"] for item in data["items"])


class TestProjectCreate:
    async def test_create_project_success(
        self, authed_client: AsyncClient, sample_org
    ):
        payload = {
            "name": "Fraud Detection ML",
            "description": "Real-time fraud scoring",
            "ai_pattern": "predictive_ml",
            "lifecycle_stage": "qualification",
            "model_risk_tier": 1,
            "expected_value_amount": 500000,
            "expected_value_unit": "cost_reduction",
        }
        response = await authed_client.post("/projects", json=payload)
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "Fraud Detection ML"
        assert data["slug"] == "fraud-detection-ml"
        assert data["ai_pattern"] == "predictive_ml"
        assert "id" in data

    async def test_create_project_invalid_pattern(self, authed_client: AsyncClient):
        payload = {
            "name": "Test Project",
            "ai_pattern": "not_a_valid_pattern",
            "lifecycle_stage": "ideation",
            "model_risk_tier": 3,
        }
        response = await authed_client.post("/projects", json=payload)
        assert response.status_code in (400, 422)

    async def test_create_project_invalid_stage(self, authed_client: AsyncClient):
        payload = {
            "name": "Test Project",
            "ai_pattern": "generative_ai",
            "lifecycle_stage": "nonexistent_stage",
            "model_risk_tier": 3,
        }
        response = await authed_client.post("/projects", json=payload)
        assert response.status_code in (400, 422)

    async def test_duplicate_name_different_org(self, authed_client: AsyncClient):
        """Same project name should work for different orgs (slug is org-scoped)."""
        payload = {
            "name": "HR Policy Bot",
            "ai_pattern": "generative_ai",
            "lifecycle_stage": "ideation",
            "model_risk_tier": 3,
        }
        response = await authed_client.post("/projects", json=payload)
        # May succeed (different org) or 409 (same org, slug collision)
        assert response.status_code in (201, 409)


class TestProjectDetail:
    async def test_get_project_by_id(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.get(f"/projects/{sample_project.id}")
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == str(sample_project.id)
        assert data["name"] == sample_project.name

    async def test_get_project_by_slug(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.get(f"/projects/{sample_project.slug}")
        assert response.status_code == 200
        data = response.json()
        assert data["slug"] == sample_project.slug

    async def test_get_nonexistent_project(self, authed_client: AsyncClient):
        fake_id = str(uuid.uuid4())
        response = await authed_client.get(f"/projects/{fake_id}")
        assert response.status_code == 404

    async def test_project_has_milestones_field(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.get(f"/projects/{sample_project.id}")
        data = response.json()
        assert "milestones" in data
        assert isinstance(data["milestones"], list)

    async def test_project_has_risks_field(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.get(f"/projects/{sample_project.id}")
        data = response.json()
        assert "risks" in data
        assert isinstance(data["risks"], list)


class TestProjectUpdate:
    async def test_patch_rag_status(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.patch(
            f"/projects/{sample_project.id}",
            json={"rag_status": "amber"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["rag_status"] == "amber"

    async def test_patch_forecast_date(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.patch(
            f"/projects/{sample_project.id}",
            json={"forecast_end_date": "2025-06-30"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["forecast_end_date"] == "2025-06-30"


class TestStageAdvance:
    async def test_advance_stage(
        self, authed_client: AsyncClient, sample_project
    ):
        """Advance from pilot → production."""
        response = await authed_client.post(
            f"/projects/{sample_project.id}/advance-stage",
            json={"notes": "Stakeholder sign-off received"},
        )
        assert response.status_code == 200
        data = response.json()
        assert data["previous_stage"] == "pilot"
        assert data["new_stage"] == "production"

    async def test_cannot_advance_past_sunset(
        self, authed_client: AsyncClient, db, sample_user, sample_org
    ):
        from pulseboard.models.project import AIProject

        project = AIProject(
            id=uuid.uuid4(),
            org_id=sample_org.id,
            name="Sunsetted Project",
            slug="sunsetted-project",
            ai_pattern="nlp",
            lifecycle_stage="sunset",
            model_risk_tier=3,
            created_by=sample_user.id,
        )
        db.add(project)
        await db.commit()

        response = await authed_client.post(
            f"/projects/{project.id}/advance-stage",
            json={"notes": "Try to advance past sunset"},
        )
        assert response.status_code == 400


class TestRAGOverride:
    async def test_rag_override(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            f"/projects/{sample_project.id}/rag-override",
            json={
                "rag_status": "red",
                "reason": "Key engineer left the project",
            },
        )
        assert response.status_code == 200
        data = response.json()
        assert data["rag_status"] == "red"
        assert data["rag_is_manual"] is True
        assert "Key engineer" in (data["rag_reason"] or "")

    async def test_rag_override_invalid_status(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            f"/projects/{sample_project.id}/rag-override",
            json={"rag_status": "purple"},
        )
        assert response.status_code in (400, 422)


class TestMilestones:
    async def test_create_milestone(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            f"/projects/{sample_project.id}/milestones",
            json={
                "title": "Model training complete",
                "due_date": "2025-03-01",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["title"] == "Model training complete"
        assert "id" in data

    async def test_complete_milestone(
        self, authed_client: AsyncClient, sample_project
    ):
        # Create milestone
        create_resp = await authed_client.post(
            f"/projects/{sample_project.id}/milestones",
            json={"title": "Go-live", "due_date": "2025-04-01"},
        )
        milestone_id = create_resp.json()["id"]

        # Mark complete
        update_resp = await authed_client.patch(
            f"/projects/{sample_project.id}/milestones/{milestone_id}",
            json={"completed_at": "2025-04-01T10:00:00Z"},
        )
        assert update_resp.status_code == 200
        assert update_resp.json()["completed_at"] is not None


class TestRisks:
    async def test_create_risk(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.post(
            f"/projects/{sample_project.id}/risks",
            json={
                "title": "Data quality issues",
                "description": "Source data has inconsistencies",
                "likelihood": "high",
                "impact": "medium",
                "mitigation": "Data cleansing sprint planned",
            },
        )
        assert response.status_code == 201
        data = response.json()
        assert data["title"] == "Data quality issues"
        assert data["status"] == "open"

    async def test_escalate_risk(
        self, authed_client: AsyncClient, sample_project
    ):
        create_resp = await authed_client.post(
            f"/projects/{sample_project.id}/risks",
            json={
                "title": "Vendor dependency",
                "likelihood": "medium",
                "impact": "high",
            },
        )
        risk_id = create_resp.json()["id"]

        update_resp = await authed_client.patch(
            f"/projects/{sample_project.id}/risks/{risk_id}",
            json={"status": "escalated"},
        )
        assert update_resp.status_code == 200
        assert update_resp.json()["status"] == "escalated"


class TestProjectHistory:
    async def test_history_endpoint(
        self, authed_client: AsyncClient, sample_project
    ):
        response = await authed_client.get(
            f"/projects/{sample_project.id}/history?days=30"
        )
        assert response.status_code == 200
        data = response.json()
        assert "snapshots" in data
        assert isinstance(data["snapshots"], list)
