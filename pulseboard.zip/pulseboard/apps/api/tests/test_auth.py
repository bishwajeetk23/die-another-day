"""
Tests for authentication and RBAC middleware.
"""
import uuid
from unittest.mock import AsyncMock, patch

import pytest
from httpx import AsyncClient


pytestmark = pytest.mark.asyncio


class TestAuthRequired:
    """All protected endpoints must reject requests without valid auth."""

    PROTECTED_ENDPOINTS = [
        ("GET", "/projects"),
        ("GET", "/adoption/kpis"),
        ("GET", "/users/me"),
        ("GET", "/governance/summary"),
        ("GET", "/agent/conversations"),
    ]

    @pytest.mark.parametrize("method,path", PROTECTED_ENDPOINTS)
    async def test_no_token_returns_401(
        self, client: AsyncClient, method: str, path: str
    ):
        response = await client.request(method, path)
        assert response.status_code in (401, 403), (
            f"{method} {path} should require auth, got {response.status_code}"
        )

    async def test_invalid_token_returns_401(self, client: AsyncClient):
        response = await client.get(
            "/projects",
            headers={"Authorization": "Bearer not-a-valid-jwt"},
        )
        assert response.status_code in (401, 403)

    async def test_malformed_authorization_header(self, client: AsyncClient):
        response = await client.get(
            "/projects",
            headers={"Authorization": "NotBearer some-token"},
        )
        assert response.status_code in (401, 403)


class TestEntraJWTValidation:
    async def test_valid_token_succeeds(
        self, db, admin_claims
    ):
        """A properly structured Entra JWT should result in 200."""
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from httpx import ASGITransport

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            new_callable=AsyncMock,
            return_value=admin_claims,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer fake-valid-token"},
            ) as ac:
                response = await ac.get("/projects")
                assert response.status_code == 200

        app.dependency_overrides.clear()

    async def test_expired_token_rejected(self, db):
        """A token with past exp should be rejected."""
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from httpx import ASGITransport
        import jwt

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        # Simulate jwt.ExpiredSignatureError being raised
        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            side_effect=Exception("Token is expired"),
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer expired-token"},
            ) as ac:
                response = await ac.get("/projects")
                assert response.status_code in (401, 403)

        app.dependency_overrides.clear()


class TestUserAutoprovisioning:
    async def test_new_user_is_provisioned_on_first_login(
        self, db, admin_claims
    ):
        """First login with a valid Entra token should create the user automatically."""
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from pulseboard.models.user import User
        from sqlalchemy import select
        from httpx import ASGITransport

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        new_oid = str(uuid.uuid4())
        claims = {**admin_claims, "oid": new_oid, "preferred_username": "newuser@test.com"}

        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            new_callable=AsyncMock,
            return_value=claims,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer fake-token"},
            ) as ac:
                response = await ac.get("/users/me")
                assert response.status_code == 200
                data = response.json()
                assert data["email"] == "newuser@test.com"

        # Verify user was persisted
        result = await db.execute(
            select(User).where(User.entra_oid == new_oid)
        )
        user = result.scalar_one_or_none()
        assert user is not None
        assert user.email == "newuser@test.com"

        app.dependency_overrides.clear()


class TestRoleBasedAccess:
    async def _make_client(self, db, claims):
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from httpx import ASGITransport

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            new_callable=AsyncMock,
            return_value=claims,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer fake-token"},
            ) as ac:
                yield ac

        app.dependency_overrides.clear()

    async def test_viewer_can_read_projects(self, db, viewer_claims):
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from httpx import ASGITransport

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            new_callable=AsyncMock,
            return_value=viewer_claims,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer viewer-token"},
            ) as ac:
                response = await ac.get("/projects")
                assert response.status_code == 200

        app.dependency_overrides.clear()

    async def test_viewer_cannot_access_admin_endpoints(self, db, viewer_claims):
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from httpx import ASGITransport

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            new_callable=AsyncMock,
            return_value=viewer_claims,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer viewer-token"},
            ) as ac:
                # Admin-only endpoint
                response = await ac.get("/users")
                assert response.status_code == 403

        app.dependency_overrides.clear()

    async def test_contributor_can_create_projects(
        self, db, contributor_claims, sample_org
    ):
        from pulseboard.main import app
        from pulseboard.dependencies import get_db
        from httpx import ASGITransport

        async def override_get_db():
            yield db

        app.dependency_overrides[get_db] = override_get_db

        with patch(
            "pulseboard.auth.entra.validate_entra_token",
            new_callable=AsyncMock,
            return_value=contributor_claims,
        ):
            async with AsyncClient(
                transport=ASGITransport(app=app),
                base_url="http://test",
                headers={"Authorization": "Bearer contributor-token"},
            ) as ac:
                response = await ac.post(
                    "/projects",
                    json={
                        "name": "Contributor Test Project",
                        "ai_pattern": "generative_ai",
                        "lifecycle_stage": "ideation",
                        "model_risk_tier": 3,
                    },
                )
                # 201 = success, 403 = blocked, both are valid depending on BU mapping
                assert response.status_code in (201, 403)

        app.dependency_overrides.clear()


class TestCurrentUser:
    async def test_get_me_returns_user_profile(self, authed_client: AsyncClient):
        response = await authed_client.get("/users/me")
        assert response.status_code == 200
        data = response.json()
        assert "id" in data
        assert "email" in data
        assert "display_name" in data
        assert "role" in data
        assert data["role"] in (
            "PulseBoard.Admin",
            "PulseBoard.Contributor",
            "PulseBoard.Viewer",
        )
