"""
Pytest configuration and fixtures for PulseBoard API tests.
"""
import asyncio
import uuid
from typing import AsyncGenerator
from unittest.mock import AsyncMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker

from pulseboard.main import app
from pulseboard.models.base import Base
from pulseboard.models.user import User, Organization
from pulseboard.dependencies import get_db

# ──────────────────────────────────────────────
# In-memory SQLite for tests
# ──────────────────────────────────────────────
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

test_engine = create_async_engine(
    TEST_DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False},
)
TestSessionLocal = async_sessionmaker(
    test_engine,
    expire_on_commit=False,
    class_=AsyncSession,
)


@pytest_asyncio.fixture(scope="session")
async def setup_db():
    """Create all tables once per test session."""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture()
async def db(setup_db) -> AsyncGenerator[AsyncSession, None]:
    """Provide a transactional test DB session, rolled back after each test."""
    async with TestSessionLocal() as session:
        yield session


@pytest_asyncio.fixture()
async def client(db: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Async test client with DB override and mocked auth."""
    async def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as ac:
        yield ac

    app.dependency_overrides.clear()


# ──────────────────────────────────────────────
# Auth fixtures
# ──────────────────────────────────────────────
def make_entra_claims(
    role: str = "PulseBoard.Viewer",
    oid: str | None = None,
    tenant: str = "test-tenant-id",
) -> dict:
    """Build a fake Entra JWT claims dict."""
    return {
        "oid": oid or str(uuid.uuid4()),
        "preferred_username": "testuser@company.com",
        "name": "Test User",
        "tid": tenant,
        "roles": [role],
        "groups": [],
        "exp": 9999999999,
        "iat": 1700000000,
        "iss": f"https://login.microsoftonline.com/{tenant}/v2.0",
        "aud": "test-client-id",
    }


@pytest.fixture()
def admin_claims():
    return make_entra_claims(role="PulseBoard.Admin")


@pytest.fixture()
def contributor_claims():
    return make_entra_claims(role="PulseBoard.Contributor")


@pytest.fixture()
def viewer_claims():
    return make_entra_claims(role="PulseBoard.Viewer")


@pytest_asyncio.fixture()
async def authed_client(
    db: AsyncSession,
    admin_claims: dict,
) -> AsyncGenerator[AsyncClient, None]:
    """Test client with admin auth token patched."""
    async def override_get_db():
        yield db

    app.dependency_overrides[get_db] = override_get_db

    with patch(
        "pulseboard.auth.entra.validate_entra_token",
        new_callable=AsyncMock,
        return_value=admin_claims,
    ):
        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
            headers={"Authorization": "Bearer fake-admin-token"},
        ) as ac:
            yield ac

    app.dependency_overrides.clear()


# ──────────────────────────────────────────────
# Seed fixtures
# ──────────────────────────────────────────────
@pytest_asyncio.fixture()
async def sample_org(db: AsyncSession) -> Organization:
    org = Organization(
        id=uuid.uuid4(),
        name="Test Corp",
        slug="test-corp",
        entra_tenant_id="test-tenant-id",
    )
    db.add(org)
    await db.commit()
    await db.refresh(org)
    return org


@pytest_asyncio.fixture()
async def sample_user(db: AsyncSession, sample_org: Organization) -> User:
    from pulseboard.models.user import User

    user = User(
        id=uuid.uuid4(),
        org_id=sample_org.id,
        entra_oid=str(uuid.uuid4()),
        email="admin@test.com",
        display_name="Test Admin",
        role="PulseBoard.Admin",
        entra_group_ids=[],
        is_active=True,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


@pytest_asyncio.fixture()
async def sample_project(db: AsyncSession, sample_org: Organization, sample_user: User):
    from pulseboard.models.project import AIProject

    project = AIProject(
        id=uuid.uuid4(),
        org_id=sample_org.id,
        name="HR Policy Bot",
        slug="hr-policy-bot",
        ai_pattern="generative_ai",
        lifecycle_stage="pilot",
        model_risk_tier=2,
        rag_status="green",
        product_owner_id=sample_user.id,
        created_by=sample_user.id,
    )
    db.add(project)
    await db.commit()
    await db.refresh(project)
    return project
