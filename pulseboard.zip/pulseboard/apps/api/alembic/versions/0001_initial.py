"""Initial PulseBoard schema.

Revision ID: 0001
Revises:
Create Date: 2024-01-01 00:00:00.000000
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # organizations
    op.create_table(
        "organizations",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("entra_tenant_id", sa.String(36), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    # users
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("entra_object_id", sa.String(36), nullable=False),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("job_title", sa.String(255), nullable=True),
        sa.Column("manager_entra_id", sa.String(36), nullable=True),
        sa.Column("photo_url", sa.String(2048), nullable=True),
        sa.Column("app_role", sa.String(50), nullable=False, server_default="PulseBoard.Viewer"),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["org_id"], ["organizations.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("entra_object_id"),
    )
    op.create_index("ix_users_email", "users", ["email"])

    # entra_group_mappings
    op.create_table(
        "entra_group_mappings",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("entra_group_id", sa.String(36), nullable=False),
        sa.Column("mapped_to_type", sa.String(50), nullable=False),
        sa.Column("mapped_to_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.ForeignKeyConstraint(["org_id"], ["organizations.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # business_units
    op.create_table(
        "business_units",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("head_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["org_id"], ["organizations.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # functions
    op.create_table(
        "functions",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("head_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("business_unit_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["org_id"], ["organizations.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["business_unit_id"], ["business_units.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
    )

    # ai_projects
    op.create_table(
        "ai_projects",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("sponsoring_function_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("sponsoring_bu_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("delivering_team", sa.String(255), nullable=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("slug", sa.String(255), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("ai_pattern", sa.String(50), nullable=True),
        sa.Column("foundation_model", sa.String(100), nullable=True),
        sa.Column("data_sensitivity", sa.String(50), nullable=True),
        sa.Column("model_risk_tier", sa.String(10), nullable=True),
        sa.Column("responsible_ai_status", sa.String(50), nullable=True),
        sa.Column("dpia_status", sa.String(50), nullable=True),
        sa.Column("lifecycle_stage", sa.String(50), nullable=False, server_default="ideation"),
        sa.Column("status", sa.String(50), nullable=False, server_default="active"),
        sa.Column("rag_status", sa.String(10), nullable=False, server_default="green"),
        sa.Column("product_owner_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("tech_lead_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("business_sponsor_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("start_date", sa.Date, nullable=True),
        sa.Column("baseline_end_date", sa.Date, nullable=True),
        sa.Column("forecast_end_date", sa.Date, nullable=True),
        sa.Column("actual_end_date", sa.Date, nullable=True),
        sa.Column("baseline_budget", sa.Numeric(18, 2), nullable=True),
        sa.Column("actual_spend", sa.Numeric(18, 2), nullable=True),
        sa.Column("expected_value_amount", sa.Numeric(18, 2), nullable=True),
        sa.Column("expected_value_unit", sa.String(50), nullable=True),
        sa.Column("expected_value_currency", sa.String(3), nullable=True),
        sa.Column("realized_value_amount", sa.Numeric(18, 2), nullable=True),
        sa.Column("realized_value_last_measured_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("source", sa.String(50), nullable=True),
        sa.Column("jira_project_key", sa.String(50), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["org_id"], ["organizations.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["sponsoring_function_id"], ["functions.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["sponsoring_bu_id"], ["business_units.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["product_owner_user_id"], ["users.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["tech_lead_user_id"], ["users.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["business_sponsor_user_id"], ["users.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("slug"),
    )
    op.create_index("ix_ai_projects_org_id", "ai_projects", ["org_id"])
    op.create_index("ix_ai_projects_lifecycle_stage", "ai_projects", ["lifecycle_stage"])
    op.create_index("ix_ai_projects_rag_status", "ai_projects", ["rag_status"])

    # ai_project_milestones
    op.create_table(
        "ai_project_milestones",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("baseline_date", sa.Date, nullable=True),
        sa.Column("forecast_date", sa.Date, nullable=True),
        sa.Column("actual_date", sa.Date, nullable=True),
        sa.Column("status", sa.String(50), nullable=False, server_default="pending"),
        sa.Column("stage_gate", sa.Boolean, nullable=False, server_default="false"),
        sa.ForeignKeyConstraint(["project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # ai_project_risks
    op.create_table(
        "ai_project_risks",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("risk_category", sa.String(50), nullable=True),
        sa.Column("severity", sa.String(20), nullable=False, server_default="medium"),
        sa.Column("likelihood", sa.String(20), nullable=False, server_default="medium"),
        sa.Column("mitigation", sa.Text, nullable=True),
        sa.Column("owner_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("status", sa.String(20), nullable=False, server_default="open"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_user_id"], ["users.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
    )

    # ai_project_issues
    op.create_table(
        "ai_project_issues",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("severity", sa.String(20), nullable=False, server_default="medium"),
        sa.Column("raised_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("owner_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_user_id"], ["users.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
    )

    # ai_project_history_snapshots
    op.create_table(
        "ai_project_history_snapshots",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("snapshot_date", sa.Date, nullable=False),
        sa.Column("lifecycle_stage", sa.String(50), nullable=False),
        sa.Column("rag", sa.String(10), nullable=False),
        sa.Column("schedule_variance_days", sa.Integer, nullable=True),
        sa.Column("budget_variance_pct", sa.Numeric(8, 4), nullable=True),
        sa.Column("realized_value_amount", sa.Numeric(18, 2), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # jira_instances
    op.create_table(
        "jira_instances",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("base_url", sa.String(2048), nullable=False),
        sa.Column("auth_type", sa.String(50), nullable=False, server_default="basic"),
        sa.Column("secret_ref", sa.String(500), nullable=True),
        sa.Column("status", sa.String(50), nullable=False, server_default="pending"),
        sa.Column("last_sync_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["org_id"], ["organizations.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # jira_project_links
    op.create_table(
        "jira_project_links",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("jira_instance_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("jira_project_key", sa.String(50), nullable=False),
        sa.Column("ai_project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("sync_enabled", sa.Boolean, nullable=False, server_default="true"),
        sa.ForeignKeyConstraint(["jira_instance_id"], ["jira_instances.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["ai_project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # jira_tickets_cache
    op.create_table(
        "jira_tickets_cache",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("jira_project_link_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("ticket_key", sa.String(50), nullable=False),
        sa.Column("summary", sa.String(1024), nullable=True),
        sa.Column("status", sa.String(100), nullable=True),
        sa.Column("assignee", sa.String(255), nullable=True),
        sa.Column("story_points", sa.Numeric(5, 1), nullable=True),
        sa.Column("sprint", sa.String(255), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["jira_project_link_id"], ["jira_project_links.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("jira_project_link_id", "ticket_key"),
    )

    # manual_uploads
    op.create_table(
        "manual_uploads",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("ai_project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("uploaded_by", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("file_gcs_path", sa.String(2048), nullable=False),
        sa.Column("parsed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("parse_status", sa.String(20), nullable=False, server_default="pending"),
        sa.Column("row_count", sa.Integer, nullable=True),
        sa.ForeignKeyConstraint(["ai_project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["uploaded_by"], ["users.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
    )

    # adoption_kpis
    op.create_table(
        "adoption_kpis",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("ai_project_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("slug", sa.String(100), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("kpi_category", sa.String(50), nullable=False),
        sa.Column("metric_type", sa.String(50), nullable=False),
        sa.Column("unit", sa.String(50), nullable=True),
        sa.Column("target_value", sa.Numeric(18, 4), nullable=True),
        sa.Column("target_direction", sa.String(30), nullable=True),
        sa.Column("ingestion_mode", sa.String(30), nullable=False, server_default="api_push"),
        sa.Column("schedule_cron", sa.String(100), nullable=True),
        sa.Column("source_config_json", postgresql.JSONB, nullable=True),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["ai_project_id"], ["ai_projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("ai_project_id", "slug"),
    )

    # adoption_kpi_values
    op.create_table(
        "adoption_kpi_values",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("kpi_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("ts", sa.DateTime(timezone=True), nullable=False),
        sa.Column("value", sa.Numeric(18, 4), nullable=False),
        sa.Column("dimensions_json", postgresql.JSONB, nullable=True),
        sa.ForeignKeyConstraint(["kpi_id"], ["adoption_kpis.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_adoption_kpi_values_kpi_id_ts", "adoption_kpi_values", ["kpi_id", "ts"])

    # adoption_kpi_pipelines
    op.create_table(
        "adoption_kpi_pipelines",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("kpi_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("pipeline_type", sa.String(50), nullable=False),
        sa.Column("status", sa.String(50), nullable=False, server_default="active"),
        sa.Column("last_run_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_error", sa.Text, nullable=True),
        sa.ForeignKeyConstraint(["kpi_id"], ["adoption_kpis.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # ai_conversations
    op.create_table(
        "ai_conversations",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("title", sa.String(255), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # ai_messages
    op.create_table(
        "ai_messages",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("conversation_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("role", sa.String(20), nullable=False),
        sa.Column("content", sa.String(65535), nullable=False, server_default=""),
        sa.Column("tool_calls_json", postgresql.JSONB, nullable=True),
        sa.Column("citations_json", postgresql.JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.ForeignKeyConstraint(["conversation_id"], ["ai_conversations.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )

    # audit_events
    op.create_table(
        "audit_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("org_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("actor_user_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("event_type", sa.String(100), nullable=False),
        sa.Column("target_type", sa.String(100), nullable=True),
        sa.Column("target_id", sa.String(36), nullable=True),
        sa.Column("payload_json", postgresql.JSONB, nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_audit_events_org_id", "audit_events", ["org_id"])
    op.create_index("ix_audit_events_created_at", "audit_events", ["created_at"])


def downgrade() -> None:
    op.drop_table("audit_events")
    op.drop_table("ai_messages")
    op.drop_table("ai_conversations")
    op.drop_table("adoption_kpi_pipelines")
    op.drop_table("adoption_kpi_values")
    op.drop_table("adoption_kpis")
    op.drop_table("manual_uploads")
    op.drop_table("jira_tickets_cache")
    op.drop_table("jira_project_links")
    op.drop_table("jira_instances")
    op.drop_table("ai_project_history_snapshots")
    op.drop_table("ai_project_issues")
    op.drop_table("ai_project_risks")
    op.drop_table("ai_project_milestones")
    op.drop_table("ai_projects")
    op.drop_table("functions")
    op.drop_table("business_units")
    op.drop_table("entra_group_mappings")
    op.drop_table("users")
    op.drop_table("organizations")
