import { type Configuration, LogLevel, type BrowserCacheLocation } from '@azure/msal-browser';

const cacheLocation: BrowserCacheLocation = 'sessionStorage';

export const msalConfig: Configuration = {
  auth: {
    clientId: process.env.NEXT_PUBLIC_AZURE_CLIENT_ID ?? 'YOUR_CLIENT_ID',
    authority: `https://login.microsoftonline.com/${process.env.NEXT_PUBLIC_AZURE_TENANT_ID ?? 'YOUR_TENANT_ID'}`,
    redirectUri: process.env.NEXT_PUBLIC_REDIRECT_URI ?? 'http://localhost:3000',
    postLogoutRedirectUri: '/',
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation,
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      loggerCallback: (level: LogLevel, message: string, containsPii: boolean) => {
        if (containsPii) return;
        if (process.env.NODE_ENV !== 'development') return;
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            break;
          case LogLevel.Warning:
            console.warn(message);
            break;
          case LogLevel.Info:
            console.info(message);
            break;
          case LogLevel.Verbose:
            console.debug(message);
            break;
        }
      },
      logLevel: LogLevel.Warning,
    },
  },
};

export const loginRequest = {
  scopes: [
    'openid',
    'profile',
    'email',
    `api://${process.env.NEXT_PUBLIC_AZURE_CLIENT_ID ?? 'YOUR_CLIENT_ID'}/access_as_user`,
  ],
};

export const graphConfig = {
  graphMeEndpoint: 'https://graph.microsoft.com/v1.0/me',
};
