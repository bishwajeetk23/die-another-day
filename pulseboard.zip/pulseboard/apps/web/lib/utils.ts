import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, formatDistanceToNow, differenceInDays } from 'date-fns';

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date, fmt = 'MMM d, yyyy'): string {
  return format(new Date(date), fmt);
}

export function formatRelative(date: string | Date): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

export function daysUntil(date: string | Date): number {
  return differenceInDays(new Date(date), new Date());
}

export function formatPercent(value: number, decimals = 0): string {
  return `${value.toFixed(decimals)}%`;
}

export function formatNumber(
  value: number,
  opts: Intl.NumberFormatOptions = {}
): string {
  return new Intl.NumberFormat('en-US', opts).format(value);
}

export function formatCurrency(value: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    notation: 'compact',
    maximumFractionDigits: 1,
  }).format(value);
}

export type RAGStatus = 'on-track' | 'at-risk' | 'off-track';

export function ragColor(status: RAGStatus): string {
  switch (status) {
    case 'on-track':
      return '#10B981';
    case 'at-risk':
      return '#F59E0B';
    case 'off-track':
      return '#EF4444';
  }
}

export function ragLabel(status: RAGStatus): string {
  switch (status) {
    case 'on-track':
      return 'On Track';
    case 'at-risk':
      return 'At Risk';
    case 'off-track':
      return 'Off Track';
  }
}

export type AIStage =
  | 'ideation'
  | 'qualification'
  | 'poc'
  | 'pilot'
  | 'production'
  | 'scale'
  | 'sunset';

export const AI_STAGES: AIStage[] = [
  'ideation',
  'qualification',
  'poc',
  'pilot',
  'production',
  'scale',
  'sunset',
];

export const AI_STAGE_LABELS: Record<AIStage, string> = {
  ideation: 'Ideation',
  qualification: 'Qualification',
  poc: 'PoC',
  pilot: 'Pilot',
  production: 'Production',
  scale: 'Scale',
  sunset: 'Sunset',
};

export function stageIndex(stage: AIStage): number {
  return AI_STAGES.indexOf(stage);
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 11);
}

export function truncate(str: string, length: number): string {
  if (str.length <= length) return str;
  return str.slice(0, length) + '…';
}

export function initials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args: Parameters<T>) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

export function groupBy<T>(
  arr: T[],
  key: (item: T) => string
): Record<string, T[]> {
  return arr.reduce(
    (acc, item) => {
      const k = key(item);
      if (!acc[k]) acc[k] = [];
      acc[k].push(item);
      return acc;
    },
    {} as Record<string, T[]>
  );
}
