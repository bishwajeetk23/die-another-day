import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Density = 'compact' | 'comfortable' | 'spacious';
export type ViewMode = 'list' | 'kanban' | 'grid';

interface UIState {
  // Command palette
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;
  toggleCommandPalette: () => void;

  // Density
  density: Density;
  setDensity: (density: Density) => void;

  // View mode (for projects)
  projectViewMode: ViewMode;
  setProjectViewMode: (mode: ViewMode) => void;

  // Sidebar
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleSidebar: () => void;

  // Active conversation
  conversationId: string | null;
  setConversationId: (id: string | null) => void;

  // Reasoning panel visibility
  reasoningPanelOpen: boolean;
  setReasoningPanelOpen: (open: boolean) => void;

  // Notifications
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => void;
  dismissNotification: (id: string) => void;
}

interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message?: string;
  createdAt: string;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      commandPaletteOpen: false,
      setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),
      toggleCommandPalette: () =>
        set((state) => ({ commandPaletteOpen: !state.commandPaletteOpen })),

      density: 'comfortable',
      setDensity: (density) => set({ density }),

      projectViewMode: 'list',
      setProjectViewMode: (projectViewMode) => set({ projectViewMode }),

      sidebarCollapsed: false,
      setSidebarCollapsed: (sidebarCollapsed) => set({ sidebarCollapsed }),
      toggleSidebar: () =>
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),

      conversationId: null,
      setConversationId: (conversationId) => set({ conversationId }),

      reasoningPanelOpen: false,
      setReasoningPanelOpen: (reasoningPanelOpen) => set({ reasoningPanelOpen }),

      notifications: [],
      addNotification: (notification) =>
        set((state) => ({
          notifications: [
            ...state.notifications,
            {
              ...notification,
              id: Math.random().toString(36).substring(2),
              createdAt: new Date().toISOString(),
            },
          ],
        })),
      dismissNotification: (id) =>
        set((state) => ({
          notifications: state.notifications.filter((n) => n.id !== id),
        })),
    }),
    {
      name: 'pulseboard-ui',
      partialize: (state) => ({
        density: state.density,
        projectViewMode: state.projectViewMode,
        sidebarCollapsed: state.sidebarCollapsed,
      }),
    }
  )
);
