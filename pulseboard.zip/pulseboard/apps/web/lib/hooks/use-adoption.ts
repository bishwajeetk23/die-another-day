'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getKPIs,
  getKPI,
  getKPITimeSeries,
  getAdoptionSummary,
  createKPI,
  generatePushEndpoint,
  type KPI,
} from '@/lib/api/adoption';

export function useKPIs(projectId?: string) {
  return useQuery({
    queryKey: ['kpis', { projectId }],
    queryFn: () => getKPIs(projectId),
    staleTime: 30_000,
  });
}

export function useKPI(id: string) {
  return useQuery({
    queryKey: ['kpi', id],
    queryFn: () => getKPI(id),
    enabled: !!id,
    staleTime: 30_000,
  });
}

export function useKPITimeSeries(
  id: string,
  granularity: 'hour' | 'day' | 'week' | 'month' = 'day',
  days = 30
) {
  return useQuery({
    queryKey: ['kpi-timeseries', id, granularity, days],
    queryFn: () => getKPITimeSeries(id, granularity, days),
    enabled: !!id,
    staleTime: 60_000,
  });
}

export function useAdoptionSummary() {
  return useQuery({
    queryKey: ['adoption-summary'],
    queryFn: getAdoptionSummary,
    staleTime: 60_000,
  });
}

export function useCreateKPI() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<KPI>) => createKPI(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['kpis'] });
    },
  });
}

export function useGeneratePushEndpoint(kpiId: string) {
  return useQuery({
    queryKey: ['push-endpoint', kpiId],
    queryFn: () => generatePushEndpoint(kpiId),
    enabled: !!kpiId,
    staleTime: Infinity,
  });
}
