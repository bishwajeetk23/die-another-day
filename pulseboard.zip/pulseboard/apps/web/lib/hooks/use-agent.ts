'use client';

import { useState, useCallback, useRef } from 'react';
import { streamAgentMessage, type ChatMessage, type ToolCall, type Citation } from '@/lib/api/agent';

interface UseAgentOptions {
  conversationId?: string;
  getToken?: () => Promise<string | null>;
}

interface UseAgentReturn {
  messages: ChatMessage[];
  isStreaming: boolean;
  sendMessage: (content: string) => Promise<void>;
  clearMessages: () => void;
  abortStream: () => void;
  streamingContent: string;
  activeToolCalls: ToolCall[];
}

export function useAgent(options: UseAgentOptions = {}): UseAgentReturn {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState('');
  const [activeToolCalls, setActiveToolCalls] = useState<ToolCall[]>([]);
  const abortControllerRef = useRef<AbortController | null>(null);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setStreamingContent('');
    setActiveToolCalls([]);
  }, []);

  const abortStream = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsStreaming(false);
      setStreamingContent('');
    }
  }, []);

  const sendMessage = useCallback(
    async (content: string) => {
      if (isStreaming) return;

      const userMessage: ChatMessage = {
        id: 'msg-' + Date.now(),
        role: 'user',
        content,
        createdAt: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, userMessage]);
      setIsStreaming(true);
      setStreamingContent('');
      setActiveToolCalls([]);

      const citations: Citation[] = [];
      const toolCalls: ToolCall[] = [];
      let accumulatedContent = '';

      try {
        const token = options.getToken ? await options.getToken() : undefined;

        const controller = await streamAgentMessage(
          content,
          {
            conversationId: options.conversationId,
            onDelta: (delta) => {
              accumulatedContent += delta;
              setStreamingContent(accumulatedContent);
            },
            onToolCall: (toolCall) => {
              toolCalls.push(toolCall);
              setActiveToolCalls([...toolCalls]);
            },
            onCitation: (citation) => {
              citations.push(citation);
            },
            onComplete: (messageId) => {
              const assistantMessage: ChatMessage = {
                id: messageId,
                role: 'assistant',
                content: accumulatedContent,
                citations: citations.length > 0 ? [...citations] : undefined,
                toolCalls: toolCalls.length > 0 ? [...toolCalls] : undefined,
                createdAt: new Date().toISOString(),
              };
              setMessages((prev) => [...prev, assistantMessage]);
              setStreamingContent('');
              setActiveToolCalls([]);
              setIsStreaming(false);
            },
            onError: (error) => {
              console.error('Stream error:', error);
              const errorMessage: ChatMessage = {
                id: 'err-' + Date.now(),
                role: 'assistant',
                content: `I encountered an error: ${error}. Please try again.`,
                createdAt: new Date().toISOString(),
              };
              setMessages((prev) => [...prev, errorMessage]);
              setStreamingContent('');
              setIsStreaming(false);
            },
          },
          token ?? undefined
        );

        abortControllerRef.current = controller;
      } catch (err) {
        console.error('Failed to send message:', err);
        setIsStreaming(false);
        setStreamingContent('');
      }
    },
    [isStreaming, options]
  );

  return {
    messages,
    isStreaming,
    sendMessage,
    clearMessages,
    abortStream,
    streamingContent,
    activeToolCalls,
  };
}
