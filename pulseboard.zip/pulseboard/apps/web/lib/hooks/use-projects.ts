'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  getProjects,
  getProject,
  updateProjectStage,
  updateProjectRAG,
  createProject,
  getStageGateChecklist,
  type ProjectFilters,
  type Project,
} from '@/lib/api/projects';
import type { AIStage, RAGStatus } from '@/lib/utils';

export function useProjects(filters?: ProjectFilters) {
  return useQuery({
    queryKey: ['projects', filters],
    queryFn: () => getProjects(filters),
    staleTime: 30_000,
  });
}

export function useProject(id: string) {
  return useQuery({
    queryKey: ['project', id],
    queryFn: () => getProject(id),
    enabled: !!id,
    staleTime: 30_000,
  });
}

export function useUpdateProjectStage() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, stage }: { id: string; stage: AIStage }) =>
      updateProjectStage(id, stage),
    onSuccess: (updated) => {
      qc.setQueryData(['project', updated.id], updated);
      qc.invalidateQueries({ queryKey: ['projects'] });
    },
  });
}

export function useUpdateProjectRAG() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, ragStatus }: { id: string; ragStatus: RAGStatus }) =>
      updateProjectRAG(id, ragStatus),
    onSuccess: (updated) => {
      qc.setQueryData(['project', updated.id], updated);
      qc.invalidateQueries({ queryKey: ['projects'] });
    },
  });
}

export function useCreateProject() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (data: Partial<Project>) => createProject(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['projects'] });
    },
  });
}

export function useStageGateChecklist(projectId: string, stage: AIStage) {
  return useQuery({
    queryKey: ['stage-gate', projectId, stage],
    queryFn: () => getStageGateChecklist(projectId, stage),
    enabled: !!projectId && !!stage,
    staleTime: 60_000,
  });
}
