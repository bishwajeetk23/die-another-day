import { fetchWithAuth, patchWithAuth, postWithAuth } from './client';
import type { AIStage, RAGStatus } from '@/lib/utils';

export interface Project {
  id: string;
  name: string;
  description: string;
  sponsoringFunction: string;
  businessUnit: string;
  aiPattern:
    | 'generative'
    | 'predictive'
    | 'nlp'
    | 'computer-vision'
    | 'recommendation'
    | 'automation';
  owner: {
    id: string;
    name: string;
    email: string;
    avatarUrl?: string;
  };
  stage: AIStage;
  ragStatus: RAGStatus;
  startDate: string;
  targetDate: string;
  actualDate?: string;
  completionPercent: number;
  scheduleVariance: number[]; // 8-week sparkline data
  milestones: Milestone[];
  risks: Risk[];
  jiraProjectKey?: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Milestone {
  id: string;
  name: string;
  baselineDate: string;
  forecastDate: string;
  actualDate?: string;
  status: 'completed' | 'in-progress' | 'upcoming' | 'overdue';
  stageGate: boolean;
}

export interface Risk {
  id: string;
  title: string;
  description: string;
  category:
    | 'technical'
    | 'data'
    | 'adoption'
    | 'compliance'
    | 'resource'
    | 'dependency';
  severity: 'critical' | 'high' | 'medium' | 'low';
  likelihood: 'high' | 'medium' | 'low';
  mitigationPlan?: string;
  owner?: string;
  status: 'open' | 'mitigating' | 'resolved';
  aiGenerated: boolean;
}

export interface StageGateItem {
  id: string;
  label: string;
  required: boolean;
  completed: boolean;
  completedAt?: string;
  completedBy?: string;
}

export interface ProjectFilters {
  businessUnit?: string;
  sponsoringFunction?: string;
  aiPattern?: string;
  stage?: AIStage;
  ragStatus?: RAGStatus;
  search?: string;
  page?: number;
  pageSize?: number;
}

export interface ProjectsResponse {
  data: Project[];
  total: number;
  page: number;
  pageSize: number;
}

// Mock data for development
export const MOCK_PROJECTS: Project[] = [
  {
    id: 'proj-001',
    name: 'Customer Churn Predictor',
    description: 'ML model to identify at-risk customers 90 days before churn event using behavioral signals.',
    sponsoringFunction: 'Customer Success',
    businessUnit: 'Commercial',
    aiPattern: 'predictive',
    owner: { id: 'u1', name: 'Sarah Chen', email: 'sarah@acme.com' },
    stage: 'pilot',
    ragStatus: 'on-track',
    startDate: '2025-01-15',
    targetDate: '2026-06-30',
    completionPercent: 62,
    scheduleVariance: [-2, -1, 0, 1, 0, -1, 2, 1],
    milestones: [],
    risks: [],
    tags: ['ml', 'customer', 'retention'],
    createdAt: '2025-01-15T10:00:00Z',
    updatedAt: '2026-04-28T14:22:00Z',
  },
  {
    id: 'proj-002',
    name: 'Contract Intelligence Suite',
    description: 'LLM-powered contract review, clause extraction, and risk flagging for legal team.',
    sponsoringFunction: 'Legal',
    businessUnit: 'Corporate',
    aiPattern: 'nlp',
    owner: { id: 'u2', name: 'Marcus Webb', email: 'marcus@acme.com' },
    stage: 'production',
    ragStatus: 'on-track',
    startDate: '2024-08-01',
    targetDate: '2025-12-31',
    actualDate: '2026-01-15',
    completionPercent: 95,
    scheduleVariance: [0, 1, 2, 1, 0, 1, 0, 0],
    milestones: [],
    risks: [],
    tags: ['llm', 'legal', 'contracts'],
    createdAt: '2024-08-01T10:00:00Z',
    updatedAt: '2026-04-29T09:10:00Z',
  },
  {
    id: 'proj-003',
    name: 'Supply Chain Demand Forecasting',
    description: 'Real-time demand signal aggregation and AI forecasting for inventory optimization.',
    sponsoringFunction: 'Operations',
    businessUnit: 'Supply Chain',
    aiPattern: 'predictive',
    owner: { id: 'u3', name: 'Priya Nair', email: 'priya@acme.com' },
    stage: 'poc',
    ragStatus: 'at-risk',
    startDate: '2026-01-10',
    targetDate: '2026-08-15',
    completionPercent: 28,
    scheduleVariance: [1, 2, 4, 3, 5, 4, 6, 7],
    milestones: [],
    risks: [],
    tags: ['forecasting', 'supply-chain', 'optimization'],
    createdAt: '2026-01-10T10:00:00Z',
    updatedAt: '2026-04-27T16:45:00Z',
  },
  {
    id: 'proj-004',
    name: 'HR Talent Intelligence',
    description: 'AI matching engine for internal mobility and succession planning using skills graph.',
    sponsoringFunction: 'Human Resources',
    businessUnit: 'Corporate',
    aiPattern: 'recommendation',
    owner: { id: 'u4', name: 'James Okafor', email: 'james@acme.com' },
    stage: 'qualification',
    ragStatus: 'on-track',
    startDate: '2026-03-01',
    targetDate: '2026-12-31',
    completionPercent: 18,
    scheduleVariance: [0, 0, 1, 0, -1, 0, 0, 1],
    milestones: [],
    risks: [],
    tags: ['hr', 'talent', 'recommendation'],
    createdAt: '2026-03-01T10:00:00Z',
    updatedAt: '2026-04-25T11:30:00Z',
  },
  {
    id: 'proj-005',
    name: 'Manufacturing QA Vision',
    description: 'Computer vision defect detection on production line reducing manual QA effort by 70%.',
    sponsoringFunction: 'Manufacturing',
    businessUnit: 'Operations',
    aiPattern: 'computer-vision',
    owner: { id: 'u5', name: 'Elena Vasquez', email: 'elena@acme.com' },
    stage: 'scale',
    ragStatus: 'off-track',
    startDate: '2024-06-01',
    targetDate: '2025-06-30',
    completionPercent: 78,
    scheduleVariance: [3, 5, 6, 8, 7, 9, 11, 10],
    milestones: [],
    risks: [],
    tags: ['cv', 'manufacturing', 'quality'],
    createdAt: '2024-06-01T10:00:00Z',
    updatedAt: '2026-04-30T08:00:00Z',
  },
  {
    id: 'proj-006',
    name: 'Document Processing Automation',
    description: 'Intelligent document processing pipeline for accounts payable, reducing processing time by 80%.',
    sponsoringFunction: 'Finance',
    businessUnit: 'Corporate',
    aiPattern: 'automation',
    owner: { id: 'u6', name: 'Tom Bradley', email: 'tom@acme.com' },
    stage: 'production',
    ragStatus: 'on-track',
    startDate: '2025-04-01',
    targetDate: '2026-03-31',
    actualDate: '2026-03-15',
    completionPercent: 98,
    scheduleVariance: [0, -1, -1, 0, -2, -1, -2, -2],
    milestones: [],
    risks: [],
    tags: ['automation', 'finance', 'ocr'],
    createdAt: '2025-04-01T10:00:00Z',
    updatedAt: '2026-04-29T17:20:00Z',
  },
];

export async function getProjects(filters?: ProjectFilters): Promise<ProjectsResponse> {
  try {
    return await fetchWithAuth<ProjectsResponse>('/projects', { params: filters });
  } catch {
    // Return mock data in development
    const data = MOCK_PROJECTS.filter((p) => {
      if (filters?.ragStatus && p.ragStatus !== filters.ragStatus) return false;
      if (filters?.stage && p.stage !== filters.stage) return false;
      if (filters?.businessUnit && p.businessUnit !== filters.businessUnit) return false;
      if (filters?.search) {
        const s = filters.search.toLowerCase();
        return p.name.toLowerCase().includes(s) || p.description.toLowerCase().includes(s);
      }
      return true;
    });
    return { data, total: data.length, page: 1, pageSize: data.length };
  }
}

export async function getProject(id: string): Promise<Project> {
  try {
    return await fetchWithAuth<Project>(`/projects/${id}`);
  } catch {
    const project = MOCK_PROJECTS.find((p) => p.id === id);
    if (!project) throw new Error(`Project ${id} not found`);
    return project;
  }
}

export async function updateProjectStage(
  id: string,
  stage: AIStage
): Promise<Project> {
  return patchWithAuth<Project>(`/projects/${id}`, { stage });
}

export async function updateProjectRAG(
  id: string,
  ragStatus: RAGStatus
): Promise<Project> {
  return patchWithAuth<Project>(`/projects/${id}`, { ragStatus });
}

export async function createProject(
  data: Partial<Project>
): Promise<Project> {
  return postWithAuth<Project>('/projects', data);
}

export async function getStageGateChecklist(
  projectId: string,
  stage: AIStage
): Promise<StageGateItem[]> {
  try {
    return await fetchWithAuth<StageGateItem[]>(
      `/projects/${projectId}/stage-gate/${stage}`
    );
  } catch {
    // Mock stage gate items
    return [
      { id: '1', label: 'Business case approved by sponsor', required: true, completed: true, completedAt: '2026-04-01' },
      { id: '2', label: 'Data availability confirmed', required: true, completed: true, completedAt: '2026-04-05' },
      { id: '3', label: 'Model performance meets threshold (>85% accuracy)', required: true, completed: false },
      { id: '4', label: 'Security & privacy review complete', required: true, completed: false },
      { id: '5', label: 'Responsible AI assessment submitted', required: true, completed: false },
      { id: '6', label: 'Rollback plan documented', required: false, completed: false },
      { id: '7', label: 'Pilot user group selected', required: true, completed: true, completedAt: '2026-04-10' },
    ];
  }
}
