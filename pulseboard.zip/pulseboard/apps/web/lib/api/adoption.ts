import { fetchWithAuth, postWithAuth } from './client';

export interface KPI {
  id: string;
  name: string;
  description: string;
  category: 'usage' | 'quality' | 'funnel' | 'value' | 'health' | 'trust';
  projectId?: string;
  projectName?: string;
  currentValue: number;
  targetValue: number;
  unit: string;
  direction: 'up' | 'down';
  trend: 'up' | 'down' | 'flat';
  trendPercent: number;
  ingestionMode: 'push' | 'pull' | 'sql' | 'manual';
  lastIngested?: string;
  dimensions?: string[];
  sparkline: number[];
  status: 'on-track' | 'at-risk' | 'off-track';
  createdAt: string;
}

export interface KPIDataPoint {
  timestamp: string;
  value: number;
  dimension?: string;
}

export interface KPITimeSeries {
  kpiId: string;
  granularity: 'hour' | 'day' | 'week' | 'month';
  points: KPIDataPoint[];
}

export interface FunnelStep {
  name: string;
  count: number;
  convertedCount: number;
  conversionRate: number;
}

export interface CohortData {
  cohort: string;
  week0: number;
  week1: number;
  week2: number;
  week4: number;
  week8: number;
  week12: number;
}

export interface AdoptionSummary {
  totalUsers: number;
  activeUsers: number;
  adoptionRate: number;
  weeklyGrowth: number;
  topKPIs: KPI[];
  funnel: FunnelStep[];
  cohorts: CohortData[];
}

// Mock data
export const MOCK_KPIS: KPI[] = [
  {
    id: 'kpi-001',
    name: 'Daily Active Users',
    description: 'Unique users who interact with the AI feature each day',
    category: 'usage',
    projectId: 'proj-001',
    projectName: 'Customer Churn Predictor',
    currentValue: 1247,
    targetValue: 2000,
    unit: 'users',
    direction: 'up',
    trend: 'up',
    trendPercent: 12.4,
    ingestionMode: 'push',
    lastIngested: '2026-04-30T08:00:00Z',
    sparkline: [820, 890, 940, 1020, 1080, 1150, 1190, 1247],
    status: 'on-track',
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'kpi-002',
    name: 'Prediction Accuracy',
    description: 'Model accuracy on held-out validation set',
    category: 'quality',
    projectId: 'proj-001',
    projectName: 'Customer Churn Predictor',
    currentValue: 87.3,
    targetValue: 90,
    unit: '%',
    direction: 'up',
    trend: 'up',
    trendPercent: 2.1,
    ingestionMode: 'sql',
    lastIngested: '2026-04-30T06:00:00Z',
    sparkline: [83, 84.2, 85.1, 85.8, 86.2, 86.9, 87.1, 87.3],
    status: 'at-risk',
    createdAt: '2026-01-01T00:00:00Z',
  },
  {
    id: 'kpi-003',
    name: 'Contracts Reviewed / Week',
    description: 'Volume of contracts processed through the AI review pipeline',
    category: 'usage',
    projectId: 'proj-002',
    projectName: 'Contract Intelligence Suite',
    currentValue: 342,
    targetValue: 400,
    unit: 'contracts',
    direction: 'up',
    trend: 'up',
    trendPercent: 8.2,
    ingestionMode: 'push',
    lastIngested: '2026-04-30T07:30:00Z',
    sparkline: [210, 240, 265, 290, 310, 325, 338, 342],
    status: 'on-track',
    createdAt: '2026-01-15T00:00:00Z',
  },
  {
    id: 'kpi-004',
    name: 'Time Saved (hrs/week)',
    description: 'Estimated attorney hours saved through AI-assisted review',
    category: 'value',
    projectId: 'proj-002',
    projectName: 'Contract Intelligence Suite',
    currentValue: 156,
    targetValue: 200,
    unit: 'hours',
    direction: 'up',
    trend: 'up',
    trendPercent: 15.6,
    ingestionMode: 'sql',
    lastIngested: '2026-04-29T18:00:00Z',
    sparkline: [80, 95, 110, 120, 132, 143, 150, 156],
    status: 'on-track',
    createdAt: '2026-01-15T00:00:00Z',
  },
  {
    id: 'kpi-005',
    name: 'Defect Detection Rate',
    description: 'Percentage of defects detected vs total defects on production line',
    category: 'quality',
    projectId: 'proj-005',
    projectName: 'Manufacturing QA Vision',
    currentValue: 91.2,
    targetValue: 95,
    unit: '%',
    direction: 'up',
    trend: 'flat',
    trendPercent: 0.4,
    ingestionMode: 'push',
    lastIngested: '2026-04-30T09:00:00Z',
    sparkline: [88, 89, 90.2, 90.8, 91.0, 90.9, 91.1, 91.2],
    status: 'at-risk',
    createdAt: '2024-06-01T00:00:00Z',
  },
  {
    id: 'kpi-006',
    name: 'False Positive Rate',
    description: 'Rate of non-defective items flagged as defective',
    category: 'quality',
    projectId: 'proj-005',
    projectName: 'Manufacturing QA Vision',
    currentValue: 3.8,
    targetValue: 2.0,
    unit: '%',
    direction: 'down',
    trend: 'down',
    trendPercent: -12.3,
    ingestionMode: 'push',
    lastIngested: '2026-04-30T09:00:00Z',
    sparkline: [8.2, 7.1, 6.3, 5.8, 5.2, 4.6, 4.1, 3.8],
    status: 'off-track',
    createdAt: '2024-06-01T00:00:00Z',
  },
];

export async function getKPIs(projectId?: string): Promise<KPI[]> {
  try {
    return await fetchWithAuth<KPI[]>('/kpis', { params: { projectId } });
  } catch {
    if (projectId) return MOCK_KPIS.filter((k) => k.projectId === projectId);
    return MOCK_KPIS;
  }
}

export async function getKPI(id: string): Promise<KPI> {
  try {
    return await fetchWithAuth<KPI>(`/kpis/${id}`);
  } catch {
    const kpi = MOCK_KPIS.find((k) => k.id === id);
    if (!kpi) throw new Error(`KPI ${id} not found`);
    return kpi;
  }
}

export async function getKPITimeSeries(
  id: string,
  granularity: 'hour' | 'day' | 'week' | 'month' = 'day',
  days = 30
): Promise<KPITimeSeries> {
  try {
    return await fetchWithAuth<KPITimeSeries>(`/kpis/${id}/timeseries`, {
      params: { granularity, days },
    });
  } catch {
    // Generate mock timeseries
    const kpi = MOCK_KPIS.find((k) => k.id === id);
    const base = kpi?.currentValue ?? 100;
    const points: KPIDataPoint[] = Array.from({ length: days }, (_, i) => ({
      timestamp: new Date(Date.now() - (days - i) * 86400000).toISOString(),
      value: base * (0.8 + 0.2 * Math.random()) + (i * base * 0.003),
    }));
    return { kpiId: id, granularity, points };
  }
}

export async function getAdoptionSummary(): Promise<AdoptionSummary> {
  try {
    return await fetchWithAuth<AdoptionSummary>('/adoption/summary');
  } catch {
    return {
      totalUsers: 4820,
      activeUsers: 2341,
      adoptionRate: 48.6,
      weeklyGrowth: 7.2,
      topKPIs: MOCK_KPIS.slice(0, 4),
      funnel: [
        { name: 'Invited', count: 4820, convertedCount: 4820, conversionRate: 100 },
        { name: 'Activated', count: 3640, convertedCount: 3640, conversionRate: 75.5 },
        { name: 'Active (7d)', count: 2341, convertedCount: 2341, conversionRate: 48.6 },
        { name: 'Power Users', count: 892, convertedCount: 892, conversionRate: 18.5 },
        { name: 'Champions', count: 234, convertedCount: 234, conversionRate: 4.9 },
      ],
      cohorts: [
        { cohort: 'Jan 2026', week0: 100, week1: 82, week2: 74, week4: 65, week8: 58, week12: 52 },
        { cohort: 'Feb 2026', week0: 100, week1: 85, week2: 78, week4: 70, week8: 63, week12: 0 },
        { cohort: 'Mar 2026', week0: 100, week1: 88, week2: 81, week4: 74, week8: 0, week12: 0 },
        { cohort: 'Apr 2026', week0: 100, week1: 87, week2: 0, week4: 0, week8: 0, week12: 0 },
      ],
    };
  }
}

export async function createKPI(data: Partial<KPI>): Promise<KPI> {
  return postWithAuth<KPI>('/kpis', data);
}

export async function generatePushEndpoint(kpiId: string): Promise<{
  endpoint: string;
  token: string;
  curlExample: string;
  pythonExample: string;
}> {
  try {
    return await fetchWithAuth(`/kpis/${kpiId}/push-config`);
  } catch {
    const endpoint = `${process.env.NEXT_PUBLIC_API_URL ?? 'https://api.pulseboard.io'}/ingest/kpis/${kpiId}`;
    const token = `pb_live_${Math.random().toString(36).substring(2, 34)}`;
    return {
      endpoint,
      token,
      curlExample: `curl -X POST "${endpoint}" \\
  -H "Authorization: Bearer ${token}" \\
  -H "Content-Type: application/json" \\
  -d '{"value": 1247, "timestamp": "2026-04-30T12:00:00Z", "dimension": "region:EMEA"}'`,
      pythonExample: `import requests\nimport datetime\n\nURL = "${endpoint}"\nTOKEN = "${token}"\n\ndef ingest(value: float, dimension: str | None = None):\n    payload = {\n        "value": value,\n        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",\n    }\n    if dimension:\n        payload["dimension"] = dimension\n    resp = requests.post(URL, json=payload, headers={"Authorization": f"Bearer {TOKEN}"})\n    resp.raise_for_status()\n    return resp.json()\n\n# Example usage\ningest(1247, dimension="region:EMEA")`,
    };
  }
}
