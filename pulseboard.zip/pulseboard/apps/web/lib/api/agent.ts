export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  citations?: Citation[];
  toolCalls?: ToolCall[];
  createdAt: string;
}

export interface Citation {
  id: string;
  projectName?: string;
  kpiName?: string;
  source: string;
  excerpt: string;
  confidence: number;
}

export interface ToolCall {
  id: string;
  name: string;
  input: Record<string, unknown>;
  output?: string;
  startedAt: string;
  completedAt?: string;
  durationMs?: number;
}

export interface StreamEvent {
  type:
    | 'text_delta'
    | 'tool_call_start'
    | 'tool_call_complete'
    | 'citation'
    | 'error'
    | 'done';
  delta?: string;
  toolCall?: ToolCall;
  citation?: Citation;
  error?: string;
  messageId?: string;
}

export interface AgentStreamOptions {
  conversationId?: string;
  onDelta: (delta: string) => void;
  onToolCall: (toolCall: ToolCall) => void;
  onCitation: (citation: Citation) => void;
  onComplete: (messageId: string) => void;
  onError: (error: string) => void;
}

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000/api';

export async function streamAgentMessage(
  message: string,
  options: AgentStreamOptions,
  token?: string
): Promise<AbortController> {
  const controller = new AbortController();

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'text/event-stream',
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_BASE}/agent/stream`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        message,
        conversationId: options.conversationId,
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    if (!response.body) {
      throw new Error('No response body');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    const processStream = async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() ?? '';

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6).trim();
              if (data === '[DONE]') {
                options.onComplete('msg-' + Date.now());
                return;
              }

              try {
                const event = JSON.parse(data) as StreamEvent;
                switch (event.type) {
                  case 'text_delta':
                    if (event.delta) options.onDelta(event.delta);
                    break;
                  case 'tool_call_start':
                  case 'tool_call_complete':
                    if (event.toolCall) options.onToolCall(event.toolCall);
                    break;
                  case 'citation':
                    if (event.citation) options.onCitation(event.citation);
                    break;
                  case 'error':
                    options.onError(event.error ?? 'Unknown error');
                    break;
                  case 'done':
                    options.onComplete(event.messageId ?? 'msg-' + Date.now());
                    break;
                }
              } catch {
                // Skip malformed JSON
              }
            }
          }
        }
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          options.onError((err as Error).message);
        }
      }
    };

    processStream();
  } catch (err) {
    if ((err as Error).name !== 'AbortError') {
      // Fallback to mock streaming for development
      simulateMockStream(message, options, controller);
    }
  }

  return controller;
}

function simulateMockStream(
  message: string,
  options: AgentStreamOptions,
  controller: AbortController
): void {
  const responses: Record<string, string> = {
    default: `I've analyzed your request across the PulseBoard data. Here's what I found:\n\n**Portfolio Summary**\n\nYou currently have **6 active AI projects** across 4 business units:\n- 2 projects are in Production stage\n- 1 project is Scaling\n- 1 project in Pilot\n- 1 in PoC\n- 1 in Qualification\n\n**RAG Status Overview**\n- ✅ On Track: 4 projects (67%)\n- ⚠️ At Risk: 1 project — Supply Chain Demand Forecasting (+7 days variance)\n- 🔴 Off Track: 1 project — Manufacturing QA Vision (schedule variance trending up)\n\n**Key Insight**: The Manufacturing QA Vision project has shown increasing schedule variance over 8 weeks. Consider scheduling a stage-gate review with Elena Vasquez's team this week.\n\nWould you like me to draft a status update for stakeholders or pull the detailed risk register?`,
    churn: `**Customer Churn Predictor Analysis**\n\nThe model is performing well in Pilot phase:\n- Current accuracy: **87.3%** (target: 90%)\n- Daily Active Users: **1,247** (+12.4% WoW)\n- Schedule variance: 0 days (on track)\n\n**Next Milestone**: Production Go-Live — June 30, 2026\n\n**Stage Gate Status** (Pilot → Production):\n- ✅ Business case approved\n- ✅ Data availability confirmed\n- ✅ Pilot user group selected\n- ⏳ Model performance threshold (87.3% vs 90% target)\n- ⏳ Security & privacy review\n- ⏳ Responsible AI assessment\n\nI recommend prioritizing the security review to avoid blocking the production gate.`,
  };

  const lower = message.toLowerCase();
  const responseText = lower.includes('churn')
    ? responses.churn
    : responses.default;

  // Simulate tool calls
  setTimeout(() => {
    if (controller.signal.aborted) return;
    options.onToolCall({
      id: 'tc-1',
      name: 'query_project_portfolio',
      input: { filters: { status: 'all' } },
      startedAt: new Date().toISOString(),
    });
  }, 200);

  setTimeout(() => {
    if (controller.signal.aborted) return;
    options.onToolCall({
      id: 'tc-1',
      name: 'query_project_portfolio',
      input: { filters: { status: 'all' } },
      output: JSON.stringify({ count: 6, onTrack: 4, atRisk: 1, offTrack: 1 }),
      startedAt: new Date(Date.now() - 300).toISOString(),
      completedAt: new Date().toISOString(),
      durationMs: 312,
    });
  }, 600);

  // Simulate text streaming
  let charIndex = 0;
  const interval = setInterval(() => {
    if (controller.signal.aborted || charIndex >= responseText.length) {
      clearInterval(interval);
      if (!controller.signal.aborted) {
        options.onCitation({
          id: 'cit-1',
          projectName: 'Manufacturing QA Vision',
          source: 'Project Status Report — April 2026',
          excerpt: 'Schedule variance has increased from 3 to 10 days over the last 8 weeks.',
          confidence: 0.94,
        });
        options.onComplete('msg-' + Date.now());
      }
      return;
    }

    const chunkSize = Math.floor(Math.random() * 8) + 3;
    const chunk = responseText.slice(charIndex, charIndex + chunkSize);
    options.onDelta(chunk);
    charIndex += chunkSize;
  }, 25);
}
