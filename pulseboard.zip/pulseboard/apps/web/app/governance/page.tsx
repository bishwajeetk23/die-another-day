"use client";

import { motion } from "framer-motion";
import { Shield, AlertTriangle } from "lucide-react";
import { Shell } from "@/components/layout/shell";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api/client";
import { cn } from "@/lib/utils";

const ATTESTATION_COLORS: Record<string, string> = {
  approved: "bg-emerald-500/10 text-emerald-400",
  in_review: "bg-amber-500/10 text-amber-400",
  not_started: "bg-surface-2 text-muted",
  not_required: "bg-surface-2 text-muted",
  conditional: "bg-orange-500/10 text-orange-400",
  rejected: "bg-red-500/10 text-red-400",
  pending: "bg-blue-500/10 text-blue-400",
  completed: "bg-emerald-500/10 text-emerald-400",
};

export default function GovernancePage() {
  const { data: heatmap = [], isLoading: heatmapLoading } = useQuery({
    queryKey: ["governance", "heatmap"],
    queryFn: () => apiClient.get("/governance/compliance-heatmap").then((r) => r.data),
  });

  const { data: tiers, isLoading: tiersLoading } = useQuery({
    queryKey: ["governance", "risk-tiers"],
    queryFn: () => apiClient.get("/governance/risk-tiers").then((r) => r.data),
  });

  const { data: sunsetCandidates = [], isLoading: sunsetLoading } = useQuery({
    queryKey: ["governance", "sunset"],
    queryFn: () => apiClient.get("/governance/sunset-candidates").then((r) => r.data),
  });

  return (
    <Shell>
      <div className="space-y-6">
        <div>
          <h1 className="text-xl font-semibold text-text-primary">Governance</h1>
          <p className="mt-0.5 text-sm text-muted">
            Model risk tiers, compliance status, and sunset candidates.
          </p>
        </div>

        {/* Risk tier summary */}
        {!tiersLoading && tiers?.summary && (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {Object.entries(tiers.summary).map(([tier, count]) => (
              <motion.div
                key={tier}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-xl border border-border bg-surface p-4"
              >
                <p className="text-xs text-muted capitalize">{tier === "unclassified" ? "Unclassified" : `Model Risk ${tier}`}</p>
                <p className="mt-1 font-mono text-3xl font-semibold tabular-nums text-text-primary">
                  {count as number}
                </p>
              </motion.div>
            ))}
          </div>
        )}

        {/* Compliance heatmap */}
        <div>
          <h2 className="mb-3 text-sm font-semibold text-text-primary">Compliance Heatmap</h2>
          <div className="overflow-x-auto rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-surface-2">
                  <th className="px-4 py-2.5 text-left text-xs font-medium text-muted">Project</th>
                  <th className="px-4 py-2.5 text-left text-xs font-medium text-muted">Stage</th>
                  <th className="px-4 py-2.5 text-center text-xs font-medium text-muted">Responsible AI</th>
                  <th className="px-4 py-2.5 text-center text-xs font-medium text-muted">DPIA</th>
                  <th className="px-4 py-2.5 text-center text-xs font-medium text-muted">Security</th>
                  <th className="px-4 py-2.5 text-center text-xs font-medium text-muted">Legal</th>
                </tr>
              </thead>
              <tbody>
                {heatmapLoading ? (
                  [...Array(5)].map((_, i) => (
                    <tr key={i} className="border-b border-border">
                      <td className="px-4 py-3" colSpan={6}>
                        <div className="h-4 animate-pulse rounded bg-surface-2" />
                      </td>
                    </tr>
                  ))
                ) : (
                  heatmap.map((row: any) => (
                    <tr key={row.project_id} className="border-b border-border hover:bg-surface-2 last:border-0">
                      <td className="px-4 py-3 font-medium text-text-primary">{row.project_name}</td>
                      <td className="px-4 py-3 capitalize text-muted text-xs">{row.lifecycle_stage}</td>
                      {["responsible_ai", "dpia", "security", "legal"].map((key) => (
                        <td key={key} className="px-4 py-3 text-center">
                          <span
                            className={cn(
                              "inline-flex rounded px-2 py-0.5 text-xs font-medium capitalize",
                              ATTESTATION_COLORS[row.attestations[key]] || "bg-surface-2 text-muted"
                            )}
                          >
                            {row.attestations[key]?.replace("_", " ") || "—"}
                          </span>
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Sunset candidates */}
        {sunsetCandidates.length > 0 && (
          <div>
            <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-text-primary">
              <AlertTriangle className="h-4 w-4 text-amber-400" />
              Sunset Candidates
            </h2>
            <div className="space-y-2">
              {sunsetCandidates.map((c: any) => (
                <div key={c.project_id} className="flex items-center gap-4 rounded-lg border border-amber-500/20 bg-amber-500/5 px-4 py-3">
                  <Shield className="h-4 w-4 flex-shrink-0 text-amber-400" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-text-primary">{c.name}</p>
                    <p className="text-xs text-muted capitalize">{c.signal?.replace("_", " ")}</p>
                  </div>
                  <span className="text-xs text-amber-400 capitalize">{c.lifecycle_stage}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Shell>
  );
}
