"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  CheckCircle,
  Circle,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Loader2,
  ArrowLeft,
} from "lucide-react";
import Link from "next/link";

const STEPS = ["Connect", "Select Projects", "Map Fields"];

interface JiraInstance {
  id: string;
  name: string;
  base_url: string;
  sync_status: string;
  connected_as?: string;
}

interface JiraProject {
  key: string;
  name: string;
  project_type_key: string;
  issues_count?: number;
}

const DEFAULT_FIELD_MAP = {
  "Project Name": "Jira Project Name",
  "Product Owner": "Project Lead",
  "Baseline End Date": "Fix Version → Due Date",
  "Lifecycle Stage": 'Labels with "stage:" prefix',
  "AI Pattern": 'Custom field "AI Pattern"',
};

export default function JiraOnboardingPage() {
  const [step, setStep] = useState(0);
  const [instanceForm, setInstanceForm] = useState({
    name: "",
    base_url: "",
    auth_email: "",
    auth_token: "",
  });
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);
  const [savedInstance, setSavedInstance] = useState<JiraInstance | null>(null);
  const [selectedProjects, setSelectedProjects] = useState<string[]>([]);
  const [fieldMap, setFieldMap] = useState(DEFAULT_FIELD_MAP);

  const qc = useQueryClient();

  const { data: jiraProjects, isLoading: loadingProjects } = useQuery<
    JiraProject[]
  >({
    queryKey: ["jira-projects", savedInstance?.id],
    queryFn: async () => {
      const res = await fetch(
        `/api/onboarding/jira/instances/${savedInstance!.id}/projects`
      );
      if (!res.ok) throw new Error("Failed to fetch Jira projects");
      return res.json();
    },
    enabled: !!savedInstance?.id && step === 1,
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/onboarding/jira/instances/test-connection", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(instanceForm),
      });
      return res.json();
    },
    onSuccess: (data) => {
      setTestResult({
        ok: data.ok,
        message: data.ok
          ? `Connected as ${data.connected_as}`
          : data.error || "Connection failed",
      });
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/onboarding/jira/instances", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(instanceForm),
      });
      if (!res.ok) throw new Error("Failed to save Jira instance");
      return res.json();
    },
    onSuccess: (data) => {
      setSavedInstance(data);
      setStep(1);
    },
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/onboarding/jira/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instance_id: savedInstance?.id,
          project_keys: selectedProjects,
          field_map: fieldMap,
        }),
      });
      if (!res.ok) throw new Error("Sync failed");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      setStep(3); // done
    },
  });

  return (
    <div className="min-h-screen bg-[#0A0A0F] px-4 py-10">
      <div className="max-w-2xl mx-auto">
        {/* Back */}
        <Link
          href="/onboarding"
          className="inline-flex items-center gap-1.5 text-sm text-white/40 hover:text-white/70 mb-8 transition-colors"
        >
          <ArrowLeft size={14} />
          Onboarding
        </Link>

        <h1 className="text-2xl font-semibold text-white mb-1">
          Connect Jira
        </h1>
        <p className="text-white/50 text-sm mb-8">
          Link your Jira projects to PulseBoard and keep them in sync
          automatically.
        </p>

        {/* Step indicator */}
        <div className="flex items-center gap-0 mb-10">
          {STEPS.map((label, i) => (
            <div key={i} className="flex items-center">
              <div className="flex items-center gap-2">
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium transition-colors ${
                    i < step
                      ? "bg-[#8B5CF6] text-white"
                      : i === step
                      ? "border border-[#8B5CF6] text-[#8B5CF6]"
                      : "border border-white/20 text-white/30"
                  }`}
                >
                  {i < step ? <CheckCircle size={12} /> : i + 1}
                </div>
                <span
                  className={`text-sm font-medium ${
                    i === step ? "text-white" : "text-white/40"
                  }`}
                >
                  {label}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div
                  className={`h-px w-12 mx-3 ${
                    i < step ? "bg-[#8B5CF6]" : "bg-white/10"
                  }`}
                />
              )}
            </div>
          ))}
        </div>

        <AnimatePresence mode="wait">
          {/* Step 0 — Connect */}
          {step === 0 && (
            <motion.div
              key="step0"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="space-y-5"
            >
              <div className="bg-[#13131A] border border-white/8 rounded-xl p-6 space-y-4">
                <div className="space-y-1">
                  <label className="text-xs text-white/50 uppercase tracking-wider">
                    Instance Name
                  </label>
                  <input
                    value={instanceForm.name}
                    onChange={(e) =>
                      setInstanceForm((f) => ({ ...f, name: e.target.value }))
                    }
                    placeholder="Acme Jira"
                    className="w-full bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#8B5CF6]/50"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-white/50 uppercase tracking-wider">
                    Jira Base URL
                  </label>
                  <input
                    value={instanceForm.base_url}
                    onChange={(e) =>
                      setInstanceForm((f) => ({
                        ...f,
                        base_url: e.target.value,
                      }))
                    }
                    placeholder="https://yourcompany.atlassian.net"
                    className="w-full bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#8B5CF6]/50"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs text-white/50 uppercase tracking-wider">
                      Atlassian Email
                    </label>
                    <input
                      value={instanceForm.auth_email}
                      onChange={(e) =>
                        setInstanceForm((f) => ({
                          ...f,
                          auth_email: e.target.value,
                        }))
                      }
                      placeholder="you@company.com"
                      className="w-full bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#8B5CF6]/50"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs text-white/50 uppercase tracking-wider">
                      API Token
                    </label>
                    <input
                      type="password"
                      value={instanceForm.auth_token}
                      onChange={(e) =>
                        setInstanceForm((f) => ({
                          ...f,
                          auth_token: e.target.value,
                        }))
                      }
                      placeholder="ATATT3x..."
                      className="w-full bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#8B5CF6]/50"
                    />
                  </div>
                </div>

                <a
                  href="https://id.atlassian.com/manage-profile/security/api-tokens"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-[#8B5CF6] hover:text-[#a78bfa]"
                >
                  Generate an Atlassian API token
                  <ExternalLink size={11} />
                </a>
              </div>

              {/* Test result */}
              {testResult && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm ${
                    testResult.ok
                      ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                      : "bg-red-500/10 border border-red-500/20 text-red-400"
                  }`}
                >
                  {testResult.ok ? (
                    <CheckCircle size={15} />
                  ) : (
                    <AlertCircle size={15} />
                  )}
                  {testResult.message}
                </motion.div>
              )}

              <div className="flex gap-3">
                <button
                  onClick={() => testMutation.mutate()}
                  disabled={
                    testMutation.isPending ||
                    !instanceForm.base_url ||
                    !instanceForm.auth_email
                  }
                  className="flex-1 px-4 py-2.5 border border-white/15 rounded-lg text-sm text-white/70 hover:text-white hover:border-white/30 disabled:opacity-40 transition-all"
                >
                  {testMutation.isPending ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 size={13} className="animate-spin" /> Testing...
                    </span>
                  ) : (
                    "Test Connection"
                  )}
                </button>
                <button
                  onClick={() => saveMutation.mutate()}
                  disabled={
                    saveMutation.isPending ||
                    !testResult?.ok ||
                    !instanceForm.name
                  }
                  className="flex-1 px-4 py-2.5 bg-[#8B5CF6] rounded-lg text-sm text-white font-medium hover:bg-[#7c3aed] disabled:opacity-40 transition-all"
                >
                  {saveMutation.isPending ? (
                    <span className="flex items-center justify-center gap-2">
                      <Loader2 size={13} className="animate-spin" /> Saving...
                    </span>
                  ) : (
                    "Save & Continue"
                  )}
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 1 — Select Projects */}
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="space-y-5"
            >
              <div className="bg-[#13131A] border border-white/8 rounded-xl overflow-hidden">
                {loadingProjects ? (
                  <div className="flex items-center justify-center py-12 gap-3 text-white/40">
                    <Loader2 size={18} className="animate-spin" />
                    <span className="text-sm">Fetching Jira projects…</span>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {jiraProjects?.map((jp) => {
                      const selected = selectedProjects.includes(jp.key);
                      return (
                        <button
                          key={jp.key}
                          onClick={() =>
                            setSelectedProjects((prev) =>
                              selected
                                ? prev.filter((k) => k !== jp.key)
                                : [...prev, jp.key]
                            )
                          }
                          className="w-full flex items-center gap-4 px-5 py-3.5 hover:bg-white/3 text-left transition-colors"
                        >
                          <div
                            className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                              selected
                                ? "bg-[#8B5CF6] border-[#8B5CF6]"
                                : "border-white/20"
                            }`}
                          >
                            {selected && (
                              <CheckCircle size={10} className="text-white" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm text-white font-medium">
                              {jp.name}
                            </div>
                            <div className="text-xs text-white/40 font-mono">
                              {jp.key}
                            </div>
                          </div>
                          {jp.issues_count != null && (
                            <span className="text-xs text-white/30 font-mono">
                              {jp.issues_count} issues
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="flex justify-between">
                <button
                  onClick={() => setStep(0)}
                  className="px-4 py-2.5 text-sm text-white/50 hover:text-white transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(2)}
                  disabled={selectedProjects.length === 0}
                  className="px-6 py-2.5 bg-[#8B5CF6] rounded-lg text-sm text-white font-medium hover:bg-[#7c3aed] disabled:opacity-40 transition-all flex items-center gap-2"
                >
                  Continue
                  <ChevronRight size={14} />
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 2 — Map Fields */}
          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="space-y-5"
            >
              <div className="bg-[#13131A] border border-white/8 rounded-xl p-5 space-y-4">
                <p className="text-sm text-white/50">
                  Review the automatic field mappings. Adjust any that don't
                  look right.
                </p>
                <div className="space-y-3">
                  {Object.entries(fieldMap).map(([pbField, jiraField]) => (
                    <div
                      key={pbField}
                      className="grid grid-cols-2 gap-3 items-center"
                    >
                      <div className="text-sm text-white/70 font-medium">
                        {pbField}
                      </div>
                      <input
                        value={jiraField}
                        onChange={(e) =>
                          setFieldMap((m) => ({
                            ...m,
                            [pbField]: e.target.value,
                          }))
                        }
                        className="bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2 text-sm text-white/80 focus:outline-none focus:border-[#8B5CF6]/50"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#8B5CF6]/10 border border-[#8B5CF6]/20 rounded-xl p-4 text-sm text-white/60">
                <strong className="text-white/80">
                  {selectedProjects.length} project
                  {selectedProjects.length !== 1 ? "s" : ""}
                </strong>{" "}
                selected. PulseBoard will sync all issues from the last 90 days
                and set up a recurring 15-minute sync.
              </div>

              <div className="flex justify-between">
                <button
                  onClick={() => setStep(1)}
                  className="px-4 py-2.5 text-sm text-white/50 hover:text-white transition-colors"
                >
                  Back
                </button>
                <button
                  onClick={() => syncMutation.mutate()}
                  disabled={syncMutation.isPending}
                  className="px-6 py-2.5 bg-[#8B5CF6] rounded-lg text-sm text-white font-medium hover:bg-[#7c3aed] disabled:opacity-40 transition-all flex items-center gap-2"
                >
                  {syncMutation.isPending ? (
                    <>
                      <Loader2 size={13} className="animate-spin" /> Syncing…
                    </>
                  ) : (
                    <>
                      Save & Sync Now
                      <ChevronRight size={14} />
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 3 — Done */}
          {step === 3 && (
            <motion.div
              key="done"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-16 space-y-4"
            >
              <div className="w-14 h-14 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle size={28} className="text-emerald-400" />
              </div>
              <h2 className="text-xl font-semibold text-white">
                Jira Connected!
              </h2>
              <p className="text-white/50 text-sm max-w-sm mx-auto">
                {selectedProjects.length} project
                {selectedProjects.length !== 1 ? "s" : ""} imported.
                PulseBoard will sync every 15 minutes automatically.
              </p>
              <div className="flex gap-3 justify-center mt-6">
                <Link
                  href="/projects"
                  className="px-5 py-2.5 bg-[#8B5CF6] rounded-lg text-sm text-white font-medium hover:bg-[#7c3aed] transition-all"
                >
                  View Projects
                </Link>
                <Link
                  href="/onboarding"
                  className="px-5 py-2.5 border border-white/15 rounded-lg text-sm text-white/70 hover:text-white hover:border-white/30 transition-all"
                >
                  Back to Onboarding
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
