"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, Copy, ArrowRight, ArrowLeft, Zap, Globe, Database, Upload } from "lucide-react";
import { Shell } from "@/components/layout/shell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { apiClient } from "@/lib/api/client";

const STEPS = ["Choose KPI", "Ingestion Mode", "Configure", "Validate"];

type IngestionMode = "api_push" | "api_pull" | "pipeline" | "manual";

const MODE_OPTIONS: Array<{ id: IngestionMode; label: string; icon: React.ElementType; description: string; best_for: string }> = [
  { id: "api_push", label: "Push API", icon: Zap, description: "PulseBoard generates an endpoint. You POST data to it.", best_for: "Real-time events from your own systems" },
  { id: "api_pull", label: "Pull API", icon: Globe, description: "You provide an endpoint. PulseBoard polls it on a schedule.", best_for: "APIs you don't control" },
  { id: "pipeline", label: "SQL Pipeline", icon: Database, description: "Write a SQL query against BigQuery or Snowflake.", best_for: "Metrics already in your data warehouse" },
  { id: "manual", label: "Manual Upload", icon: Upload, description: "Paste CSV or upload a spreadsheet.", best_for: "One-off or low-frequency metrics" },
];

export default function KPIOnboardingPage() {
  const [step, setStep] = useState(0);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [mode, setMode] = useState<IngestionMode>("api_push");
  const [kpiName, setKPIName] = useState("");
  const [target, setTarget] = useState("");
  const [direction, setDirection] = useState<"higher_is_better" | "lower_is_better">("higher_is_better");
  const [copied, setCopied] = useState(false);
  const [generatedToken, setGeneratedToken] = useState<{ token: string; endpoint: string; curl_example: string } | null>(null);

  const { data: library = [] } = useQuery({
    queryKey: ["kpi-library"],
    queryFn: () => apiClient.get("/onboarding/kpi-starter-library").then((r) => r.data),
  });

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNext = () => setStep((s) => Math.min(s + 1, STEPS.length - 1));
  const handleBack = () => setStep((s) => Math.max(s - 1, 0));

  return (
    <Shell>
      <div className="mx-auto max-w-2xl space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-xl font-semibold text-text-primary">Onboard Adoption KPI</h1>
          <p className="mt-0.5 text-sm text-muted">
            Define what you want to track and how PulseBoard should collect the data.
          </p>
        </div>

        {/* Step indicators */}
        <div className="flex items-center gap-2">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <button
                onClick={() => i < step && setStep(i)}
                className={cn(
                  "flex h-6 w-6 items-center justify-center rounded-full text-xs font-medium transition-colors",
                  i < step
                    ? "cursor-pointer bg-accent text-white"
                    : i === step
                    ? "bg-accent/20 text-accent ring-1 ring-accent/40"
                    : "bg-surface-2 text-muted"
                )}
              >
                {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </button>
              <span className={cn("text-xs", i === step ? "text-text-primary" : "text-muted")}>{s}</span>
              {i < STEPS.length - 1 && <div className="h-px w-6 bg-border" />}
            </div>
          ))}
        </div>

        {/* Step content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.2 }}
            className="rounded-xl border border-border bg-surface p-6"
          >
            {/* Step 0: Choose KPI */}
            {step === 0 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-text-primary">Choose a KPI template</h2>
                  <p className="mt-1 text-sm text-muted">Start from our library or define from scratch.</p>
                </div>

                <div className="grid grid-cols-1 gap-2 max-h-72 overflow-y-auto">
                  {library.map((kpi: any) => (
                    <button
                      key={kpi.slug}
                      onClick={() => { setSelectedTemplate(kpi); setKPIName(kpi.name); }}
                      className={cn(
                        "flex items-start gap-3 rounded-lg border p-3 text-left transition-colors",
                        selectedTemplate?.slug === kpi.slug
                          ? "border-accent/40 bg-accent/5"
                          : "border-border hover:border-border/80 hover:bg-surface-2"
                      )}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium text-text-primary">{kpi.name}</p>
                          <Badge variant="outline" className="text-[10px] capitalize">{kpi.category?.replace("_", " ")}</Badge>
                        </div>
                        <p className="mt-0.5 text-xs text-muted">{kpi.description}</p>
                      </div>
                      {selectedTemplate?.slug === kpi.slug && (
                        <Check className="h-4 w-4 flex-shrink-0 text-accent" />
                      )}
                    </button>
                  ))}
                </div>

                <div className="border-t border-border pt-4">
                  <p className="text-xs text-muted mb-2">Or define a custom KPI:</p>
                  <input
                    value={kpiName}
                    onChange={(e) => { setKPIName(e.target.value); setSelectedTemplate(null); }}
                    placeholder="e.g. Daily Active Users on Procurement Bot"
                    className="w-full rounded-lg border border-border bg-surface-2 px-3 py-2 text-sm text-text-primary placeholder:text-muted focus:border-accent/50 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* Step 1: Ingestion mode */}
            {step === 1 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-text-primary">How will data flow in?</h2>
                  <p className="mt-1 text-sm text-muted">Choose the ingestion mode that fits your setup.</p>
                </div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {MODE_OPTIONS.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setMode(m.id)}
                      className={cn(
                        "flex flex-col gap-2 rounded-lg border p-4 text-left transition-colors",
                        mode === m.id
                          ? "border-accent/40 bg-accent/5"
                          : "border-border hover:border-border/80 hover:bg-surface-2"
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <m.icon className={cn("h-4 w-4", mode === m.id ? "text-accent" : "text-muted")} />
                        <span className="text-sm font-medium text-text-primary">{m.label}</span>
                        {mode === m.id && <Check className="ml-auto h-4 w-4 text-accent" />}
                      </div>
                      <p className="text-xs text-muted">{m.description}</p>
                      <p className="text-xs text-text-secondary">
                        <span className="text-muted">Best for: </span>{m.best_for}
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Configure */}
            {step === 2 && (
              <div className="space-y-4">
                <div>
                  <h2 className="text-base font-semibold text-text-primary">Configure "{kpiName}"</h2>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-muted">Target value</label>
                    <input
                      value={target}
                      onChange={(e) => setTarget(e.target.value)}
                      placeholder="e.g. 5000"
                      className="mt-1 w-full rounded-lg border border-border bg-surface-2 px-3 py-2 text-sm text-text-primary placeholder:text-muted focus:border-accent/50 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted">Direction</label>
                    <select
                      value={direction}
                      onChange={(e) => setDirection(e.target.value as any)}
                      className="mt-1 w-full rounded-lg border border-border bg-surface-2 px-3 py-2 text-sm text-text-primary focus:border-accent/50 focus:outline-none"
                    >
                      <option value="higher_is_better">Higher is better</option>
                      <option value="lower_is_better">Lower is better</option>
                    </select>
                  </div>
                </div>

                {/* Push API configuration */}
                {mode === "api_push" && (
                  <div className="rounded-lg border border-border bg-surface-2 p-4 space-y-3">
                    <p className="text-sm font-medium text-text-primary">Push API Setup</p>
                    <p className="text-xs text-muted">After saving, PulseBoard will generate a unique endpoint and bearer token for this KPI.</p>
                    <div className="rounded-md bg-background p-3 font-mono text-xs text-text-secondary">
                      <p className="text-muted mb-1"># Example POST request</p>
                      <p>{`curl -X POST "https://api.pulseboard.app/adoption/kpis/{id}/ingest" \\`}</p>
                      <p>{`  -H "Authorization: Bearer <your-token>" \\`}</p>
                      <p>{`  -H "Content-Type: application/json" \\`}</p>
                      <p>{`  -d '{"ts": "2024-01-15T10:00:00Z", "value": 1234, "dimensions": {"region": "APAC"}}'`}</p>
                    </div>
                  </div>
                )}

                {mode === "pipeline" && (
                  <div>
                    <label className="text-xs text-muted">SQL Query (BigQuery / Snowflake)</label>
                    <textarea
                      rows={5}
                      placeholder={`SELECT COUNT(DISTINCT user_id) as value, CURRENT_TIMESTAMP() as ts\nFROM your_dataset.usage_events\nWHERE DATE(event_ts) = CURRENT_DATE()\nAND product = 'hr_policy_bot'`}
                      className="mt-1 w-full rounded-lg border border-border bg-surface-2 px-3 py-2 font-mono text-xs text-text-primary placeholder:text-muted focus:border-accent/50 focus:outline-none"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Step 3: Validate */}
            {step === 3 && (
              <div className="space-y-4 text-center">
                <div className="flex justify-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/10">
                    <Check className="h-7 w-7 text-emerald-400" />
                  </div>
                </div>
                <h2 className="text-base font-semibold text-text-primary">KPI configured!</h2>
                <p className="text-sm text-muted">
                  <strong className="text-text-primary">{kpiName}</strong> is ready. Send your first data point to activate it.
                </p>

                {mode === "api_push" && (
                  <div className="text-left rounded-lg border border-border bg-surface-2 p-4 space-y-2">
                    <p className="text-xs font-medium text-text-primary">Your curl example:</p>
                    <div className="relative">
                      <pre className="overflow-x-auto rounded-md bg-background p-3 font-mono text-xs text-text-secondary whitespace-pre-wrap">
                        {`curl -X POST "https://api.pulseboard.app/adoption/kpis/[kpi-id]/ingest" \\\n  -H "Authorization: Bearer [your-token]" \\\n  -H "Content-Type: application/json" \\\n  -d '{"value": 1234}'`}
                      </pre>
                      <button
                        onClick={() => handleCopy("curl example")}
                        className="absolute right-2 top-2 rounded p-1 text-muted hover:text-text-primary"
                      >
                        {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={handleBack} disabled={step === 0} className="gap-1.5">
            <ArrowLeft className="h-4 w-4" /> Back
          </Button>
          <Button onClick={handleNext} disabled={step === STEPS.length - 1 && !kpiName} className="gap-1.5">
            {step === STEPS.length - 1 ? "Go to Adoption Dashboard" : "Next"}
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Shell>
  );
}
