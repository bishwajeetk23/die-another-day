"use client";

import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Upload,
  FileSpreadsheet,
  CheckCircle,
  AlertCircle,
  X,
  Download,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import Link from "next/link";

interface ParsedRow {
  name: string;
  ai_pattern?: string;
  lifecycle_stage?: string;
  rag_status?: string;
  parse_status: "ok" | "warning" | "error";
  parse_message?: string;
}

interface ParseResult {
  preview: ParsedRow[];
  total_rows: number;
  error_rows: number;
  warning_rows: number;
}

export default function UploadOnboardingPage() {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [parseResult, setParseResult] = useState<ParseResult | null>(null);
  const [importDone, setImportDone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const qc = useQueryClient();

  const parseMutation = useMutation({
    mutationFn: async (f: File) => {
      const form = new FormData();
      form.append("file", f);
      form.append("preview_only", "true");
      const res = await fetch("/api/onboarding/upload", {
        method: "POST",
        body: form,
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Parse failed");
      }
      return res.json() as Promise<ParseResult>;
    },
    onSuccess: (data) => setParseResult(data),
  });

  const importMutation = useMutation({
    mutationFn: async () => {
      const form = new FormData();
      form.append("file", file!);
      form.append("preview_only", "false");
      const res = await fetch("/api/onboarding/upload", {
        method: "POST",
        body: form,
      });
      if (!res.ok) throw new Error("Import failed");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      setImportDone(true);
    },
  });

  const handleFile = useCallback((f: File) => {
    setFile(f);
    setParseResult(null);
    setImportDone(false);
    parseMutation.mutate(f);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);
      const f = e.dataTransfer.files[0];
      if (f) handleFile(f);
    },
    [handleFile]
  );

  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const onDragLeave = () => setIsDragging(false);

  const statusIcon = (status: ParsedRow["parse_status"]) => {
    if (status === "ok") return <CheckCircle size={13} className="text-emerald-400" />;
    if (status === "warning") return <AlertCircle size={13} className="text-amber-400" />;
    return <X size={13} className="text-red-400" />;
  };

  const statusColor = (status: ParsedRow["parse_status"]) => {
    if (status === "ok") return "text-emerald-400";
    if (status === "warning") return "text-amber-400";
    return "text-red-400";
  };

  return (
    <div className="min-h-screen bg-[#0A0A0F] px-4 py-10">
      <div className="max-w-2xl mx-auto">
        <Link
          href="/onboarding"
          className="inline-flex items-center gap-1.5 text-sm text-white/40 hover:text-white/70 mb-8 transition-colors"
        >
          <ArrowLeft size={14} />
          Onboarding
        </Link>

        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-2xl font-semibold text-white mb-1">
              Upload Tracker
            </h1>
            <p className="text-white/50 text-sm">
              Import your AI project tracker from CSV or Excel.
            </p>
          </div>
          <a
            href="/api/onboarding/template"
            download
            className="flex items-center gap-2 px-4 py-2 border border-white/15 rounded-lg text-sm text-white/60 hover:text-white hover:border-white/30 transition-all"
          >
            <Download size={14} />
            Template (.xlsx)
          </a>
        </div>

        <AnimatePresence mode="wait">
          {importDone ? (
            <motion.div
              key="done"
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center py-16 space-y-4"
            >
              <div className="w-14 h-14 rounded-full bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto">
                <CheckCircle size={28} className="text-emerald-400" />
              </div>
              <h2 className="text-xl font-semibold text-white">
                Import complete!
              </h2>
              <p className="text-white/50 text-sm">
                {parseResult?.total_rows} project
                {parseResult?.total_rows !== 1 ? "s" : ""} imported
                successfully.
              </p>
              <div className="flex gap-3 justify-center mt-6">
                <Link
                  href="/projects"
                  className="px-5 py-2.5 bg-[#8B5CF6] rounded-lg text-sm text-white font-medium hover:bg-[#7c3aed] transition-all"
                >
                  View Projects
                </Link>
                <button
                  onClick={() => {
                    setFile(null);
                    setParseResult(null);
                    setImportDone(false);
                  }}
                  className="px-5 py-2.5 border border-white/15 rounded-lg text-sm text-white/70 hover:text-white hover:border-white/30 transition-all"
                >
                  Upload Another
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="upload"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-5"
            >
              {/* Drop zone */}
              <div
                onDrop={onDrop}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onClick={() => fileInputRef.current?.click()}
                className={`relative border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-[#8B5CF6] bg-[#8B5CF6]/5"
                    : file
                    ? "border-[#8B5CF6]/40 bg-[#13131A]"
                    : "border-white/10 bg-[#13131A] hover:border-white/20"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleFile(f);
                  }}
                />

                {parseMutation.isPending ? (
                  <div className="flex flex-col items-center gap-3 text-white/50">
                    <Loader2 size={32} className="animate-spin text-[#8B5CF6]" />
                    <span className="text-sm">Parsing file…</span>
                  </div>
                ) : file ? (
                  <div className="flex flex-col items-center gap-3">
                    <FileSpreadsheet size={32} className="text-[#8B5CF6]" />
                    <div>
                      <div className="text-sm text-white font-medium">
                        {file.name}
                      </div>
                      <div className="text-xs text-white/40 mt-0.5">
                        {(file.size / 1024).toFixed(1)} KB
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setFile(null);
                        setParseResult(null);
                      }}
                      className="text-xs text-white/40 hover:text-white/70 transition-colors"
                    >
                      Remove file
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3 text-white/40">
                    <Upload size={32} />
                    <div>
                      <p className="text-sm text-white/60">
                        Drop your CSV or XLSX here
                      </p>
                      <p className="text-xs text-white/30 mt-1">
                        or click to browse files
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Parse error */}
              {parseMutation.isError && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 px-4 py-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm text-red-400"
                >
                  <AlertCircle size={14} />
                  {parseMutation.error?.message || "Failed to parse file"}
                </motion.div>
              )}

              {/* Preview */}
              {parseResult && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  {/* Summary */}
                  <div className="flex gap-4 text-sm">
                    <span className="text-white/50">
                      <span className="text-white font-medium">
                        {parseResult.total_rows}
                      </span>{" "}
                      rows
                    </span>
                    {parseResult.error_rows > 0 && (
                      <span className="text-red-400">
                        {parseResult.error_rows} errors
                      </span>
                    )}
                    {parseResult.warning_rows > 0 && (
                      <span className="text-amber-400">
                        {parseResult.warning_rows} warnings
                      </span>
                    )}
                  </div>

                  {/* Preview table */}
                  <div className="bg-[#13131A] border border-white/8 rounded-xl overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-white/8">
                            <th className="text-left px-4 py-3 text-xs text-white/40 font-medium uppercase tracking-wider w-5">

                            </th>
                            <th className="text-left px-4 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                              Name
                            </th>
                            <th className="text-left px-4 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                              AI Pattern
                            </th>
                            <th className="text-left px-4 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                              Stage
                            </th>
                            <th className="text-left px-4 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                              Note
                            </th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-white/5">
                          {parseResult.preview.map((row, i) => (
                            <tr
                              key={i}
                              className="hover:bg-white/2 transition-colors"
                            >
                              <td className="px-4 py-3">
                                {statusIcon(row.parse_status)}
                              </td>
                              <td className="px-4 py-3 text-white/80 font-medium">
                                {row.name || (
                                  <span className="text-white/30 italic">
                                    (empty)
                                  </span>
                                )}
                              </td>
                              <td className="px-4 py-3 text-white/50 text-xs font-mono">
                                {row.ai_pattern || "—"}
                              </td>
                              <td className="px-4 py-3 text-white/50 text-xs capitalize">
                                {row.lifecycle_stage || "—"}
                              </td>
                              <td
                                className={`px-4 py-3 text-xs ${statusColor(
                                  row.parse_status
                                )}`}
                              >
                                {row.parse_message || ""}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button
                      onClick={() => importMutation.mutate()}
                      disabled={
                        importMutation.isPending ||
                        parseResult.error_rows === parseResult.total_rows
                      }
                      className="px-6 py-2.5 bg-[#8B5CF6] rounded-lg text-sm text-white font-medium hover:bg-[#7c3aed] disabled:opacity-40 transition-all flex items-center gap-2"
                    >
                      {importMutation.isPending ? (
                        <>
                          <Loader2 size={13} className="animate-spin" />
                          Importing…
                        </>
                      ) : (
                        <>
                          Import{" "}
                          {parseResult.total_rows - parseResult.error_rows}{" "}
                          Projects
                        </>
                      )}
                    </button>
                  </div>
                </motion.div>
              )}

              {/* Format guide */}
              {!parseResult && !file && (
                <div className="bg-[#13131A] border border-white/8 rounded-xl p-5 space-y-3">
                  <h3 className="text-sm font-medium text-white/70">
                    Required CSV columns
                  </h3>
                  <div className="font-mono text-xs text-white/40 bg-[#0A0A0F] rounded-lg p-3 overflow-x-auto">
                    name, ai_pattern, lifecycle_stage, model_risk_tier,
                    baseline_end_date, forecast_end_date, rag_status,
                    expected_value_amount, expected_value_unit, bu_name,
                    product_owner_email
                  </div>
                  <p className="text-xs text-white/30">
                    Download the template above for the exact column headers and
                    allowed values.
                  </p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
