"use client";

import { useState, useCallback } from "react";
import { motion, AnimatePresence, Reorder } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  MoreHorizontal,
  AlertTriangle,
  ChevronRight,
  Loader2,
} from "lucide-react";
import Link from "next/link";

const STAGES = [
  { id: "ideation", label: "Ideation", color: "rgba(139,92,246,0.15)" },
  { id: "qualification", label: "Qualification", color: "rgba(99,102,241,0.15)" },
  { id: "poc", label: "PoC", color: "rgba(59,130,246,0.15)" },
  { id: "pilot", label: "Pilot", color: "rgba(14,165,233,0.15)" },
  { id: "production", label: "Production", color: "rgba(16,185,129,0.15)" },
  { id: "scale", label: "Scale", color: "rgba(245,158,11,0.15)" },
  { id: "sunset", label: "Sunset", color: "rgba(239,68,68,0.1)" },
];

const RAG_COLORS: Record<string, string> = {
  green: "bg-emerald-500",
  amber: "bg-amber-400",
  red: "bg-red-500",
};

const AI_PATTERN_LABELS: Record<string, string> = {
  predictive_ml: "Predictive ML",
  generative_ai: "Gen AI",
  agentic: "Agentic",
  computer_vision: "Vision",
  nlp: "NLP",
  recommendation: "Recs",
  optimization: "Optim.",
  rpa_ai: "RPA+AI",
};

interface Project {
  id: string;
  name: string;
  slug: string;
  ai_pattern: string;
  lifecycle_stage: string;
  rag_status: string;
  model_risk_tier: number;
  product_owner?: { display_name: string };
  bu?: { name: string };
  function?: { name: string };
  forecast_end_date?: string;
}

function ProjectCard({
  project,
  onAdvance,
  advancing,
}: {
  project: Project;
  onAdvance: (id: string, currentStage: string) => void;
  advancing: boolean;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const currentStageIdx = STAGES.findIndex(
    (s) => s.id === project.lifecycle_stage
  );
  const canAdvance = currentStageIdx < STAGES.length - 1;

  return (
    <motion.div
      layout
      layoutId={`card-${project.id}`}
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -1 }}
      className="bg-[#0A0A0F] border border-white/8 rounded-xl p-4 space-y-3 cursor-default relative group"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <Link
          href={`/projects/${project.slug}`}
          className="text-sm font-medium text-white hover:text-[#a78bfa] transition-colors leading-tight"
        >
          {project.name}
        </Link>
        <div className="flex items-center gap-1.5 shrink-0">
          <div
            className={`w-2 h-2 rounded-full ${RAG_COLORS[project.rag_status] || "bg-white/20"}`}
          />
          <div className="relative">
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="opacity-0 group-hover:opacity-100 text-white/30 hover:text-white/60 transition-all"
            >
              <MoreHorizontal size={14} />
            </button>
            <AnimatePresence>
              {menuOpen && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -4 }}
                  className="absolute right-0 top-6 bg-[#1a1a24] border border-white/15 rounded-lg py-1 w-36 z-20 shadow-xl"
                  onMouseLeave={() => setMenuOpen(false)}
                >
                  <Link
                    href={`/projects/${project.slug}`}
                    className="block px-3 py-1.5 text-xs text-white/70 hover:text-white hover:bg-white/5 transition-colors"
                  >
                    Open Detail
                  </Link>
                  {canAdvance && (
                    <button
                      onClick={() => {
                        onAdvance(project.id, project.lifecycle_stage);
                        setMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-1.5 text-xs text-[#8B5CF6] hover:bg-[#8B5CF6]/10 transition-colors flex items-center gap-1.5"
                    >
                      <ChevronRight size={11} />
                      Advance Stage
                    </button>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Pattern + BU */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-xs px-2 py-0.5 rounded-full bg-[#8B5CF6]/10 text-[#8B5CF6]/80">
          {AI_PATTERN_LABELS[project.ai_pattern] || project.ai_pattern}
        </span>
        {(project.bu || project.function) && (
          <span className="text-xs text-white/30 truncate max-w-[100px]">
            {project.bu?.name || project.function?.name}
          </span>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          {project.model_risk_tier === 1 && (
            <AlertTriangle size={11} className="text-amber-400" />
          )}
          <span className="text-xs text-white/30">T{project.model_risk_tier}</span>
        </div>
        {project.product_owner && (
          <span className="text-xs text-white/30 truncate max-w-[100px]">
            {project.product_owner.display_name.split(" ")[0]}
          </span>
        )}
        {canAdvance && (
          <button
            onClick={() => onAdvance(project.id, project.lifecycle_stage)}
            disabled={advancing}
            className="opacity-0 group-hover:opacity-100 text-xs text-[#8B5CF6] hover:text-[#a78bfa] disabled:opacity-40 flex items-center gap-1 transition-all"
          >
            {advancing ? (
              <Loader2 size={10} className="animate-spin" />
            ) : (
              <>
                Advance <ChevronRight size={10} />
              </>
            )}
          </button>
        )}
      </div>
    </motion.div>
  );
}

export default function KanbanPage() {
  const qc = useQueryClient();
  const [advancingId, setAdvancingId] = useState<string | null>(null);

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["projects", "all"],
    queryFn: async () => {
      const res = await fetch("/api/projects?limit=200");
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      return data.items || data;
    },
  });

  const advanceMutation = useMutation({
    mutationFn: async ({
      id,
    }: {
      id: string;
      currentStage: string;
    }) => {
      const res = await fetch(`/api/projects/${id}/advance-stage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notes: "Advanced via Kanban board" }),
      });
      if (!res.ok) throw new Error("Failed to advance stage");
      return res.json();
    },
    onMutate: ({ id }) => setAdvancingId(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["projects"] });
      setAdvancingId(null);
    },
    onError: () => setAdvancingId(null),
  });

  const handleAdvance = useCallback(
    (id: string, currentStage: string) => {
      advanceMutation.mutate({ id, currentStage });
    },
    [advanceMutation]
  );

  // Group projects by stage
  const byStage = STAGES.reduce<Record<string, Project[]>>((acc, stage) => {
    acc[stage.id] = projects.filter((p) => p.lifecycle_stage === stage.id);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      {/* Header */}
      <div className="px-6 py-6 border-b border-white/8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-white">AI Portfolio</h1>
            <p className="text-sm text-white/40 mt-0.5">
              Kanban view · {projects.length} projects
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              href="/projects"
              className="px-3 py-1.5 text-xs text-white/50 hover:text-white border border-white/10 hover:border-white/25 rounded-lg transition-all"
            >
              List view
            </Link>
          </div>
        </div>
      </div>

      {/* Board */}
      {isLoading ? (
        <div className="flex items-center justify-center py-24 gap-3 text-white/40">
          <Loader2 size={20} className="animate-spin" />
          <span>Loading projects…</span>
        </div>
      ) : (
        <div className="flex gap-3 p-5 overflow-x-auto pb-8 min-h-[calc(100vh-100px)]">
          {STAGES.map((stage) => {
            const cards = byStage[stage.id] || [];
            return (
              <div
                key={stage.id}
                className="flex-shrink-0 w-[260px] flex flex-col"
              >
                {/* Column header */}
                <div
                  className="flex items-center justify-between px-3 py-2.5 rounded-t-xl mb-2"
                  style={{ backgroundColor: stage.color }}
                >
                  <span className="text-xs font-semibold text-white/70 uppercase tracking-wider">
                    {stage.label}
                  </span>
                  <span className="text-xs font-mono text-white/40 bg-black/20 px-2 py-0.5 rounded-full">
                    {cards.length}
                  </span>
                </div>

                {/* Cards */}
                <div className="flex-1 space-y-2 min-h-[120px]">
                  <AnimatePresence>
                    {cards.map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onAdvance={handleAdvance}
                        advancing={advancingId === project.id}
                      />
                    ))}
                  </AnimatePresence>

                  {cards.length === 0 && (
                    <div className="border border-dashed border-white/8 rounded-xl h-20 flex items-center justify-center">
                      <span className="text-xs text-white/20">Empty</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
