"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { useParams } from "next/navigation";
import { ArrowLeft, ExternalLink, GitBranch, AlertTriangle, Shield, BarChart3, TrendingUp } from "lucide-react";
import Link from "next/link";
import { Shell } from "@/components/layout/shell";
import { StagePipeline } from "@/components/projects/stage-pipeline";
import { RAGIndicator } from "@/components/projects/rag-indicator";
import { useProject, useProjectMilestones, useProjectRisks } from "@/lib/hooks/use-projects";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { InlineChart } from "@/components/charts/inline-chart";
import { cn } from "@/lib/utils";

export default function ProjectDetailPage() {
  const params = useParams();
  const projectId = params.id as string;

  const { data: project, isLoading } = useProject(projectId);
  const { data: milestones = [] } = useProjectMilestones(projectId);
  const { data: risks = [] } = useProjectRisks(projectId);

  if (isLoading) {
    return (
      <Shell>
        <div className="space-y-4">
          <div className="h-8 w-64 animate-pulse rounded-lg bg-surface-2" />
          <div className="h-4 w-96 animate-pulse rounded bg-surface-2" />
          <div className="h-48 animate-pulse rounded-xl bg-surface-2" />
        </div>
      </Shell>
    );
  }

  if (!project) {
    return (
      <Shell>
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <p className="text-sm text-muted">Project not found.</p>
          <Link href="/projects" className="mt-2 text-xs text-accent hover:underline">← Back to portfolio</Link>
        </div>
      </Shell>
    );
  }

  const scheduleVarianceDays =
    project.forecast_end_date && project.baseline_end_date
      ? Math.round(
          (new Date(project.forecast_end_date).getTime() - new Date(project.baseline_end_date).getTime()) /
            (1000 * 60 * 60 * 24)
        )
      : null;

  return (
    <Shell>
      <div className="space-y-6">
        {/* Back link */}
        <Link href="/projects" className="flex items-center gap-1.5 text-xs text-muted hover:text-text-secondary">
          <ArrowLeft className="h-3.5 w-3.5" />
          AI Projects
        </Link>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-border bg-surface p-6"
        >
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-xl font-semibold text-text-primary">{project.name}</h1>
                <RAGIndicator status={project.rag_status} />
              </div>
              {project.description && (
                <p className="mt-1.5 text-sm text-muted max-w-2xl">{project.description}</p>
              )}
              <div className="mt-4">
                <StagePipeline currentStage={project.lifecycle_stage} size="md" showLabels />
              </div>
            </div>

            {/* Key stats */}
            <div className="flex flex-shrink-0 gap-4 text-right">
              {scheduleVarianceDays !== null && (
                <div>
                  <p className="text-2xl font-mono font-semibold tabular-nums text-text-primary">
                    {scheduleVarianceDays > 0 ? "+" : ""}{scheduleVarianceDays}d
                  </p>
                  <p className="text-xs text-muted">Schedule variance</p>
                </div>
              )}
              {project.expected_value_amount && (
                <div>
                  <p className="text-2xl font-mono font-semibold tabular-nums text-text-primary">
                    {project.expected_value_currency}{Number(project.expected_value_amount).toLocaleString()}
                  </p>
                  <p className="text-xs text-muted">Expected value ({project.expected_value_unit})</p>
                </div>
              )}
            </div>
          </div>

          {/* Meta grid */}
          <div className="mt-5 grid grid-cols-2 gap-x-8 gap-y-3 border-t border-border pt-5 sm:grid-cols-4">
            <MetaItem label="AI Pattern" value={project.ai_pattern?.replace("_", " ")} />
            <MetaItem label="Foundation Model" value={project.foundation_model} />
            <MetaItem label="Sponsoring Function" value={project.sponsoring_function} />
            <MetaItem label="Model Risk Tier" value={project.model_risk_tier} />
            <MetaItem label="Data Sensitivity" value={project.data_sensitivity} />
            <MetaItem label="Source" value={project.source} />
            <MetaItem
              label="Baseline End"
              value={project.baseline_end_date ? new Date(project.baseline_end_date).toLocaleDateString() : undefined}
            />
            <MetaItem
              label="Forecast End"
              value={project.forecast_end_date ? new Date(project.forecast_end_date).toLocaleDateString() : undefined}
            />
          </div>
        </motion.div>

        {/* Tabs */}
        <Tabs defaultValue="milestones">
          <TabsList>
            <TabsTrigger value="milestones">
              <GitBranch className="mr-1.5 h-3.5 w-3.5" /> Milestones
            </TabsTrigger>
            <TabsTrigger value="risks">
              <AlertTriangle className="mr-1.5 h-3.5 w-3.5" /> Risks & Issues
            </TabsTrigger>
            <TabsTrigger value="governance">
              <Shield className="mr-1.5 h-3.5 w-3.5" /> Governance
            </TabsTrigger>
            <TabsTrigger value="adoption">
              <BarChart3 className="mr-1.5 h-3.5 w-3.5" /> Adoption
            </TabsTrigger>
            <TabsTrigger value="value">
              <TrendingUp className="mr-1.5 h-3.5 w-3.5" /> Value Realization
            </TabsTrigger>
          </TabsList>

          {/* Milestones */}
          <TabsContent value="milestones" className="mt-4">
            <div className="rounded-xl border border-border overflow-hidden">
              <div className="grid grid-cols-[2fr_1fr_1fr_1fr_100px] gap-4 border-b border-border bg-surface-2 px-4 py-2.5 text-xs font-medium text-muted">
                <span>Milestone</span>
                <span>Baseline</span>
                <span>Forecast</span>
                <span>Actual</span>
                <span>Status</span>
              </div>
              {milestones.length === 0 ? (
                <EmptyState message="No milestones added yet." />
              ) : (
                milestones.map((m) => (
                  <div key={m.id} className="grid grid-cols-[2fr_1fr_1fr_1fr_100px] gap-4 items-center border-b border-border px-4 py-3 text-sm last:border-0">
                    <span className="text-text-primary font-medium">{m.name}</span>
                    <span className="font-mono text-xs text-muted">{m.baseline_date ? new Date(m.baseline_date).toLocaleDateString() : "—"}</span>
                    <span className="font-mono text-xs text-muted">{m.forecast_date ? new Date(m.forecast_date).toLocaleDateString() : "—"}</span>
                    <span className="font-mono text-xs text-muted">{m.actual_date ? new Date(m.actual_date).toLocaleDateString() : "—"}</span>
                    <MilestoneStatusBadge status={m.status} />
                  </div>
                ))
              )}
            </div>
          </TabsContent>

          {/* Risks */}
          <TabsContent value="risks" className="mt-4 space-y-2">
            {risks.length === 0 ? (
              <EmptyState message="No risks logged. Great news, or add one now." />
            ) : (
              risks.map((risk) => (
                <div key={risk.id} className="flex items-start gap-3 rounded-lg border border-border bg-surface p-4">
                  <SeverityDot severity={risk.severity} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium text-text-primary">{risk.title}</span>
                      <Badge variant="outline" className="text-[10px]">{risk.risk_category?.replace("_", " ")}</Badge>
                      <Badge variant="outline" className="text-[10px]">{risk.status}</Badge>
                    </div>
                    {risk.mitigation && (
                      <p className="mt-1 text-xs text-muted">{risk.mitigation}</p>
                    )}
                  </div>
                  <div className="text-right text-xs text-muted">
                    <p>Likelihood: {risk.likelihood}</p>
                    <p>Severity: {risk.severity}</p>
                  </div>
                </div>
              ))
            )}
          </TabsContent>

          {/* Governance */}
          <TabsContent value="governance" className="mt-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <GovernanceCard title="Model Risk Tier" value={project.model_risk_tier || "Not set"} description="1 = highest risk" />
              <GovernanceCard title="Responsible AI Status" value={project.responsible_ai_status || "Not started"} />
              <GovernanceCard title="DPIA Status" value={project.dpia_status || "Not required"} />
              <GovernanceCard title="Data Sensitivity" value={project.data_sensitivity || "Not set"} />
              <GovernanceCard title="Foundation Model" value={project.foundation_model || "N/A"} />
            </div>
          </TabsContent>

          {/* Adoption — link to adoption page */}
          <TabsContent value="adoption" className="mt-4">
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <BarChart3 className="mb-3 h-8 w-8 text-muted" />
              <p className="text-sm text-muted">Adoption KPIs are tracked in the Adoption module.</p>
              <Link
                href={`/adoption?project_id=${project.id}`}
                className="mt-3 text-sm text-accent hover:underline"
              >
                View adoption KPIs for this project →
              </Link>
            </div>
          </TabsContent>

          {/* Value Realization */}
          <TabsContent value="value" className="mt-4">
            {project.expected_value_amount ? (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="rounded-xl border border-border bg-surface p-5">
                  <p className="text-xs text-muted">Expected Value</p>
                  <p className="mt-1 font-mono text-3xl font-semibold tabular-nums text-text-primary">
                    {project.expected_value_currency} {Number(project.expected_value_amount).toLocaleString()}
                  </p>
                  <p className="text-xs text-muted">{project.expected_value_unit}</p>
                </div>
                <div className="rounded-xl border border-border bg-surface p-5">
                  <p className="text-xs text-muted">Realized Value</p>
                  <p className="mt-1 font-mono text-3xl font-semibold tabular-nums text-emerald-400">
                    {project.realized_value_amount
                      ? `${project.expected_value_currency} ${Number(project.realized_value_amount).toLocaleString()}`
                      : "Not yet measured"}
                  </p>
                  {project.realized_value_amount && project.expected_value_amount && (
                    <p className="text-xs text-muted">
                      {Math.round((Number(project.realized_value_amount) / Number(project.expected_value_amount)) * 100)}% of target
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <EmptyState message="No value target set for this project." />
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Shell>
  );
}

function MetaItem({ label, value }: { label: string; value?: string | null }) {
  return (
    <div>
      <p className="text-xs text-muted">{label}</p>
      <p className="mt-0.5 text-sm font-medium capitalize text-text-primary">{value || "—"}</p>
    </div>
  );
}

function MilestoneStatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    complete: "text-emerald-400",
    in_progress: "text-accent",
    delayed: "text-amber-400",
    pending: "text-muted",
  };
  return (
    <span className={cn("text-xs font-medium capitalize", colors[status] || "text-muted")}>{status.replace("_", " ")}</span>
  );
}

function SeverityDot({ severity }: { severity: string }) {
  const colors: Record<string, string> = {
    critical: "bg-red-500",
    high: "bg-orange-500",
    medium: "bg-amber-500",
    low: "bg-blue-500",
  };
  return <div className={cn("mt-1 h-2 w-2 flex-shrink-0 rounded-full", colors[severity] || "bg-muted")} />;
}

function GovernanceCard({ title, value, description }: { title: string; value: string; description?: string }) {
  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <p className="text-xs text-muted">{title}</p>
      <p className="mt-1 text-sm font-medium capitalize text-text-primary">{value}</p>
      {description && <p className="mt-0.5 text-xs text-muted">{description}</p>}
    </div>
  );
}

function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex items-center justify-center py-12 text-sm text-muted">{message}</div>
  );
}
