"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LayoutList, Kanban, Filter, Plus, Search } from "lucide-react";
import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Shell } from "@/components/layout/shell";
import { useProjects } from "@/lib/hooks/use-projects";
import { StagePipeline } from "@/components/projects/stage-pipeline";
import { RAGIndicator } from "@/components/projects/rag-indicator";
import { Sparkline } from "@/components/charts/sparkline";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const AI_PATTERN_LABELS: Record<string, string> = {
  predictive_ml: "Predictive ML",
  gen_ai: "Generative AI",
  agentic: "Agentic",
  cv: "Computer Vision",
  nlp: "NLP",
  recommendation: "Recommendation",
  optimization: "Optimization",
  rpa_ai: "RPA + AI",
};

const AI_PATTERN_COLORS: Record<string, string> = {
  predictive_ml: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  gen_ai: "bg-accent/10 text-accent border-accent/20",
  agentic: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  cv: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  nlp: "bg-pink-500/10 text-pink-400 border-pink-500/20",
  recommendation: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
  optimization: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  rpa_ai: "bg-purple-500/10 text-purple-400 border-purple-500/20",
};

const STAGE_FILTERS = ["all", "ideation", "qualification", "poc", "pilot", "production", "scale", "sunset"];
const RAG_FILTERS = ["all", "green", "amber", "red"];

export default function ProjectsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [view, setView] = useState<"list" | "kanban">("list");
  const [search, setSearch] = useState("");

  const stage = searchParams.get("stage") || "all";
  const rag = searchParams.get("rag") || "all";

  const { data: projects = [], isLoading } = useProjects({
    lifecycle_stage: stage !== "all" ? stage : undefined,
    rag_status: rag !== "all" ? rag : undefined,
    search: search || undefined,
  });

  const setFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value === "all") params.delete(key);
    else params.set(key, value);
    router.push(`/projects?${params.toString()}`);
  };

  return (
    <Shell>
      <div className="space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-text-primary">AI Projects</h1>
            <p className="mt-0.5 text-sm text-muted">
              {isLoading ? "Loading…" : `${projects.length} initiative${projects.length !== 1 ? "s" : ""}`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {/* View toggle */}
            <div className="flex items-center rounded-lg border border-border bg-surface-2 p-0.5">
              <button
                onClick={() => setView("list")}
                className={cn("rounded p-1.5 transition-colors", view === "list" ? "bg-surface text-text-primary" : "text-muted")}
              >
                <LayoutList className="h-4 w-4" />
              </button>
              <button
                onClick={() => setView("kanban")}
                className={cn("rounded p-1.5 transition-colors", view === "kanban" ? "bg-surface text-text-primary" : "text-muted")}
              >
                <Kanban className="h-4 w-4" />
              </button>
            </div>
            <Button size="sm" className="gap-1.5">
              <Plus className="h-3.5 w-3.5" />
              New Project
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 min-w-48">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search projects…"
              className="w-full rounded-lg border border-border bg-surface-2 py-2 pl-9 pr-3 text-sm text-text-primary placeholder:text-muted focus:border-accent/50 focus:outline-none"
            />
          </div>

          {/* Stage filter */}
          <div className="flex items-center gap-1">
            {STAGE_FILTERS.map((s) => (
              <button
                key={s}
                onClick={() => setFilter("stage", s)}
                className={cn(
                  "rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors",
                  stage === s
                    ? "bg-accent/10 text-accent"
                    : "text-muted hover:text-text-secondary"
                )}
              >
                {s === "all" ? "All Stages" : s}
              </button>
            ))}
          </div>

          {/* RAG filter */}
          <div className="flex items-center gap-1">
            {RAG_FILTERS.map((r) => (
              <button
                key={r}
                onClick={() => setFilter("rag", r)}
                className={cn(
                  "rounded-md px-2.5 py-1 text-xs font-medium capitalize transition-colors",
                  rag === r
                    ? "bg-accent/10 text-accent"
                    : "text-muted hover:text-text-secondary"
                )}
              >
                {r === "all" ? "All RAG" : r}
              </button>
            ))}
          </div>
        </div>

        {/* Project list */}
        {isLoading ? (
          <div className="space-y-2">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-16 animate-pulse rounded-lg bg-surface-2" />
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="mb-3 text-4xl">🧠</div>
            <h3 className="text-sm font-medium text-text-primary">No projects found</h3>
            <p className="mt-1 text-xs text-muted">
              Try adjusting your filters or{" "}
              <Link href="/onboarding" className="text-accent hover:underline">onboard a new project</Link>.
            </p>
          </div>
        ) : (
          <div className="rounded-xl border border-border overflow-hidden">
            {/* Table header */}
            <div className="grid grid-cols-[2fr_1fr_120px_100px_100px_80px] gap-4 border-b border-border bg-surface-2 px-4 py-2.5 text-xs font-medium text-muted">
              <span>Project</span>
              <span>Function</span>
              <span>Stage</span>
              <span>RAG</span>
              <span>Trend (8w)</span>
              <span>Deadline</span>
            </div>

            <AnimatePresence>
              {projects.map((project, idx) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.03, duration: 0.2 }}
                >
                  <Link
                    href={`/projects/${project.id}`}
                    className="grid grid-cols-[2fr_1fr_120px_100px_100px_80px] gap-4 items-center border-b border-border px-4 py-3 transition-colors hover:bg-surface-2 last:border-0"
                  >
                    {/* Project name + pattern */}
                    <div className="flex flex-col gap-1 min-w-0">
                      <span className="truncate text-sm font-medium text-text-primary">{project.name}</span>
                      {project.ai_pattern && (
                        <span
                          className={cn(
                            "inline-flex w-fit rounded border px-1.5 py-0.5 text-[10px] font-medium",
                            AI_PATTERN_COLORS[project.ai_pattern] || "bg-surface-2 text-muted border-border"
                          )}
                        >
                          {AI_PATTERN_LABELS[project.ai_pattern] || project.ai_pattern}
                        </span>
                      )}
                    </div>

                    {/* Function */}
                    <span className="truncate text-xs text-muted">{project.sponsoring_function || "—"}</span>

                    {/* Stage pipeline */}
                    <div>
                      <StagePipeline currentStage={project.lifecycle_stage} size="sm" />
                    </div>

                    {/* RAG */}
                    <RAGIndicator status={project.rag_status as any} size="sm" />

                    {/* Sparkline */}
                    <div className="h-8 w-20">
                      <Sparkline
                        data={project.schedule_variance_sparkline || [0, 0, 0, 0, 0, 0, 0, 0]}
                        color={
                          project.rag_status === "red"
                            ? "#EF4444"
                            : project.rag_status === "amber"
                            ? "#F59E0B"
                            : "#10B981"
                        }
                      />
                    </div>

                    {/* Deadline */}
                    <span className="font-mono text-xs text-muted">
                      {project.forecast_end_date
                        ? new Date(project.forecast_end_date).toLocaleDateString("en", {
                            month: "short",
                            day: "numeric",
                          })
                        : "—"}
                    </span>
                  </Link>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </Shell>
  );
}
