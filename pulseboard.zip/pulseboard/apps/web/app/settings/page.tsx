"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Users,
  Link2,
  Shield,
  Trash2,
  Plus,
  CheckCircle,
  AlertCircle,
  Loader2,
  ChevronDown,
  ExternalLink,
} from "lucide-react";

const TABS = [
  { id: "identity", label: "Identity", icon: Shield },
  { id: "integrations", label: "Integrations", icon: Link2 },
  { id: "users", label: "Users", icon: Users },
];

// --- Identity tab ---
function IdentityTab() {
  const qc = useQueryClient();
  const [newMapping, setNewMapping] = useState({
    entra_group_id: "",
    entra_group_name: "",
    bu_id: "",
    function_id: "",
  });
  const [showAddForm, setShowAddForm] = useState(false);

  const { data: mappings, isLoading } = useQuery<any[]>({
    queryKey: ["entra-mappings"],
    queryFn: async () => {
      const res = await fetch("/api/settings/entra-mappings");
      if (!res.ok) throw new Error("Failed");
      return res.json();
    },
  });

  const { data: bus } = useQuery<any[]>({
    queryKey: ["business-units"],
    queryFn: async () => {
      const res = await fetch("/api/business-units");
      return res.json();
    },
  });

  const { data: fns } = useQuery<any[]>({
    queryKey: ["functions"],
    queryFn: async () => {
      const res = await fetch("/api/functions");
      return res.json();
    },
  });

  const addMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/settings/entra-mappings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newMapping),
      });
      if (!res.ok) throw new Error("Failed to add mapping");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["entra-mappings"] });
      setNewMapping({
        entra_group_id: "",
        entra_group_name: "",
        bu_id: "",
        function_id: "",
      });
      setShowAddForm(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await fetch(`/api/settings/entra-mappings/${id}`, { method: "DELETE" });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["entra-mappings"] }),
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white">
          Entra Group Mappings
        </h2>
        <p className="text-sm text-white/40 mt-0.5">
          Map Entra security groups to Business Units and Functions to control
          data access scoping.
        </p>
      </div>

      <div className="bg-[#13131A] border border-white/8 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-10 gap-3 text-white/40">
            <Loader2 size={16} className="animate-spin" />
            <span className="text-sm">Loading mappings…</span>
          </div>
        ) : (
          <>
            {mappings && mappings.length > 0 ? (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/8">
                    <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                      Entra Group
                    </th>
                    <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                      Maps To
                    </th>
                    <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                      Entity
                    </th>
                    <th className="w-12" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {mappings.map((m: any) => (
                    <tr key={m.id} className="hover:bg-white/2 transition-colors">
                      <td className="px-5 py-3">
                        <div className="text-white/80 font-medium">
                          {m.entra_group_name}
                        </div>
                        <div className="text-xs text-white/30 font-mono">
                          {m.entra_group_id}
                        </div>
                      </td>
                      <td className="px-5 py-3 text-white/50 text-xs uppercase tracking-wide">
                        {m.bu_id ? "Business Unit" : "Function"}
                      </td>
                      <td className="px-5 py-3 text-white/70">
                        {m.bu?.name || m.function?.name || "—"}
                      </td>
                      <td className="px-5 py-3">
                        <button
                          onClick={() => deleteMutation.mutate(m.id)}
                          className="text-white/30 hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="text-center py-12 text-white/30 text-sm">
                No group mappings yet. Add your first mapping below.
              </div>
            )}

            <div className="border-t border-white/8 p-4">
              <AnimatePresence>
                {showAddForm && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-4 space-y-3"
                  >
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        placeholder="Entra Group Object ID"
                        value={newMapping.entra_group_id}
                        onChange={(e) =>
                          setNewMapping((m) => ({
                            ...m,
                            entra_group_id: e.target.value,
                          }))
                        }
                        className="bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#8B5CF6]/50"
                      />
                      <input
                        placeholder="Display name (e.g. sg-wealth-team)"
                        value={newMapping.entra_group_name}
                        onChange={(e) =>
                          setNewMapping((m) => ({
                            ...m,
                            entra_group_name: e.target.value,
                          }))
                        }
                        className="bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-[#8B5CF6]/50"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="relative">
                        <select
                          value={newMapping.bu_id}
                          onChange={(e) =>
                            setNewMapping((m) => ({
                              ...m,
                              bu_id: e.target.value,
                              function_id: "",
                            }))
                          }
                          className="w-full appearance-none bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#8B5CF6]/50 pr-8"
                        >
                          <option value="">Select Business Unit</option>
                          {bus?.map((b: any) => (
                            <option key={b.id} value={b.id}>
                              {b.name}
                            </option>
                          ))}
                        </select>
                        <ChevronDown
                          size={13}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none"
                        />
                      </div>
                      <div className="relative">
                        <select
                          value={newMapping.function_id}
                          onChange={(e) =>
                            setNewMapping((m) => ({
                              ...m,
                              function_id: e.target.value,
                              bu_id: "",
                            }))
                          }
                          className="w-full appearance-none bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-[#8B5CF6]/50 pr-8"
                        >
                          <option value="">Select Function</option>
                          {fns?.map((f: any) => (
                            <option key={f.id} value={f.id}>
                              {f.name}
                            </option>
                          ))}
                        </select>
                        <ChevronDown
                          size={13}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 pointer-events-none"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2 justify-end">
                      <button
                        onClick={() => setShowAddForm(false)}
                        className="px-3 py-1.5 text-sm text-white/50 hover:text-white transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => addMutation.mutate()}
                        disabled={
                          addMutation.isPending ||
                          !newMapping.entra_group_id ||
                          (!newMapping.bu_id && !newMapping.function_id)
                        }
                        className="px-4 py-1.5 bg-[#8B5CF6] rounded-lg text-sm text-white hover:bg-[#7c3aed] disabled:opacity-40 transition-all"
                      >
                        {addMutation.isPending ? "Adding…" : "Add Mapping"}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {!showAddForm && (
                <button
                  onClick={() => setShowAddForm(true)}
                  className="flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors"
                >
                  <Plus size={14} />
                  Add Mapping
                </button>
              )}
            </div>
          </>
        )}
      </div>

      <div className="bg-[#13131A] border border-white/8 rounded-xl p-5 space-y-3">
        <h3 className="text-sm font-medium text-white/70">SCIM Provisioning</h3>
        <div className="flex items-center gap-3">
          <div className="flex-1 bg-[#0A0A0F] border border-white/10 rounded-lg px-3 py-2 text-sm text-white/50 font-mono">
            https://api.pulseboard.app/scim/v2
          </div>
          <button className="px-4 py-2 border border-white/15 rounded-lg text-sm text-white/60 hover:text-white transition-colors">
            Generate Token
          </button>
        </div>
        <p className="text-xs text-white/30">
          Configure in{" "}
          <a
            href="https://portal.azure.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#8B5CF6] hover:text-[#a78bfa] inline-flex items-center gap-0.5"
          >
            Azure Portal → Enterprise Applications → PulseBoard → Provisioning
            <ExternalLink size={10} />
          </a>
        </p>
      </div>
    </div>
  );
}

// --- Integrations tab ---
function IntegrationsTab() {
  const { data: instances, isLoading } = useQuery<any[]>({
    queryKey: ["jira-instances"],
    queryFn: async () => {
      const res = await fetch("/api/onboarding/jira/instances");
      return res.json();
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white">Jira Integrations</h2>
        <p className="text-sm text-white/40 mt-0.5">
          Connected Jira instances. Sync runs every 15 minutes.
        </p>
      </div>

      <div className="bg-[#13131A] border border-white/8 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-10 gap-3 text-white/40">
            <Loader2 size={16} className="animate-spin" />
          </div>
        ) : instances && instances.length > 0 ? (
          <div className="divide-y divide-white/5">
            {instances.map((inst: any) => (
              <div
                key={inst.id}
                className="flex items-center gap-4 px-5 py-4"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-white font-medium">
                      {inst.name}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        inst.sync_status === "ok"
                          ? "bg-emerald-500/15 text-emerald-400"
                          : inst.sync_status === "error"
                          ? "bg-red-500/15 text-red-400"
                          : "bg-white/10 text-white/40"
                      }`}
                    >
                      {inst.sync_status}
                    </span>
                  </div>
                  <div className="text-xs text-white/40 font-mono mt-0.5">
                    {inst.base_url}
                  </div>
                </div>
                {inst.last_sync_at && (
                  <span className="text-xs text-white/30 font-mono">
                    Last sync:{" "}
                    {new Date(inst.last_sync_at).toLocaleTimeString()}
                  </span>
                )}
                <button className="text-xs text-[#8B5CF6] hover:text-[#a78bfa] transition-colors">
                  Sync Now
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-white/30 text-sm">
            No Jira instances connected.
          </div>
        )}

        <div className="border-t border-white/8 p-4">
          <a
            href="/onboarding/jira"
            className="flex items-center gap-2 text-sm text-white/50 hover:text-white transition-colors"
          >
            <Plus size={14} />
            Add Jira Instance
          </a>
        </div>
      </div>
    </div>
  );
}

// --- Users tab ---
const ROLE_LABELS: Record<string, string> = {
  "PulseBoard.Admin": "Admin",
  "PulseBoard.Contributor": "Contributor",
  "PulseBoard.Viewer": "Viewer",
};

const ROLE_COLORS: Record<string, string> = {
  "PulseBoard.Admin": "text-[#8B5CF6] bg-[#8B5CF6]/10",
  "PulseBoard.Contributor": "text-sky-400 bg-sky-400/10",
  "PulseBoard.Viewer": "text-white/50 bg-white/8",
};

function UsersTab() {
  const qc = useQueryClient();
  const { data: users, isLoading } = useQuery<any[]>({
    queryKey: ["users"],
    queryFn: async () => {
      const res = await fetch("/api/users");
      return res.json();
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ id, role }: { id: string; role: string }) => {
      const res = await fetch(`/api/users/${id}/role`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role }),
      });
      if (!res.ok) throw new Error("Failed");
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["users"] }),
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-base font-semibold text-white">Users</h2>
        <p className="text-sm text-white/40 mt-0.5">
          All provisioned users. Roles are assigned in Entra but can be overridden here.
        </p>
      </div>

      <div className="bg-[#13131A] border border-white/8 rounded-xl overflow-hidden">
        {isLoading ? (
          <div className="flex items-center justify-center py-10 gap-3 text-white/40">
            <Loader2 size={16} className="animate-spin" />
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/8">
                <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                  User
                </th>
                <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                  Department
                </th>
                <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                  Role
                </th>
                <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                  Last Login
                </th>
                <th className="text-left px-5 py-3 text-xs text-white/40 font-medium uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {users?.map((user: any) => (
                <tr key={user.id} className="hover:bg-white/2 transition-colors">
                  <td className="px-5 py-3">
                    <div className="text-white/80 font-medium">
                      {user.display_name}
                    </div>
                    <div className="text-xs text-white/30">{user.email}</div>
                  </td>
                  <td className="px-5 py-3 text-white/50 text-xs">
                    {user.department || "—"}
                  </td>
                  <td className="px-5 py-3">
                    <div className="relative">
                      <select
                        value={user.role}
                        onChange={(e) =>
                          updateRoleMutation.mutate({
                            id: user.id,
                            role: e.target.value,
                          })
                        }
                        className={`appearance-none text-xs px-2.5 py-1 rounded-full font-medium border-0 cursor-pointer focus:outline-none ${
                          ROLE_COLORS[user.role] || "text-white/50 bg-white/8"
                        }`}
                      >
                        {Object.entries(ROLE_LABELS).map(([value, label]) => (
                          <option key={value} value={value}>
                            {label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </td>
                  <td className="px-5 py-3 text-white/30 text-xs font-mono">
                    {user.last_login_at
                      ? new Date(user.last_login_at).toLocaleDateString()
                      : "Never"}
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full ${
                        user.is_active
                          ? "bg-emerald-500/10 text-emerald-400"
                          : "bg-white/8 text-white/30"
                      }`}
                    >
                      {user.is_active ? "Active" : "Inactive"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// --- Main settings page ---
export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("identity");

  return (
    <div className="min-h-screen bg-[#0A0A0F] px-6 py-10">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-semibold text-white mb-1">Settings</h1>
        <p className="text-white/40 text-sm mb-8">
          Admin configuration for identity, integrations, and user management.
        </p>

        {/* Tab bar */}
        <div className="flex gap-1 mb-8 bg-[#13131A] border border-white/8 rounded-xl p-1 w-fit">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  active ? "text-white" : "text-white/40 hover:text-white/70"
                }`}
              >
                {active && (
                  <motion.div
                    layoutId="settings-tab-bg"
                    className="absolute inset-0 bg-[#8B5CF6]/20 border border-[#8B5CF6]/30 rounded-lg"
                    transition={{ type: "spring", stiffness: 500, damping: 35 }}
                  />
                )}
                <Icon size={14} className="relative z-10" />
                <span className="relative z-10">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === "identity" && <IdentityTab />}
            {activeTab === "integrations" && <IntegrationsTab />}
            {activeTab === "users" && <UsersTab />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
