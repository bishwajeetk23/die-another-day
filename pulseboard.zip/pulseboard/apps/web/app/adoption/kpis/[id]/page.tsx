"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Minus,
  AlertCircle,
  RefreshCw,
} from "lucide-react";
import Link from "next/link";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const GRANULARITY_OPTIONS = [
  { value: "day", label: "Daily" },
  { value: "week", label: "Weekly" },
];

const RANGE_OPTIONS = [
  { value: 14, label: "14d" },
  { value: 30, label: "30d" },
  { value: 90, label: "90d" },
  { value: 180, label: "180d" },
];

function formatValue(value: number, unit: string): string {
  if (unit.includes("%")) return `${value.toFixed(1)}%`;
  if (value >= 1000) return `${(value / 1000).toFixed(1)}k`;
  return value.toFixed(unit.includes("score") ? 2 : 0);
}

const CustomTooltip = ({
  active,
  payload,
  label,
  unit,
}: {
  active?: boolean;
  payload?: any[];
  label?: string;
  unit: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-[#1a1a24] border border-white/15 rounded-lg px-3 py-2 shadow-xl">
      <p className="text-xs text-white/40 mb-1">{label}</p>
      <p className="text-sm text-white font-medium font-mono">
        {formatValue(payload[0].value, unit)} {unit}
      </p>
    </div>
  );
};

export default function KPIDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [granularity, setGranularity] = useState("day");
  const [rangeDays, setRangeDays] = useState(90);
  const [activeDimension, setActiveDimension] = useState<string | null>(null);
  const [chartType, setChartType] = useState<"area" | "bar">("area");

  const { data: kpi, isLoading: kpiLoading } = useQuery<any>({
    queryKey: ["kpi", id],
    queryFn: async () => {
      const res = await fetch(`/api/adoption/kpis/${id}`);
      if (!res.ok) throw new Error("Not found");
      return res.json();
    },
  });

  const { data: values, isLoading: valuesLoading } = useQuery<any>({
    queryKey: ["kpi-values", id, granularity, rangeDays, activeDimension],
    queryFn: async () => {
      const params = new URLSearchParams({
        granularity,
        days: String(rangeDays),
        ...(activeDimension ? { dimension: activeDimension } : {}),
      });
      const res = await fetch(`/api/adoption/kpis/${id}/values?${params}`);
      return res.json();
    },
    enabled: !!id,
  });

  if (kpiLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="flex items-center gap-3 text-white/40">
          <RefreshCw size={18} className="animate-spin" />
          <span className="text-sm">Loading KPI…</span>
        </div>
      </div>
    );
  }

  if (!kpi) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="text-center">
          <AlertCircle size={32} className="text-white/20 mx-auto mb-3" />
          <p className="text-white/40 text-sm">KPI not found</p>
          <Link
            href="/adoption"
            className="text-[#8B5CF6] text-sm hover:text-[#a78bfa] mt-2 inline-block"
          >
            Back to Adoption
          </Link>
        </div>
      </div>
    );
  }

  const series = values?.series || [];
  const currentValue = values?.current_value;
  const trendPct = values?.trend_pct;
  const targetValue = kpi.target_value;
  const progressPct = targetValue
    ? Math.min(100, (currentValue / targetValue) * 100)
    : null;

  const trendIsPositive =
    kpi.direction === "higher_is_better"
      ? (trendPct ?? 0) > 0
      : (trendPct ?? 0) < 0;

  const dimensionGroups: Record<string, any[]> = {};
  if (activeDimension && values?.dimension_data) {
    Object.assign(dimensionGroups, values.dimension_data);
  }

  const hasDimensions =
    kpi.dimension_schema && kpi.dimension_schema.length > 0;

  return (
    <div className="min-h-screen bg-[#0A0A0F] px-6 py-10">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <Link
            href="/adoption"
            className="inline-flex items-center gap-1.5 text-sm text-white/40 hover:text-white/70 mb-4 transition-colors"
          >
            <ArrowLeft size={14} />
            Adoption
          </Link>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-semibold text-white">{kpi.name}</h1>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-xs text-white/40 uppercase tracking-wider">
                  {kpi.category.replace("_", " ")}
                </span>
                <span className="text-white/20">·</span>
                <span className="text-xs text-white/40">
                  {kpi.unit}
                </span>
                <span className="text-white/20">·</span>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full ${
                    kpi.is_stale
                      ? "bg-red-500/10 text-red-400"
                      : "bg-emerald-500/10 text-emerald-400"
                  }`}
                >
                  {kpi.is_stale ? "Stale" : "Live"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Stat cards */}
        <div className="grid grid-cols-3 gap-4">
          {/* Current */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-[#13131A] border border-white/8 rounded-xl p-5"
          >
            <p className="text-xs text-white/40 uppercase tracking-wider mb-2">
              Current
            </p>
            <p className="text-3xl font-bold text-white font-mono">
              {currentValue != null
                ? formatValue(currentValue, kpi.unit)
                : "—"}
            </p>
            <p className="text-xs text-white/30 mt-1">{kpi.unit}</p>
          </motion.div>

          {/* Target */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="bg-[#13131A] border border-white/8 rounded-xl p-5"
          >
            <p className="text-xs text-white/40 uppercase tracking-wider mb-2">
              Target
            </p>
            <p className="text-3xl font-bold text-white font-mono">
              {formatValue(targetValue, kpi.unit)}
            </p>
            {progressPct != null && (
              <div className="mt-2">
                <div className="flex justify-between text-xs text-white/30 mb-1">
                  <span>Progress</span>
                  <span>{progressPct.toFixed(0)}%</span>
                </div>
                <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progressPct}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="h-full bg-[#8B5CF6] rounded-full"
                  />
                </div>
              </div>
            )}
          </motion.div>

          {/* Trend */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-[#13131A] border border-white/8 rounded-xl p-5"
          >
            <p className="text-xs text-white/40 uppercase tracking-wider mb-2">
              Trend ({rangeDays}d)
            </p>
            <div className="flex items-center gap-2">
              {trendPct == null ? (
                <Minus size={20} className="text-white/30" />
              ) : trendIsPositive ? (
                <TrendingUp size={20} className="text-emerald-400" />
              ) : (
                <TrendingDown size={20} className="text-red-400" />
              )}
              <p
                className={`text-3xl font-bold font-mono ${
                  trendPct == null
                    ? "text-white/30"
                    : trendIsPositive
                    ? "text-emerald-400"
                    : "text-red-400"
                }`}
              >
                {trendPct != null
                  ? `${trendPct > 0 ? "+" : ""}${trendPct.toFixed(1)}%`
                  : "—"}
              </p>
            </div>
            <p className="text-xs text-white/30 mt-1">
              vs. {rangeDays} days ago
            </p>
          </motion.div>
        </div>

        {/* Chart controls */}
        <div className="flex items-center justify-between">
          <div className="flex gap-1 bg-[#13131A] border border-white/8 rounded-lg p-1">
            {RANGE_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                onClick={() => setRangeDays(opt.value)}
                className={`px-3 py-1 rounded text-xs font-medium transition-all ${
                  rangeDays === opt.value
                    ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                    : "text-white/40 hover:text-white/70"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex gap-1 bg-[#13131A] border border-white/8 rounded-lg p-1">
              {GRANULARITY_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setGranularity(opt.value)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-all ${
                    granularity === opt.value
                      ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                      : "text-white/40 hover:text-white/70"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            <div className="flex gap-1 bg-[#13131A] border border-white/8 rounded-lg p-1">
              <button
                onClick={() => setChartType("area")}
                className={`px-3 py-1 rounded text-xs font-medium transition-all ${
                  chartType === "area"
                    ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                    : "text-white/40 hover:text-white/70"
                }`}
              >
                Area
              </button>
              <button
                onClick={() => setChartType("bar")}
                className={`px-3 py-1 rounded text-xs font-medium transition-all ${
                  chartType === "bar"
                    ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                    : "text-white/40 hover:text-white/70"
                }`}
              >
                Bar
              </button>
            </div>
          </div>
        </div>

        {/* Main chart */}
        <div className="bg-[#13131A] border border-white/8 rounded-xl p-6">
          {valuesLoading ? (
            <div className="h-64 flex items-center justify-center gap-3 text-white/30">
              <RefreshCw size={16} className="animate-spin" />
              <span className="text-sm">Loading data…</span>
            </div>
          ) : series.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-white/20 text-sm">
              No data for this period
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              {chartType === "area" ? (
                <AreaChart data={series} margin={{ top: 4, right: 4, bottom: 4, left: 4 }}>
                  <defs>
                    <linearGradient id="kpiGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis
                    dataKey="ts"
                    tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "Geist Mono" }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => {
                      const d = new Date(v);
                      return `${d.getMonth() + 1}/${d.getDate()}`;
                    }}
                  />
                  <YAxis
                    tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "Geist Mono" }}
                    axisLine={false}
                    tickLine={false}
                    width={45}
                    tickFormatter={(v) => formatValue(v, kpi.unit)}
                  />
                  <Tooltip content={<CustomTooltip unit={kpi.unit} />} />
                  {targetValue && (
                    <Line
                      type="monotone"
                      dataKey={() => targetValue}
                      stroke="rgba(139,92,246,0.4)"
                      strokeDasharray="4 3"
                      dot={false}
                      name="Target"
                    />
                  )}
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke="#8B5CF6"
                    strokeWidth={2}
                    fill="url(#kpiGrad)"
                    dot={false}
                    activeDot={{ r: 4, fill: "#8B5CF6" }}
                  />
                </AreaChart>
              ) : (
                <BarChart data={series} margin={{ top: 4, right: 4, bottom: 4, left: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                  <XAxis
                    dataKey="ts"
                    tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "Geist Mono" }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => {
                      const d = new Date(v);
                      return `${d.getMonth() + 1}/${d.getDate()}`;
                    }}
                  />
                  <YAxis
                    tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 11, fontFamily: "Geist Mono" }}
                    axisLine={false}
                    tickLine={false}
                    width={45}
                    tickFormatter={(v) => formatValue(v, kpi.unit)}
                  />
                  <Tooltip content={<CustomTooltip unit={kpi.unit} />} />
                  <Bar
                    dataKey="value"
                    fill="#8B5CF6"
                    fillOpacity={0.7}
                    radius={[3, 3, 0, 0]}
                  />
                </BarChart>
              )}
            </ResponsiveContainer>
          )}
        </div>

        {/* Dimension pivot */}
        {hasDimensions && (
          <div className="bg-[#13131A] border border-white/8 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-white">
                Dimension Breakdown
              </h3>
              <div className="flex gap-1">
                <button
                  onClick={() => setActiveDimension(null)}
                  className={`px-3 py-1 rounded text-xs font-medium transition-all ${
                    !activeDimension
                      ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                      : "text-white/40 hover:text-white/70"
                  }`}
                >
                  Total
                </button>
                {kpi.dimension_schema.map((dim: string) => (
                  <button
                    key={dim}
                    onClick={() => setActiveDimension(dim)}
                    className={`px-3 py-1 rounded text-xs font-medium transition-all capitalize ${
                      activeDimension === dim
                        ? "bg-[#8B5CF6]/20 text-[#8B5CF6]"
                        : "text-white/40 hover:text-white/70"
                    }`}
                  >
                    {dim.replace("_", " ")}
                  </button>
                ))}
              </div>
            </div>

            {activeDimension && Object.keys(dimensionGroups).length > 0 ? (
              <div className="space-y-3">
                {Object.entries(dimensionGroups).map(([key, avg]) => {
                  const pct = targetValue
                    ? Math.min(100, ((avg as number) / targetValue) * 100)
                    : 50;
                  return (
                    <div key={key} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-white/60 capitalize">{key}</span>
                        <span className="text-white/40 font-mono">
                          {formatValue(avg as number, kpi.unit)} {kpi.unit}
                        </span>
                      </div>
                      <div className="h-1.5 bg-white/8 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.6, ease: "easeOut" }}
                          className="h-full bg-[#8B5CF6]/60 rounded-full"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-white/30 text-center py-4">
                Select a dimension to see the breakdown
              </p>
            )}
          </div>
        )}

        {/* Ingestion info */}
        <div className="bg-[#13131A] border border-white/8 rounded-xl p-5">
          <h3 className="text-sm font-medium text-white mb-3">
            Ingestion Details
          </h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-xs text-white/40 mb-1">Mode</p>
              <p className="text-white/70 capitalize">
                {kpi.ingestion_mode} API
              </p>
            </div>
            <div>
              <p className="text-xs text-white/40 mb-1">Last Ingested</p>
              <p className="text-white/70 font-mono text-xs">
                {kpi.last_ingested_at
                  ? new Date(kpi.last_ingested_at).toLocaleString()
                  : "Never"}
              </p>
            </div>
            <div>
              <p className="text-xs text-white/40 mb-1">Direction</p>
              <p className="text-white/70 text-sm">
                {kpi.direction === "higher_is_better"
                  ? "↑ Higher is better"
                  : "↓ Lower is better"}
              </p>
            </div>
            <div>
              <p className="text-xs text-white/40 mb-1">Dimensions</p>
              <p className="text-white/70 text-sm">
                {kpi.dimension_schema?.length > 0
                  ? kpi.dimension_schema.join(", ")
                  : "None"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
