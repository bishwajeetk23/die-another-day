"use client";

import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import { Plus, TrendingUp, TrendingDown, Minus, Clock } from "lucide-react";
import Link from "next/link";
import { Shell } from "@/components/layout/shell";
import { useKPIs } from "@/lib/hooks/use-adoption";
import { Sparkline } from "@/components/charts/sparkline";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const CATEGORY_COLORS: Record<string, string> = {
  usage: "bg-blue-500/10 text-blue-400 border-blue-500/20",
  quality: "bg-accent/10 text-accent border-accent/20",
  funnel: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  value_realization: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  health: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  trust_safety: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default function AdoptionPage() {
  const searchParams = useSearchParams();
  const projectId = searchParams.get("project_id") || undefined;
  const category = searchParams.get("category") || undefined;

  const { data: kpis = [], isLoading } = useKPIs({ project_id: projectId, category });

  return (
    <Shell>
      <div className="space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-text-primary">Adoption Analytics</h1>
            <p className="mt-0.5 text-sm text-muted">
              {isLoading ? "Loading…" : `${kpis.length} KPI${kpis.length !== 1 ? "s" : ""} tracked`}
            </p>
          </div>
          <Link href="/onboarding/kpi">
            <Button size="sm" className="gap-1.5">
              <Plus className="h-3.5 w-3.5" />
              Add KPI
            </Button>
          </Link>
        </div>

        {/* Category filter pills */}
        <div className="flex flex-wrap gap-2">
          {["all", "usage", "quality", "funnel", "value_realization", "health", "trust_safety"].map((cat) => {
            const isActive = (category || "all") === cat;
            return (
              <Link
                key={cat}
                href={`/adoption?${projectId ? `project_id=${projectId}&` : ""}category=${cat === "all" ? "" : cat}`}
                className={cn(
                  "rounded-full border px-3 py-1 text-xs font-medium capitalize transition-colors",
                  isActive
                    ? "border-accent/40 bg-accent/10 text-accent"
                    : "border-border text-muted hover:border-border/80 hover:text-text-secondary"
                )}
              >
                {cat === "all" ? "All Categories" : cat.replace("_", " ")}
              </Link>
            );
          })}
        </div>

        {/* KPI grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-36 animate-pulse rounded-xl bg-surface-2" />
            ))}
          </div>
        ) : kpis.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-24 text-center">
            <div className="mb-3 text-4xl">📊</div>
            <h3 className="text-sm font-medium text-text-primary">No KPIs yet</h3>
            <p className="mt-1 text-xs text-muted">
              <Link href="/onboarding/kpi" className="text-accent hover:underline">Onboard your first KPI</Link>{" "}
              to start tracking adoption.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {kpis.map((kpi, idx) => (
              <KPICard key={kpi.id} kpi={kpi} index={idx} />
            ))}
          </div>
        )}
      </div>
    </Shell>
  );
}

function KPICard({ kpi, index }: { kpi: any; index: number }) {
  const pctToTarget =
    kpi.target_value && kpi.latest_value !== undefined
      ? Math.round((kpi.latest_value / kpi.target_value) * 100)
      : null;

  const trend = kpi.trend as "up" | "down" | "flat" | undefined;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, duration: 0.25 }}
    >
      <Link
        href={`/adoption/kpis/${kpi.id}`}
        className="block rounded-xl border border-border bg-surface p-4 transition-colors hover:border-accent/30 hover:bg-surface-2"
      >
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            <span
              className={cn(
                "mb-2 inline-flex rounded border px-1.5 py-0.5 text-[10px] font-medium capitalize",
                CATEGORY_COLORS[kpi.kpi_category] || "bg-surface-2 text-muted border-border"
              )}
            >
              {kpi.kpi_category?.replace("_", " ")}
            </span>
            <h3 className="truncate text-sm font-medium text-text-primary">{kpi.name}</h3>
          </div>
          <TrendIcon trend={trend} />
        </div>

        <div className="mt-3 flex items-end justify-between gap-3">
          <div>
            <p className="font-mono text-2xl font-semibold tabular-nums text-text-primary">
              {kpi.latest_value !== undefined ? kpi.latest_value.toLocaleString() : "—"}
            </p>
            <p className="text-xs text-muted">{kpi.unit}</p>
          </div>

          {/* Sparkline */}
          {kpi.recent_values && (
            <div className="h-10 w-24">
              <Sparkline
                data={kpi.recent_values}
                color={trend === "up" ? "#10B981" : trend === "down" ? "#EF4444" : "#8B5CF6"}
              />
            </div>
          )}
        </div>

        {/* Target progress */}
        {pctToTarget !== null && (
          <div className="mt-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted">Target: {kpi.target_value?.toLocaleString()} {kpi.unit}</span>
              <span className={cn("font-medium", pctToTarget >= 100 ? "text-emerald-400" : pctToTarget >= 75 ? "text-accent" : "text-amber-400")}>
                {pctToTarget}%
              </span>
            </div>
            <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-surface-2">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(pctToTarget, 100)}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className={cn(
                  "h-full rounded-full",
                  pctToTarget >= 100 ? "bg-emerald-500" : pctToTarget >= 75 ? "bg-accent" : "bg-amber-500"
                )}
              />
            </div>
          </div>
        )}

        {/* Staleness indicator */}
        {kpi.last_data_at && (
          <div className="mt-2 flex items-center gap-1 text-xs text-muted">
            <Clock className="h-3 w-3" />
            <span>Updated {new Date(kpi.last_data_at).toLocaleDateString()}</span>
          </div>
        )}
      </Link>
    </motion.div>
  );
}

function TrendIcon({ trend }: { trend?: "up" | "down" | "flat" }) {
  if (trend === "up") return <TrendingUp className="h-4 w-4 text-emerald-400" />;
  if (trend === "down") return <TrendingDown className="h-4 w-4 text-red-400" />;
  return <Minus className="h-4 w-4 text-muted" />;
}
