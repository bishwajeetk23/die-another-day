"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence, useMotionValue, useSpring } from "framer-motion";
import { Send, Sparkles, ChevronDown, ChevronRight, Clock, Zap } from "lucide-react";
import { Shell } from "@/components/layout/shell";
import { useAgentStream } from "@/lib/hooks/use-agent";
import { cn } from "@/lib/utils";
import ReactMarkdown from "react-markdown";
import rehypeHighlight from "rehype-highlight";
import { InlineChart } from "@/components/charts/inline-chart";

// Suggestion chips shown to users by role
const SUGGESTION_CHIPS = [
  "Show me red projects this quarter",
  "Which BUs have the most stuck pilots?",
  "What's the realized vs expected value across the portfolio?",
  "Which models are showing accuracy drift?",
  "Show adoption funnel for HR Policy Bot",
  "What AI projects are blocked by governance?",
];

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  blocks?: Array<{ type: string; spec?: object }>;
  citations?: Array<{ type: string; key: string; label: string; url?: string }>;
  toolCalls?: Array<{ tool: string; duration_ms: number }>;
  streaming?: boolean;
}

export default function AIAssistantPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [expandedReasoning, setExpandedReasoning] = useState<Set<string>>(new Set());
  const [conversationId, setConversationId] = useState<string | undefined>();
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Mouse parallax for background
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const springX = useSpring(mouseX, { stiffness: 50, damping: 30 });
  const springY = useSpring(mouseY, { stiffness: 50, damping: 30 });

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      mouseX.set(e.clientX / window.innerWidth - 0.5);
      mouseY.set(e.clientY / window.innerHeight - 0.5);
    },
    [mouseX, mouseY]
  );

  const { stream } = useAgentStream();

  const scrollToBottom = () => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (text: string) => {
    if (!text.trim() || isStreaming) return;

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: "user",
      content: text.trim(),
    };

    const assistantMsg: Message = {
      id: crypto.randomUUID(),
      role: "assistant",
      content: "",
      streaming: true,
      toolCalls: [],
      blocks: [],
      citations: [],
    };

    setMessages((prev) => [...prev, userMsg, assistantMsg]);
    setInput("");
    setIsStreaming(true);

    try {
      await stream({
        message: text.trim(),
        conversationId,
        onChunk: (chunk) => {
          if (chunk.type === "text_delta") {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsg.id
                  ? { ...m, content: m.content + (chunk.delta || "") }
                  : m
              )
            );
          } else if (chunk.type === "tool_call") {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsg.id
                  ? { ...m, toolCalls: [...(m.toolCalls || []), { tool: chunk.tool, duration_ms: 0 }] }
                  : m
              )
            );
          } else if (chunk.type === "tool_result" && chunk.result?.type === "chart") {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === assistantMsg.id
                  ? { ...m, blocks: [...(m.blocks || []), chunk.result] }
                  : m
              )
            );
          } else if (chunk.type === "done") {
            setConversationId(chunk.conversation_id);
          }
        },
      });
    } catch (err) {
      setMessages((prev) =>
        prev.map((m) =>
          m.id === assistantMsg.id
            ? { ...m, content: "Sorry, something went wrong. Please try again.", streaming: false }
            : m
        )
      );
    } finally {
      setIsStreaming(false);
      setMessages((prev) =>
        prev.map((m) => (m.id === assistantMsg.id ? { ...m, streaming: false } : m))
      );
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend(input);
    }
  };

  const toggleReasoning = (msgId: string) => {
    setExpandedReasoning((prev) => {
      const next = new Set(prev);
      if (next.has(msgId)) next.delete(msgId);
      else next.add(msgId);
      return next;
    });
  };

  const isEmpty = messages.length === 0;

  return (
    <Shell>
      <div className="flex h-full flex-col" onMouseMove={handleMouseMove}>
        {/* Animated gradient mesh background (only on empty state) */}
        {isEmpty && (
          <motion.div
            className="pointer-events-none absolute inset-0 overflow-hidden"
            style={{ zIndex: 0 }}
          >
            <motion.div
              className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-accent/5 blur-3xl"
              style={{ x: springX, y: springY }}
            />
            <motion.div
              className="absolute right-1/4 bottom-1/3 h-64 w-64 rounded-full bg-emerald-500/5 blur-3xl"
              style={{ x: springX, y: springY }}
            />
          </motion.div>
        )}

        {/* Messages area */}
        <div className="relative z-10 flex-1 overflow-y-auto">
          {isEmpty ? (
            // Empty state — landing hero
            <div className="flex h-full flex-col items-center justify-center px-4 py-16 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, ease: "easeOut" }}
              >
                <div className="mb-4 flex items-center justify-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent/10 ring-1 ring-accent/20">
                    <Sparkles className="h-7 w-7 text-accent" />
                  </div>
                </div>
                <h1 className="mb-2 text-2xl font-semibold tracking-tight text-text-primary">
                  Good morning. Your AI portfolio awaits.
                </h1>
                <p className="mb-8 max-w-md text-sm text-muted">
                  Ask anything about your AI initiatives — project status, adoption metrics,
                  governance, risks, or value realization. All answers cite their sources.
                </p>

                {/* Suggestion chips */}
                <div className="flex flex-wrap justify-center gap-2">
                  {SUGGESTION_CHIPS.map((chip) => (
                    <motion.button
                      key={chip}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => handleSend(chip)}
                      className="rounded-full border border-border bg-surface-2 px-4 py-2 text-sm text-text-secondary transition-colors hover:border-accent/40 hover:text-text-primary"
                    >
                      {chip}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            </div>
          ) : (
            // Conversation
            <div className="mx-auto max-w-3xl space-y-6 px-4 py-6">
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className={cn("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}
                  >
                    {msg.role === "assistant" && (
                      <div className="mt-1 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-accent/10">
                        <Zap className="h-3.5 w-3.5 text-accent" />
                      </div>
                    )}

                    <div className={cn("max-w-[80%] space-y-3", msg.role === "user" && "order-first")}>
                      {msg.role === "user" ? (
                        <div className="rounded-2xl bg-accent/10 px-4 py-3 text-sm text-text-primary ring-1 ring-accent/20">
                          {msg.content}
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {/* Tool calls reasoning panel */}
                          {msg.toolCalls && msg.toolCalls.length > 0 && (
                            <button
                              onClick={() => toggleReasoning(msg.id)}
                              className="flex items-center gap-1.5 text-xs text-muted hover:text-text-secondary"
                            >
                              {expandedReasoning.has(msg.id) ? (
                                <ChevronDown className="h-3 w-3" />
                              ) : (
                                <ChevronRight className="h-3 w-3" />
                              )}
                              <span>
                                Used {msg.toolCalls.length} tool{msg.toolCalls.length !== 1 ? "s" : ""}
                              </span>
                            </button>
                          )}

                          <AnimatePresence>
                            {expandedReasoning.has(msg.id) && msg.toolCalls && (
                              <motion.div
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: "auto", opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="overflow-hidden"
                              >
                                <div className="rounded-lg border border-border bg-surface-2 p-3 space-y-1.5">
                                  {msg.toolCalls.map((tc, i) => (
                                    <div key={i} className="flex items-center gap-2 text-xs">
                                      <span className="font-mono text-accent">{tc.tool}</span>
                                      {tc.duration_ms > 0 && (
                                        <span className="ml-auto flex items-center gap-1 text-muted">
                                          <Clock className="h-3 w-3" />
                                          {tc.duration_ms}ms
                                        </span>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </motion.div>
                            )}
                          </AnimatePresence>

                          {/* Message content */}
                          <div className="prose prose-invert prose-sm max-w-none text-text-secondary">
                            <ReactMarkdown rehypePlugins={[rehypeHighlight]}>
                              {msg.content}
                            </ReactMarkdown>
                            {msg.streaming && (
                              <motion.span
                                animate={{ opacity: [1, 0] }}
                                transition={{ repeat: Infinity, duration: 0.8 }}
                                className="inline-block h-4 w-0.5 bg-accent ml-0.5 align-middle"
                              />
                            )}
                          </div>

                          {/* Inline charts */}
                          {msg.blocks && msg.blocks.map((block, i) =>
                            block.type === "chart" ? (
                              <InlineChart key={i} spec={block.spec as any} />
                            ) : null
                          )}

                          {/* Citations */}
                          {msg.citations && msg.citations.length > 0 && (
                            <div className="flex flex-wrap gap-1.5">
                              {msg.citations.map((c) => (
                                <span
                                  key={c.key}
                                  className="cursor-pointer rounded border border-border bg-surface-2 px-2 py-0.5 font-mono text-xs text-muted hover:border-accent/40 hover:text-text-secondary"
                                  title={c.label}
                                >
                                  {c.key}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        {/* Input area */}
        <div className="relative z-10 border-t border-border bg-surface px-4 py-4">
          <div className="mx-auto max-w-3xl">
            <div
              className={cn(
                "relative flex items-end gap-3 rounded-xl border bg-surface-2 px-4 py-3 transition-all duration-200",
                isStreaming
                  ? "border-border"
                  : "border-border focus-within:border-accent/50 focus-within:shadow-[0_0_0_3px_rgba(139,92,246,0.1)]"
              )}
            >
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask anything about your AI portfolio…"
                disabled={isStreaming}
                rows={1}
                className="flex-1 resize-none bg-transparent text-sm text-text-primary placeholder:text-muted focus:outline-none disabled:opacity-50"
                style={{ maxHeight: "120px" }}
              />
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSend(input)}
                disabled={!input.trim() || isStreaming}
                className={cn(
                  "flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg transition-colors",
                  input.trim() && !isStreaming
                    ? "bg-accent text-white hover:bg-accent-dim"
                    : "bg-surface text-muted"
                )}
              >
                {isStreaming ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    className="h-4 w-4 rounded-full border-2 border-transparent border-t-current"
                  />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </motion.button>
            </div>
            <p className="mt-2 text-center text-xs text-muted">
              All answers cite their data sources.{" "}
              <kbd className="rounded bg-surface-2 px-1.5 py-0.5 font-mono text-xs">Enter</kbd> to send,{" "}
              <kbd className="rounded bg-surface-2 px-1.5 py-0.5 font-mono text-xs">Shift+Enter</kbd> for newline.
            </p>
          </div>
        </div>
      </div>
    </Shell>
  );
}
