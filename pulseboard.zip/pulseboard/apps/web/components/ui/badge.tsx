import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-xs font-medium transition-colors',
  {
    variants: {
      variant: {
        default: 'border-accent/30 bg-accent/20 text-accent-light',
        secondary: 'border-border bg-surface-2 text-text-secondary',
        'on-track': 'border-on-track/30 bg-on-track/20 text-on-track',
        'at-risk': 'border-at-risk/30 bg-at-risk/20 text-at-risk',
        'off-track': 'border-off-track/30 bg-off-track/20 text-off-track',
        muted: 'border-border bg-surface text-muted',
        outline: 'border-border bg-transparent text-text-secondary',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export { Badge, badgeVariants };
