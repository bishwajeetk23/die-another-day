"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Command } from "cmdk";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, FolderKanban, BarChart3, ShieldCheck, Plug,
  Settings, Search, ArrowRight, Zap, Moon, Sun, Grid,
} from "lucide-react";
import { useUIStore } from "@/lib/store/ui-store";
import { useProjects } from "@/lib/hooks/use-projects";
import { cn } from "@/lib/utils";

interface CommandItem {
  id: string;
  label: string;
  icon: React.ElementType;
  action: () => void;
  section: string;
  keywords?: string;
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const router = useRouter();
  const { density, setDensity } = useUIStore();
  const { data: projects = [] } = useProjects({});

  // Global ⌘K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const nav = useCallback(
    (href: string) => {
      setOpen(false);
      router.push(href);
    },
    [router]
  );

  const staticItems: CommandItem[] = [
    { id: "ai", label: "Ask AI", icon: Sparkles, action: () => nav("/ai"), section: "Navigate", keywords: "assistant chat" },
    { id: "projects", label: "AI Projects", icon: FolderKanban, action: () => nav("/projects"), section: "Navigate" },
    { id: "adoption", label: "Adoption Analytics", icon: BarChart3, action: () => nav("/adoption"), section: "Navigate" },
    { id: "governance", label: "Governance", icon: ShieldCheck, action: () => nav("/governance"), section: "Navigate" },
    { id: "onboard-jira", label: "Onboard Jira Instance", icon: Plug, action: () => nav("/onboarding/jira"), section: "Onboarding" },
    { id: "onboard-upload", label: "Upload Project Tracker", icon: Plug, action: () => nav("/onboarding/upload"), section: "Onboarding" },
    { id: "onboard-kpi", label: "Define New KPI", icon: BarChart3, action: () => nav("/onboarding/kpi"), section: "Onboarding" },
    { id: "settings", label: "Settings", icon: Settings, action: () => nav("/settings"), section: "Navigate" },
    {
      id: "density-comfortable",
      label: "Density: Comfortable",
      icon: Grid,
      action: () => { setDensity("comfortable"); setOpen(false); },
      section: "Preferences",
    },
    {
      id: "density-compact",
      label: "Density: Compact",
      icon: Grid,
      action: () => { setDensity("compact"); setOpen(false); },
      section: "Preferences",
    },
    {
      id: "density-tactical",
      label: "Density: Tactical",
      icon: Grid,
      action: () => { setDensity("tactical"); setOpen(false); },
      section: "Preferences",
    },
  ];

  const projectItems: CommandItem[] = projects.slice(0, 10).map((p) => ({
    id: `project-${p.id}`,
    label: p.name,
    icon: FolderKanban,
    action: () => nav(`/projects/${p.id}`),
    section: "Projects",
    keywords: p.ai_pattern,
  }));

  const allItems = [...staticItems, ...projectItems];

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />

          {/* Palette */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -12 }}
            transition={{ type: "spring", stiffness: 500, damping: 40 }}
            className="fixed inset-x-0 top-24 z-50 mx-auto w-full max-w-xl px-4"
          >
            <Command
              className="overflow-hidden rounded-xl border border-border bg-surface shadow-2xl shadow-black/50"
              shouldFilter={true}
            >
              <div className="flex items-center gap-2 border-b border-border px-4 py-3">
                <Search className="h-4 w-4 flex-shrink-0 text-muted" />
                <Command.Input
                  value={search}
                  onValueChange={setSearch}
                  placeholder="Search or ask AI…"
                  className="flex-1 bg-transparent text-sm text-text-primary placeholder:text-muted focus:outline-none"
                  autoFocus
                />
                <kbd className="hidden rounded bg-surface-2 px-1.5 py-0.5 font-mono text-xs text-muted sm:block">
                  ESC
                </kbd>
              </div>

              <Command.List className="max-h-80 overflow-y-auto p-2 pb-3">
                <Command.Empty className="py-8 text-center text-sm text-muted">
                  No results. Try a project name or ask a question.
                </Command.Empty>

                {/* Ask AI — always first if there's a query */}
                {search.length > 3 && (
                  <Command.Group heading="">
                    <Command.Item
                      value={`ask-ai-${search}`}
                      onSelect={() => {
                        setOpen(false);
                        router.push(`/ai?q=${encodeURIComponent(search)}`);
                      }}
                      className="flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2.5 text-sm aria-selected:bg-accent/10"
                    >
                      <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent/10">
                        <Sparkles className="h-3.5 w-3.5 text-accent" />
                      </div>
                      <div>
                        <p className="font-medium text-text-primary">Ask AI: "{search}"</p>
                        <p className="text-xs text-muted">Get an AI-powered answer about your portfolio</p>
                      </div>
                      <ArrowRight className="ml-auto h-3.5 w-3.5 text-muted" />
                    </Command.Item>
                  </Command.Group>
                )}

                {/* Grouped items */}
                {["Navigate", "Onboarding", "Projects", "Preferences"].map((section) => {
                  const sectionItems = allItems.filter((i) => i.section === section);
                  if (sectionItems.length === 0) return null;
                  return (
                    <Command.Group key={section} heading={section} className="[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-muted">
                      {sectionItems.map((item) => (
                        <Command.Item
                          key={item.id}
                          value={`${item.label} ${item.keywords || ""}`}
                          onSelect={item.action}
                          className="flex cursor-pointer items-center gap-2.5 rounded-lg px-3 py-2 text-sm text-text-secondary aria-selected:bg-surface-2 aria-selected:text-text-primary"
                        >
                          <item.icon className="h-4 w-4 flex-shrink-0" />
                          {item.label}
                        </Command.Item>
                      ))}
                    </Command.Group>
                  );
                })}
              </Command.List>
            </Command>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
