"use client";

import { Bell, Moon, Sun, Monitor } from "lucide-react";
import { useUIStore } from "@/lib/store/ui-store";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Topbar() {
  const { density, setDensity } = useUIStore();

  return (
    <header className="flex h-14 items-center justify-between border-b border-border bg-surface px-6">
      <div className="flex items-center gap-2">
        {/* Breadcrumb / page title injected via context — placeholder */}
      </div>

      <div className="flex items-center gap-2">
        {/* Density switcher */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="text-xs text-muted">
              {density === "comfortable" ? "Comfortable" : density === "compact" ? "Compact" : "Tactical"}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setDensity("comfortable")}>Comfortable</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setDensity("compact")}>Compact</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setDensity("tactical")}>Tactical</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Notifications */}
        <Button variant="ghost" size="icon" className="text-muted hover:text-text-primary">
          <Bell className="h-4 w-4" />
        </Button>

        {/* User avatar */}
        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-accent/20 text-xs font-medium text-accent">
          P
        </div>
      </div>
    </header>
  );
}
