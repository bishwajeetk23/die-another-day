"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  Sparkles,
  FolderKanban,
  BarChart3,
  ShieldCheck,
  Plug,
  Settings,
  ChevronRight,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/ai", label: "AI Assistant", icon: Sparkles, badge: null },
  { href: "/projects", label: "AI Projects", icon: FolderKanban, badge: null },
  { href: "/adoption", label: "Adoption", icon: BarChart3, badge: null },
  { href: "/governance", label: "Governance", icon: ShieldCheck, badge: null },
  { href: "/onboarding", label: "Onboarding", icon: Plug, badge: null },
  { href: "/settings", label: "Settings", icon: Settings, badge: null },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex w-56 flex-col border-r border-border bg-surface">
      {/* Logo */}
      <div className="flex h-14 items-center gap-2.5 border-b border-border px-4">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent">
          <Zap className="h-4 w-4 text-white" />
        </div>
        <span className="font-semibold tracking-tight text-text-primary">PulseBoard</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-0.5 p-2 pt-3">
        {navItems.map((item) => {
          const isActive = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "group relative flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-accent/10 text-accent"
                  : "text-text-secondary hover:bg-surface-2 hover:text-text-primary"
              )}
            >
              {isActive && (
                <motion.div
                  layoutId="sidebar-active"
                  className="absolute inset-0 rounded-md bg-accent/10"
                  initial={false}
                  transition={{ type: "spring", stiffness: 500, damping: 40 }}
                />
              )}
              <item.icon className="relative z-10 h-4 w-4 flex-shrink-0" />
              <span className="relative z-10">{item.label}</span>
              {item.badge && (
                <span className="relative z-10 ml-auto rounded-full bg-accent/20 px-1.5 py-0.5 text-xs text-accent">
                  {item.badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Keyboard hint */}
      <div className="border-t border-border p-3">
        <div className="flex items-center gap-2 rounded-md bg-surface-2 px-3 py-2 text-xs text-muted">
          <kbd className="rounded bg-border px-1.5 py-0.5 font-mono text-xs">⌘K</kbd>
          <span>Command palette</span>
        </div>
      </div>
    </aside>
  );
}
