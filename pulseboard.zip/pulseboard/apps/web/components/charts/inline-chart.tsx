"use client";

import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from "recharts";

interface ChartSpec {
  chart_type: "line" | "bar" | "area" | "funnel" | "scatter";
  title: string;
  data: Array<Record<string, unknown>>;
  x_key: string;
  y_keys: string[];
  colors?: string[];
}

const DEFAULT_COLORS = ["#8B5CF6", "#10B981", "#F59E0B", "#EF4444", "#3B82F6"];

const AXIS_STYLE = {
  fill: "#6B7280",
  fontSize: 11,
  fontFamily: "var(--font-geist-mono)",
};

const GRID_STYLE = {
  stroke: "rgba(255,255,255,0.05)",
  strokeWidth: 1,
};

const TOOLTIP_STYLE = {
  contentStyle: {
    background: "#13131A",
    border: "1px solid #2A2A3A",
    borderRadius: "8px",
    fontSize: "12px",
    color: "#F8F8FC",
  },
};

export function InlineChart({ spec }: { spec: ChartSpec }) {
  const colors = spec.colors || DEFAULT_COLORS;

  const renderChart = () => {
    switch (spec.chart_type) {
      case "bar":
        return (
          <BarChart data={spec.data}>
            <CartesianGrid {...GRID_STYLE} />
            <XAxis dataKey={spec.x_key} tick={AXIS_STYLE} />
            <YAxis tick={AXIS_STYLE} />
            <Tooltip {...TOOLTIP_STYLE} />
            <Legend />
            {spec.y_keys.map((key, i) => (
              <Bar key={key} dataKey={key} fill={colors[i % colors.length]} radius={[3, 3, 0, 0]} />
            ))}
          </BarChart>
        );
      case "area":
        return (
          <AreaChart data={spec.data}>
            <defs>
              {spec.y_keys.map((key, i) => (
                <linearGradient key={key} id={`grad-${i}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={colors[i % colors.length]} stopOpacity={0.2} />
                  <stop offset="95%" stopColor={colors[i % colors.length]} stopOpacity={0} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid {...GRID_STYLE} />
            <XAxis dataKey={spec.x_key} tick={AXIS_STYLE} />
            <YAxis tick={AXIS_STYLE} />
            <Tooltip {...TOOLTIP_STYLE} />
            <Legend />
            {spec.y_keys.map((key, i) => (
              <Area
                key={key}
                type="monotone"
                dataKey={key}
                stroke={colors[i % colors.length]}
                fill={`url(#grad-${i})`}
                strokeWidth={1.5}
              />
            ))}
          </AreaChart>
        );
      default: // line
        return (
          <LineChart data={spec.data}>
            <CartesianGrid {...GRID_STYLE} />
            <XAxis dataKey={spec.x_key} tick={AXIS_STYLE} />
            <YAxis tick={AXIS_STYLE} />
            <Tooltip {...TOOLTIP_STYLE} />
            <Legend />
            {spec.y_keys.map((key, i) => (
              <Line
                key={key}
                type="monotone"
                dataKey={key}
                stroke={colors[i % colors.length]}
                strokeWidth={1.5}
                dot={false}
                activeDot={{ r: 4 }}
              />
            ))}
          </LineChart>
        );
    }
  };

  return (
    <div className="rounded-lg border border-border bg-surface-2 p-4">
      {spec.title && (
        <h4 className="mb-3 text-sm font-medium text-text-secondary">{spec.title}</h4>
      )}
      <ResponsiveContainer width="100%" height={220}>
        {renderChart() as React.ReactElement}
      </ResponsiveContainer>
    </div>
  );
}
