"use client";

import { LineChart, Line, ResponsiveContainer, Tooltip } from "recharts";

interface SparklineProps {
  data: number[];
  color?: string;
  height?: number;
}

export function Sparkline({ data, color = "#8B5CF6", height = 32 }: SparklineProps) {
  const chartData = data.map((v, i) => ({ i, v }));

  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={chartData}>
        <Line
          type="monotone"
          dataKey="v"
          stroke={color}
          strokeWidth={1.5}
          dot={false}
          animationDuration={600}
        />
        <Tooltip
          contentStyle={{
            background: "#13131A",
            border: "1px solid #2A2A3A",
            borderRadius: "6px",
            fontSize: "11px",
            color: "#F8F8FC",
          }}
          formatter={(val: number) => [val, ""]}
          labelFormatter={() => ""}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
