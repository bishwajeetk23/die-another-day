"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type RAGStatus = "green" | "amber" | "red";

interface RAGIndicatorProps {
  status: RAGStatus;
  showLabel?: boolean;
  size?: "sm" | "md";
  className?: string;
}

const CONFIG: Record<RAGStatus, { color: string; pulse: string; label: string; textColor: string }> = {
  green: {
    color: "bg-emerald-500",
    pulse: "bg-emerald-500/30",
    label: "On Track",
    textColor: "text-emerald-400",
  },
  amber: {
    color: "bg-amber-500",
    pulse: "bg-amber-500/30",
    label: "At Risk",
    textColor: "text-amber-400",
  },
  red: {
    color: "bg-red-500",
    pulse: "bg-red-500/30",
    label: "Off Track",
    textColor: "text-red-400",
  },
};

export function RAGIndicator({ status, showLabel = true, size = "sm", className }: RAGIndicatorProps) {
  const cfg = CONFIG[status] || CONFIG.green;
  const dotSize = size === "sm" ? "h-2 w-2" : "h-2.5 w-2.5";
  const pulseSize = size === "sm" ? "h-4 w-4" : "h-5 w-5";

  return (
    <div className={cn("flex items-center gap-1.5", className)}>
      <div className="relative flex items-center justify-center">
        {/* Pulse ring (only for amber/red — on-track doesn't need to scream) */}
        {status !== "green" && (
          <motion.div
            className={cn("absolute rounded-full", pulseSize, cfg.pulse)}
            animate={{ scale: [1, 1.6, 1], opacity: [0.8, 0, 0.8] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          />
        )}
        <div className={cn("relative z-10 rounded-full", dotSize, cfg.color)} />
      </div>
      {showLabel && (
        <span className={cn("text-xs font-medium", cfg.textColor)}>{cfg.label}</span>
      )}
    </div>
  );
}
