"use client";

import { motion } from "framer-motion";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const STAGES = [
  { key: "ideation", label: "Ideation", short: "I" },
  { key: "qualification", label: "Qualification", short: "Q" },
  { key: "poc", label: "PoC", short: "P" },
  { key: "pilot", label: "Pilot", short: "Pl" },
  { key: "production", label: "Production", short: "Pr" },
  { key: "scale", label: "Scale", short: "S" },
  { key: "sunset", label: "Sunset", short: "Su" },
];

interface StagePipelineProps {
  currentStage: string;
  size?: "sm" | "md" | "lg";
  className?: string;
  showLabels?: boolean;
}

export function StagePipeline({
  currentStage,
  size = "md",
  className,
  showLabels = false,
}: StagePipelineProps) {
  const currentIdx = STAGES.findIndex((s) => s.key === currentStage);

  const dotSize = size === "sm" ? "h-2 w-2" : size === "lg" ? "h-3.5 w-3.5" : "h-2.5 w-2.5";
  const lineH = size === "sm" ? "h-px" : "h-px";

  return (
    <TooltipProvider delayDuration={100}>
      <div className={cn("flex items-center gap-0", className)}>
        {STAGES.map((stage, idx) => {
          const isPast = idx < currentIdx;
          const isCurrent = idx === currentIdx;
          const isFuture = idx > currentIdx;

          return (
            <div key={stage.key} className="flex items-center">
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="relative flex items-center justify-center">
                    {isCurrent && (
                      <motion.div
                        className="absolute rounded-full bg-accent/30"
                        style={{ width: "200%", height: "200%" }}
                        animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
                        transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                      />
                    )}
                    <motion.div
                      initial={false}
                      animate={{
                        backgroundColor: isCurrent
                          ? "#8B5CF6"
                          : isPast
                          ? "#6D46D3"
                          : "rgba(139,92,246,0.15)",
                        scale: isCurrent ? 1.2 : 1,
                      }}
                      transition={{ type: "spring", stiffness: 500, damping: 40 }}
                      className={cn(
                        "relative z-10 rounded-full border transition-all",
                        dotSize,
                        isCurrent
                          ? "border-accent shadow-[0_0_8px_rgba(139,92,246,0.6)]"
                          : isPast
                          ? "border-accent/60"
                          : "border-border"
                      )}
                    />
                    {showLabels && (
                      <span
                        className={cn(
                          "absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px]",
                          isCurrent ? "text-accent" : "text-muted"
                        )}
                      >
                        {stage.short}
                      </span>
                    )}
                  </div>
                </TooltipTrigger>
                <TooltipContent side="top" className="text-xs">
                  {stage.label}
                  {isCurrent && " — Current"}
                  {isPast && " — Complete"}
                </TooltipContent>
              </Tooltip>

              {/* Connector line */}
              {idx < STAGES.length - 1 && (
                <div className={cn("w-4 flex-shrink-0", lineH)}>
                  <motion.div
                    className={cn("h-full", lineH)}
                    initial={false}
                    animate={{
                      backgroundColor: idx < currentIdx ? "#6D46D3" : "rgba(139,92,246,0.15)",
                    }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </TooltipProvider>
  );
}
