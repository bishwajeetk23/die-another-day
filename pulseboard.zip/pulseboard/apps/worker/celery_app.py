"""Celery application configuration."""
from __future__ import annotations

from celery import Celery
from celery.schedules import crontab

from pulseboard.config import get_settings

settings = get_settings()

app = Celery(
    "pulseboard",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=[
        "apps.worker.tasks.jira_sync",
        "apps.worker.tasks.kpi_pipeline",
        "apps.worker.tasks.snapshot",
        "apps.worker.tasks.digest",
        "apps.worker.tasks.rag_auto",
    ],
)

app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "apps.worker.tasks.jira_sync.*": {"queue": "sync"},
        "apps.worker.tasks.kpi_pipeline.*": {"queue": "pipeline"},
        "apps.worker.tasks.snapshot.*": {"queue": "default"},
        "apps.worker.tasks.digest.*": {"queue": "notifications"},
        "apps.worker.tasks.rag_auto.*": {"queue": "default"},
    },
    beat_schedule={
        # Jira sync every 15 minutes
        "jira-sync-all": {
            "task": "apps.worker.tasks.jira_sync.sync_all_instances",
            "schedule": crontab(minute="*/15"),
        },
        # Daily project snapshot at midnight UTC
        "project-snapshot-daily": {
            "task": "apps.worker.tasks.snapshot.snapshot_all_projects",
            "schedule": crontab(hour=0, minute=0),
        },
        # Auto-RAG recalculation every hour
        "rag-auto-recalculate": {
            "task": "apps.worker.tasks.rag_auto.recalculate_all_rag",
            "schedule": crontab(minute=0),
        },
        # Weekly digest every Monday at 8am UTC
        "weekly-digest": {
            "task": "apps.worker.tasks.digest.send_weekly_digests",
            "schedule": crontab(hour=8, minute=0, day_of_week=1),
        },
        # KPI pipeline polling every 30 minutes
        "kpi-pipeline-poll": {
            "task": "apps.worker.tasks.kpi_pipeline.run_all_pull_pipelines",
            "schedule": crontab(minute="*/30"),
        },
    },
)
