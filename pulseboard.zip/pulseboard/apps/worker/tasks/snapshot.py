"""Daily project history snapshot task."""
from __future__ import annotations

import asyncio
from datetime import date, datetime, timezone

from apps.worker.celery_app import app


@app.task(name="apps.worker.tasks.snapshot.snapshot_all_projects")
def snapshot_all_projects() -> dict:
    return asyncio.run(_snapshot())


async def _snapshot() -> dict:
    from pulseboard.database import AsyncSessionLocal
    from pulseboard.models.project import AIProject, AIProjectHistorySnapshot
    from sqlalchemy import select

    async with AsyncSessionLocal() as db:
        result = await db.execute(select(AIProject))
        projects = result.scalars().all()
        today = date.today()
        created = 0

        for p in projects:
            variance = None
            if p.forecast_end_date and p.baseline_end_date:
                variance = (p.forecast_end_date - p.baseline_end_date).days

            budget_variance = None
            if p.actual_spend and p.baseline_budget and p.baseline_budget > 0:
                budget_variance = float((p.actual_spend - p.baseline_budget) / p.baseline_budget * 100)

            snap = AIProjectHistorySnapshot(
                project_id=p.id,
                snapshot_date=today,
                lifecycle_stage=p.lifecycle_stage,
                rag=p.rag_status,
                schedule_variance_days=variance,
                budget_variance_pct=budget_variance,
                realized_value_amount=p.realized_value_amount,
            )
            db.add(snap)
            created += 1

        await db.commit()
        return {"snapshots_created": created, "date": str(today)}
