"""Auto-calculate RAG status from schedule variance."""
from __future__ import annotations

import asyncio
from datetime import date

from apps.worker.celery_app import app


@app.task(name="apps.worker.tasks.rag_auto.recalculate_all_rag")
def recalculate_all_rag() -> dict:
    return asyncio.run(_recalculate())


async def _recalculate() -> dict:
    from pulseboard.database import AsyncSessionLocal
    from pulseboard.models.project import AIProject
    from sqlalchemy import select

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(AIProject).where(AIProject.lifecycle_stage.notin_(["sunset", "production", "scale"]))
        )
        projects = result.scalars().all()
        updated = 0

        for p in projects:
            new_rag = _compute_rag(p)
            if new_rag != p.rag_status:
                p.rag_status = new_rag
                updated += 1

        await db.commit()
        return {"projects_updated": updated}


def _compute_rag(project) -> str:
    """Simple RAG heuristic based on schedule variance."""
    if not project.forecast_end_date or not project.baseline_end_date:
        return project.rag_status  # Keep existing

    variance_days = (project.forecast_end_date - project.baseline_end_date).days

    if variance_days <= 7:
        return "green"
    elif variance_days <= 21:
        return "amber"
    else:
        return "red"
