"""Jira sync task — syncs tickets for all linked projects."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from apps.worker.celery_app import app

log = logging.getLogger(__name__)


@app.task(name="apps.worker.tasks.jira_sync.sync_all_instances", bind=True, max_retries=3)
def sync_all_instances(self, instance_id: str | None = None) -> dict[str, Any]:
    """Sync all Jira instances (or a specific one)."""
    return asyncio.run(_sync_all(instance_id))


async def _sync_all(instance_id: str | None) -> dict[str, Any]:
    from pulseboard.database import AsyncSessionLocal
    from pulseboard.models.jira import JiraInstance, JiraProjectLink, JiraTicketCache
    from pulseboard.integrations.jira.client import JiraClient
    from sqlalchemy import select
    from datetime import datetime, timezone

    async with AsyncSessionLocal() as db:
        stmt = select(JiraInstance).where(JiraInstance.status == "connected")
        if instance_id:
            stmt = stmt.where(JiraInstance.id == instance_id)
        result = await db.execute(stmt)
        instances = result.scalars().all()

        synced = 0
        errors = 0
        for instance in instances:
            try:
                client = JiraClient(instance)
                links_result = await db.execute(
                    select(JiraProjectLink).where(
                        JiraProjectLink.jira_instance_id == instance.id,
                        JiraProjectLink.sync_enabled == True,
                    )
                )
                links = links_result.scalars().all()

                for link in links:
                    try:
                        issues = await client.sync_project(link.jira_project_key)
                        for issue in issues:
                            fields = issue.get("fields", {})
                            ticket = JiraTicketCache(
                                jira_project_link_id=link.id,
                                ticket_key=issue["key"],
                                summary=fields.get("summary", ""),
                                status=fields.get("status", {}).get("name", ""),
                                assignee=(fields.get("assignee") or {}).get("displayName"),
                                story_points=fields.get("story_points") or fields.get("customfield_10028"),
                                sprint=str(fields.get("sprint", {}).get("name", "")) if fields.get("sprint") else None,
                                updated_at=datetime.now(timezone.utc),
                            )
                            await db.merge(ticket)
                        synced += len(issues)
                    except Exception as e:
                        log.error("jira_sync.link_error", link_id=str(link.id), error=str(e))
                        errors += 1

                instance.last_sync_at = datetime.now(timezone.utc)
                await db.commit()
            except Exception as e:
                log.error("jira_sync.instance_error", instance_id=str(instance.id), error=str(e))
                errors += 1

        return {"synced_tickets": synced, "errors": errors}


@app.task(name="apps.worker.tasks.jira_sync.jira_sync_task")
def jira_sync_task(instance_id: str | None = None) -> None:
    sync_all_instances.delay(instance_id)
