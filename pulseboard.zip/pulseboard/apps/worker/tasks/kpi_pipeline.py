"""KPI pipeline task — pull data from configured external sources."""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from apps.worker.celery_app import app

log = logging.getLogger(__name__)


@app.task(name="apps.worker.tasks.kpi_pipeline.run_all_pull_pipelines")
def run_all_pull_pipelines() -> dict:
    return asyncio.run(_run_pipelines())


async def _run_pipelines() -> dict:
    from pulseboard.database import AsyncSessionLocal
    from pulseboard.models.adoption import AdoptionKPI, AdoptionKPIPipeline, AdoptionKPIValue
    from sqlalchemy import select, and_

    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(AdoptionKPI).where(
                and_(
                    AdoptionKPI.ingestion_mode.in_(["api_pull", "pipeline"]),
                )
            )
        )
        kpis = result.scalars().all()

        succeeded = 0
        failed = 0

        for kpi in kpis:
            try:
                value = await _fetch_kpi_value(kpi)
                if value is not None:
                    kpi_value = AdoptionKPIValue(
                        kpi_id=kpi.id,
                        ts=datetime.now(timezone.utc),
                        value=value,
                        dimensions_json={},
                    )
                    db.add(kpi_value)

                    # Update pipeline status
                    pipeline_result = await db.execute(
                        select(AdoptionKPIPipeline).where(AdoptionKPIPipeline.kpi_id == kpi.id)
                    )
                    pipeline = pipeline_result.scalar_one_or_none()
                    if pipeline:
                        pipeline.last_run_at = datetime.now(timezone.utc)
                        pipeline.status = "active"
                        pipeline.last_error = None

                    succeeded += 1
            except Exception as e:
                log.error("kpi_pipeline.error", kpi_id=str(kpi.id), error=str(e))
                failed += 1

                # Record error in pipeline
                pipeline_result = await db.execute(
                    select(AdoptionKPIPipeline).where(AdoptionKPIPipeline.kpi_id == kpi.id)
                )
                pipeline = pipeline_result.scalar_one_or_none()
                if pipeline:
                    pipeline.last_error = str(e)
                    pipeline.status = "error"

        await db.commit()
        return {"succeeded": succeeded, "failed": failed}


async def _fetch_kpi_value(kpi) -> float | None:
    """Fetch a value from the configured source."""
    config = kpi.source_config_json or {}

    if kpi.ingestion_mode == "api_pull":
        import httpx
        endpoint = config.get("endpoint")
        if not endpoint:
            return None
        headers = {}
        if config.get("auth_type") == "bearer":
            headers["Authorization"] = f"Bearer {config.get('token', '')}"
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(endpoint, headers=headers)
            resp.raise_for_status()
            data = resp.json()
            # JMESPath extraction
            jmespath_expr = config.get("jmespath", "value")
            try:
                import jmespath  # type: ignore
                return float(jmespath.search(jmespath_expr, data) or 0)
            except Exception:
                return float(data.get("value", 0))

    elif kpi.ingestion_mode == "pipeline":
        # SQL pipeline — execute against BigQuery
        sql = config.get("sql")
        if not sql:
            return None
        from google.cloud import bigquery  # type: ignore
        client = bigquery.Client()
        results = client.query(sql).result()
        for row in results:
            return float(row.get("value", 0))

    return None
