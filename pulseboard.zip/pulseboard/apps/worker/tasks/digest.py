"""Monday morning weekly digest email task."""
from __future__ import annotations

import asyncio
import logging

from apps.worker.celery_app import app

log = logging.getLogger(__name__)


@app.task(name="apps.worker.tasks.digest.send_weekly_digests")
def send_weekly_digests() -> dict:
    return asyncio.run(_send_digests())


async def _send_digests() -> dict:
    from pulseboard.database import AsyncSessionLocal
    from pulseboard.models.project import AIProject
    from pulseboard.models.user import User
    from sqlalchemy import select, func

    async with AsyncSessionLocal() as db:
        # Get all BU/Function heads
        heads_result = await db.execute(select(User).where(User.app_role.in_(["PulseBoard.Admin", "PulseBoard.Contributor"])))
        users = heads_result.scalars().all()

        # Portfolio summary
        rag_counts = await db.execute(
            select(AIProject.rag_status, func.count(AIProject.id)).group_by(AIProject.rag_status)
        )
        rag_summary = {row[0]: row[1] for row in rag_counts}

        emails_sent = 0
        for user in users:
            try:
                await _send_digest_email(user, rag_summary)
                emails_sent += 1
            except Exception as e:
                log.error("digest.send_error", user_id=str(user.id), error=str(e))

        return {"emails_sent": emails_sent}


async def _send_digest_email(user, rag_summary: dict) -> None:
    """Send a weekly digest email. In production, use SendGrid or SES."""
    total = sum(rag_summary.values())
    red = rag_summary.get("red", 0)
    amber = rag_summary.get("amber", 0)
    green = rag_summary.get("green", 0)

    body = f"""
Good morning {user.name.split()[0]},

Here's your PulseBoard AI Portfolio Weekly Digest:

📊 PORTFOLIO SUMMARY
• Total active AI initiatives: {total}
• 🟢 On Track: {green}
• 🟡 At Risk: {amber}
• 🔴 Off Track: {red}

Open PulseBoard for the full picture and AI-powered insights:
https://app.pulseboard.ai

-- The PulseBoard AI Assistant
    """.strip()

    log.info("digest.email_prepared", to=user.email, subject="Your Monday AI Portfolio Digest")
    # TODO: integrate with email provider (SendGrid/SES)
    # await send_email(to=user.email, subject="Your Monday AI Portfolio Digest", body=body)
