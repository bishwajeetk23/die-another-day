# PulseBoard — AI Project & Adoption Intelligence Platform

> **Know your AI portfolio. Prove its value. Accelerate adoption.**

---

## 60-Second Pitch

Every enterprise running an AI programme faces the same invisible problem: dozens of AI initiatives scattered across business units, each tracked differently (or not at all), with no shared view of what is live, what is struggling, and what the business is actually getting back.

PulseBoard solves this. It is a single-pane-of-glass intelligence platform built for Chief AI Officers and their teams. Connect your Jira projects, push adoption metrics from your data pipelines, and in minutes you have:

- A real-time portfolio view across every AI project, BU, and lifecycle stage
- Automatic RAG status derived from schedule variance and model health signals
- Natural-language querying ("Which Gen AI pilots in Wealth have usage below target?")
- Weekly digests delivered Monday morning to every BU/Function Head
- Model drift detection that alerts before users notice quality degradation
- Audit-ready governance snapshots for model risk and regulatory reporting

PulseBoard is built for enterprise: it authenticates via Microsoft Entra ID (SSO + SCIM), stores data in your GCP project, and never sends your data to third-party model providers without your explicit configuration.

---

## Architecture Diagram

```mermaid
flowchart TD
    subgraph Users
        CAIO["CAIO / AI PMO"]
        BUHead["BU / Function Head"]
        PO["AI Product Owner"]
        AE["AI Engineer"]
    end

    subgraph Frontend["Frontend (Next.js 14 · Cloud Run)"]
        Web["pulseboard-web\nNext.js App Router"]
        CP["Command Palette\n(NL Query)"]
    end

    subgraph Auth["Identity (Microsoft Entra ID)"]
        MSAL["MSAL / OAuth 2.0\nOIDC Token"]
        AppRoles["App Roles\nAdmin · Contributor · Viewer"]
        SCIM["SCIM Provisioning"]
    end

    subgraph API["Backend API (FastAPI · Cloud Run)"]
        Router["REST Routers\n/projects /kpis /insights /users"]
        AuthMW["JWT Middleware\n+ RBAC"]
        Agent["AI Agent Layer\n(Vertex AI Gemini)"]
        BQ_SVC["BigQuery Service"]
    end

    subgraph Workers["Async Workers (Celery · Cloud Run)"]
        JiraSync["jira_sync\n15-min polling"]
        KPIPull["kpi_pipeline\nscheduled pull"]
        Snap["snapshot\ndaily history"]
        Digest["digest\nMon 08:00"]
        RAGAuto["rag_auto\nvariance calc"]
    end

    subgraph DataLayer["Data Layer"]
        PG["Cloud SQL\nPostgres 15\n(operational data)"]
        BQ["BigQuery\npulseboard_analytics\n(time-series · history)"]
        GCS["Cloud Storage\nuploads · templates"]
        Redis["Memorystore\nRedis 7\n(cache · Celery broker)"]
    end

    subgraph Integrations["External Integrations"]
        Jira["Jira Cloud / DC\nREST API v3"]
        EntraGraph["MS Graph API\nuser · group data"]
        PushAPI["Push KPI API\n(client systems)"]
        PullSrc["Pull Sources\nSQL / REST endpoints"]
    end

    subgraph GCP["GCP Services"]
        VertexAI["Vertex AI\nGemini 1.5 Pro\n+ Gemma fallback"]
        AR["Artifact Registry\nDocker images"]
        SM["Secret Manager\ndb-url · tokens"]
        CT["Cloud Tasks\nasync jobs"]
        CB["Cloud Build\nCI/CD pipeline"]
    end

    Users --> Web
    Web --> MSAL
    MSAL --> AppRoles
    MSAL --> API
    Web --> API
    CP --> Agent

    API --> AuthMW
    AuthMW --> Router
    Router --> PG
    Router --> BQ_SVC
    BQ_SVC --> BQ
    Agent --> VertexAI
    Agent --> BQ_SVC
    Agent --> PG

    API --> CT
    CT --> Workers
    Workers --> PG
    Workers --> BQ
    Workers --> Redis
    Workers --> Jira
    Workers --> PullSrc

    PushAPI --> API

    SCIM --> API
    EntraGraph --> API

    API --> SM
    Workers --> SM
    API --> GCS

    CB --> AR
    AR --> API
    AR --> Workers
```

---

## Tech Stack

| Layer | Technology | Notes |
|---|---|---|
| Frontend | Next.js 14 (App Router) | TypeScript, Tailwind CSS, shadcn/ui |
| Backend API | FastAPI (Python 3.12) | Async, Pydantic v2, SQLAlchemy 2 |
| Async Workers | Celery 5 + Redis | 5 task types, Cloud Run autoscale |
| Database | Cloud SQL Postgres 15 | Connection pooling via pgBouncer |
| Analytics store | BigQuery | Time-series KPIs, project history |
| AI / LLM | Vertex AI — Gemini 1.5 Pro | Gemma 2 fallback (see ADR-0001) |
| Auth | Microsoft Entra ID | MSAL, OIDC, SCIM, App Roles |
| Object storage | Cloud Storage | Uploads, CSV templates |
| Cache / broker | Memorystore Redis 7 | Session cache, Celery task queue |
| Secrets | GCP Secret Manager | All credentials, rotated automatically |
| Container registry | Artifact Registry | Regional, vulnerability scanning on |
| CI/CD | Cloud Build | Triggered on main branch push |
| IaC | Terraform 1.8 | Full GCP resource management |
| Deployment | Cloud Run (all services) | Serverless, min 1 instance for API |
| External integration | Jira Cloud / Data Center | OAuth 2.0 + PAT |
| Identity directory | Microsoft Graph API | Group membership, user attributes |

---

## Features Overview

### Portfolio Intelligence
- **Project registry** — centralised record of every AI initiative with owner, BU/Function, AI pattern (Gen AI, Predictive ML, Agentic, CV+NLP, Recommendation), lifecycle stage, and model risk tier
- **RAG status** — Red / Amber / Green automatically calculated from schedule variance, KPI attainment, and model health; manually overridable with justification
- **Lifecycle tracking** — POC → Pilot → Scale → Production → Decommissioned with stage-gate dates and duration metrics

### Adoption Analytics
- **KPI ingestion** — four modes: Push API, Pull API, Pipeline SQL, Manual upload
- **Time-series dashboards** — trend charts, target vs actual, period comparisons
- **Dimension breakdowns** — slice any KPI by BU, user cohort, feature, or custom dimension
- **Anomaly detection** — automatic flagging of drops > 2σ from rolling baseline

### AI Intelligence Layer
- **Natural language queries** — ask "Which projects are Red in Risk this month?" in the command palette
- **Morning briefing** — CAIO-facing daily summary generated by Gemini from overnight data
- **Weekly digest emails** — BU/Function Head tailored summaries every Monday 08:00
- **Model drift alerts** — KPI quality metrics monitored for degradation patterns

### Governance & Reporting
- **Daily history snapshots** — immutable point-in-time records for audit
- **Model Risk tier classification** — Tier 1–4 with approval workflow hooks
- **Export** — CSV/Excel export of any view; PDF of governance reports
- **RBAC** — Admin, Contributor, Viewer roles mapped to Entra security groups

### Integrations
- **Jira** — bi-directional sync; project status, sprint velocity, open issues pulled every 15 min
- **Microsoft Entra ID** — SSO, SCIM auto-provisioning, group-to-BU mapping
- **Push KPI API** — REST endpoint accepting metric payloads from any system
- **Pull KPI API** — PulseBoard polls configured REST/SQL endpoints on a schedule

---

## Quickstart (Local Development)

### Prerequisites

- Docker Desktop 4.x
- Python 3.12 (for running seed script locally without Docker)
- Node.js 20 LTS
- `gcloud` CLI (optional, for GCP integration testing)

### 1. Clone and configure

```bash
git clone https://github.com/your-org/pulseboard.git
cd pulseboard
cp .env.example .env
```

Edit `.env` and fill in at minimum:

```
ENTRA_TENANT_ID=your-tenant-id
ENTRA_CLIENT_ID=your-client-id
ENTRA_CLIENT_SECRET=your-client-secret
```

For local dev without Entra, set `AUTH_BYPASS_LOCAL=true` (creates a mock admin session).

### 2. Start the stack

```bash
docker compose up --build
```

This starts:
| Container | Port | Description |
|---|---|---|
| `pulseboard-db` | 5432 | Postgres 15 |
| `pulseboard-redis` | 6379 | Redis 7 |
| `pulseboard-api` | 8000 | FastAPI backend |
| `pulseboard-web` | 3000 | Next.js frontend |
| `pulseboard-worker` | — | Celery worker |

### 3. Run migrations

```bash
docker compose exec api alembic upgrade head
```

### 4. Seed demo data

```bash
docker compose exec api python scripts/seed.py --demo
```

This creates 1 org, 5 BUs, 8 Group Functions, 25 users, 40 AI projects, and 90 days of synthetic KPI history.

### 5. Open PulseBoard

Navigate to [http://localhost:3000](http://localhost:3000).

With `AUTH_BYPASS_LOCAL=true`, you will be automatically signed in as `demo-caio@pulseboard.local` with Admin role.

### 6. (Optional) Connect to Jira

1. Go to **Settings → Integrations → Jira**
2. Enter your Jira base URL and API token
3. Click **Test Connection**, then **Enable Sync**

First sync runs immediately; subsequent syncs run every 15 minutes.

---

## Repository Structure

```
pulseboard/
├── apps/
│   ├── api/              # FastAPI backend
│   │   ├── alembic/      # Database migrations
│   │   ├── pulseboard/   # Application code
│   │   └── pyproject.toml
│   ├── web/              # Next.js 14 frontend
│   │   ├── app/          # App Router pages
│   │   ├── components/   # React components
│   │   └── lib/          # Utilities, API client
│   └── worker/           # Celery async workers
│       └── tasks/
├── docs/                 # Documentation
│   └── adr/              # Architecture Decision Records
├── infra/
│   ├── terraform/        # GCP IaC
│   └── cloudbuild/       # CI/CD pipeline config
├── packages/
│   └── shared-types/     # JSON Schema shared types
├── scripts/
│   ├── deploy-gcp.sh     # One-shot GCP deployment
│   └── seed.py           # Demo data seeder
├── docker-compose.yml
├── .gitignore
└── README.md
```

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development workflow, branch naming, and PR checklist.

## License

Proprietary — Copyright 2025 PulseBoard. All rights reserved.
