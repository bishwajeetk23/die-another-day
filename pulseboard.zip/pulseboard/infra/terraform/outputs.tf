output "api_url" {
  description = "PulseBoard API Cloud Run URL"
  value       = google_cloud_run_v2_service.api.uri
}

output "web_url" {
  description = "PulseBoard Web Cloud Run URL"
  value       = google_cloud_run_v2_service.web.uri
}

output "db_connection_name" {
  description = "Cloud SQL connection name"
  value       = google_sql_database_instance.pulseboard.connection_name
}

output "db_private_ip" {
  description = "Cloud SQL private IP"
  value       = google_sql_database_instance.pulseboard.private_ip_address
}

output "gcs_bucket" {
  description = "GCS uploads bucket name"
  value       = google_storage_bucket.pulseboard_uploads.name
}

output "redis_host" {
  description = "Redis host"
  value       = google_redis_instance.pulseboard.host
}

output "artifact_registry" {
  description = "Artifact Registry image prefix"
  value       = "${var.region}-docker.pkg.dev/${var.project_id}/pulseboard"
}

output "service_account_email" {
  description = "PulseBoard service account email"
  value       = google_service_account.pulseboard.email
}

output "next_steps" {
  description = "Post-deployment steps"
  value       = <<-EOT
  ╔══════════════════════════════════════════════════════════════════╗
  ║              PulseBoard Deployed Successfully! 🚀                ║
  ╠══════════════════════════════════════════════════════════════════╣
  ║  Web URL:  ${google_cloud_run_v2_service.web.uri}
  ║  API URL:  ${google_cloud_run_v2_service.api.uri}
  ╠══════════════════════════════════════════════════════════════════╣
  ║  Next steps:                                                     ║
  ║  1. Add the Web URL as a redirect URI in your Entra app reg      ║
  ║  2. Open the Web URL and sign in via Entra SSO                   ║
  ║  3. Settings → Identity → Map Entra groups to BUs/Functions      ║
  ║  4. Settings → Integrations → Add Jira Instance                  ║
  ║  5. Onboarding → Define KPI → Push first data point              ║
  ╚══════════════════════════════════════════════════════════════════╝
  EOT
}
