terraform {
  required_version = ">= 1.5"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# ─────────────────────────────────────────────
# Enable Required APIs
# ─────────────────────────────────────────────
locals {
  required_apis = [
    "run.googleapis.com",
    "sqladmin.googleapis.com",
    "bigquery.googleapis.com",
    "secretmanager.googleapis.com",
    "cloudbuild.googleapis.com",
    "artifactregistry.googleapis.com",
    "aiplatform.googleapis.com",
    "cloudtasks.googleapis.com",
    "storage.googleapis.com",
    "compute.googleapis.com",
    "redis.googleapis.com",
    "vpcaccess.googleapis.com",
  ]
}

resource "google_project_service" "apis" {
  for_each           = toset(local.required_apis)
  service            = each.value
  disable_on_destroy = false
}

# ─────────────────────────────────────────────
# Service Account (least privilege)
# ─────────────────────────────────────────────
resource "google_service_account" "pulseboard" {
  account_id   = "pulseboard-sa"
  display_name = "PulseBoard Service Account"
  depends_on   = [google_project_service.apis]
}

resource "google_project_iam_member" "pulseboard_roles" {
  for_each = toset([
    "roles/aiplatform.user",
    "roles/cloudsql.client",
    "roles/bigquery.dataEditor",
    "roles/secretmanager.secretAccessor",
    "roles/cloudtasks.enqueuer",
    "roles/logging.logWriter",
    "roles/monitoring.metricWriter",
    "roles/trace.agent",
  ])
  project = var.project_id
  role    = each.value
  member  = "serviceAccount:${google_service_account.pulseboard.email}"
}

# ─────────────────────────────────────────────
# Artifact Registry
# ─────────────────────────────────────────────
resource "google_artifact_registry_repository" "pulseboard" {
  location      = var.region
  repository_id = "pulseboard"
  description   = "PulseBoard container images"
  format        = "DOCKER"
  depends_on    = [google_project_service.apis]
}

# ─────────────────────────────────────────────
# Cloud SQL (PostgreSQL 15)
# ─────────────────────────────────────────────
resource "random_password" "db_password" {
  length  = 32
  special = true
}

resource "google_sql_database_instance" "pulseboard" {
  name             = "pulseboard-postgres"
  database_version = "POSTGRES_15"
  region           = var.region
  depends_on       = [google_project_service.apis]

  settings {
    tier              = var.db_tier
    availability_type = var.environment == "production" ? "REGIONAL" : "ZONAL"
    disk_autoresize   = true
    disk_size         = 20

    backup_configuration {
      enabled                        = true
      start_time                     = "02:00"
      point_in_time_recovery_enabled = var.environment == "production"
    }

    ip_configuration {
      ipv4_enabled    = false
      private_network = google_compute_network.pulseboard.id
    }

    insights_config {
      query_insights_enabled = true
    }
  }

  deletion_protection = var.environment == "production"
}

resource "google_sql_database" "pulseboard" {
  name     = var.db_name
  instance = google_sql_database_instance.pulseboard.name
}

resource "google_sql_user" "pulseboard" {
  name     = var.db_user
  instance = google_sql_database_instance.pulseboard.name
  password = random_password.db_password.result
}

# ─────────────────────────────────────────────
# VPC Network (for private SQL + Redis)
# ─────────────────────────────────────────────
resource "google_compute_network" "pulseboard" {
  name                    = "pulseboard-vpc"
  auto_create_subnetworks = true
  depends_on              = [google_project_service.apis]
}

resource "google_compute_global_address" "private_ip" {
  name          = "pulseboard-private-ip"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 16
  network       = google_compute_network.pulseboard.id
}

resource "google_service_networking_connection" "private_vpc" {
  network                 = google_compute_network.pulseboard.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.private_ip.name]
}

resource "google_vpc_access_connector" "pulseboard" {
  name          = "pulseboard-connector"
  region        = var.region
  network       = google_compute_network.pulseboard.name
  ip_cidr_range = "10.8.0.0/28"
  depends_on    = [google_project_service.apis]
}

# ─────────────────────────────────────────────
# Memorystore (Redis) for Celery broker + cache
# ─────────────────────────────────────────────
resource "google_redis_instance" "pulseboard" {
  name               = "pulseboard-redis"
  tier               = "BASIC"
  memory_size_gb     = 1
  region             = var.region
  authorized_network = google_compute_network.pulseboard.id
  depends_on         = [google_project_service.apis]
}

# ─────────────────────────────────────────────
# BigQuery
# ─────────────────────────────────────────────
resource "google_bigquery_dataset" "pulseboard_analytics" {
  dataset_id    = "pulseboard_analytics"
  friendly_name = "PulseBoard Analytics"
  description   = "AI adoption KPI time-series and project history snapshots"
  location      = "US"
  depends_on    = [google_project_service.apis]
}

resource "google_bigquery_table" "adoption_kpi_values" {
  dataset_id          = google_bigquery_dataset.pulseboard_analytics.dataset_id
  table_id            = "adoption_kpi_values"
  deletion_protection = false

  time_partitioning {
    type  = "DAY"
    field = "ts"
  }

  schema = jsonencode([
    { name = "id", type = "STRING", mode = "REQUIRED" },
    { name = "kpi_id", type = "STRING", mode = "REQUIRED" },
    { name = "kpi_name", type = "STRING", mode = "NULLABLE" },
    { name = "project_id", type = "STRING", mode = "NULLABLE" },
    { name = "ts", type = "TIMESTAMP", mode = "REQUIRED" },
    { name = "value", type = "FLOAT64", mode = "REQUIRED" },
    { name = "dimensions_json", type = "JSON", mode = "NULLABLE" },
  ])
}

resource "google_bigquery_table" "project_history" {
  dataset_id          = google_bigquery_dataset.pulseboard_analytics.dataset_id
  table_id            = "project_history_snapshots"
  deletion_protection = false

  time_partitioning {
    type  = "DAY"
    field = "snapshot_date"
  }

  schema = jsonencode([
    { name = "id", type = "STRING", mode = "REQUIRED" },
    { name = "project_id", type = "STRING", mode = "REQUIRED" },
    { name = "project_name", type = "STRING", mode = "NULLABLE" },
    { name = "snapshot_date", type = "DATE", mode = "REQUIRED" },
    { name = "lifecycle_stage", type = "STRING", mode = "NULLABLE" },
    { name = "rag", type = "STRING", mode = "NULLABLE" },
    { name = "schedule_variance_days", type = "INT64", mode = "NULLABLE" },
    { name = "budget_variance_pct", type = "FLOAT64", mode = "NULLABLE" },
    { name = "realized_value_amount", type = "FLOAT64", mode = "NULLABLE" },
  ])
}

# ─────────────────────────────────────────────
# Cloud Storage (file uploads)
# ─────────────────────────────────────────────
resource "google_storage_bucket" "pulseboard_uploads" {
  name          = "${var.project_id}-pulseboard-uploads"
  location      = var.region
  force_destroy = false

  uniform_bucket_level_access = true

  lifecycle_rule {
    condition { age = 365 }
    action { type = "Delete" }
  }
}

resource "google_storage_bucket_iam_member" "sa_uploads" {
  bucket = google_storage_bucket.pulseboard_uploads.name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_service_account.pulseboard.email}"
}

# ─────────────────────────────────────────────
# Secret Manager
# ─────────────────────────────────────────────
resource "google_secret_manager_secret" "db_url" {
  secret_id  = "pulseboard-db-url"
  depends_on = [google_project_service.apis]
  replication { auto {} }
}

resource "google_secret_manager_secret_version" "db_url" {
  secret      = google_secret_manager_secret.db_url.id
  secret_data = "postgresql+asyncpg://${var.db_user}:${random_password.db_password.result}@${google_sql_database_instance.pulseboard.private_ip_address}/${var.db_name}"
}

resource "google_secret_manager_secret" "entra_client_secret" {
  secret_id  = "pulseboard-entra-client-secret"
  depends_on = [google_project_service.apis]
  replication { auto {} }
}

resource "google_secret_manager_secret_version" "entra_client_secret" {
  secret      = google_secret_manager_secret.entra_client_secret.id
  secret_data = var.entra_client_secret
}

# ─────────────────────────────────────────────
# Cloud Tasks Queue
# ─────────────────────────────────────────────
resource "google_cloud_tasks_queue" "pulseboard_default" {
  name     = "pulseboard-default"
  location = var.region
  depends_on = [google_project_service.apis]
}

# ─────────────────────────────────────────────
# Cloud Run — API
# ─────────────────────────────────────────────
resource "google_cloud_run_v2_service" "api" {
  name     = "pulseboard-api"
  location = var.region
  depends_on = [google_project_service.apis]

  template {
    service_account = google_service_account.pulseboard.email

    vpc_access {
      connector = google_vpc_access_connector.pulseboard.id
      egress    = "ALL_TRAFFIC"
    }

    containers {
      image = var.api_image != "" ? var.api_image : "${var.region}-docker.pkg.dev/${var.project_id}/pulseboard/api:latest"

      resources {
        limits = { cpu = "2", memory = "1Gi" }
      }

      env {
        name  = "ENVIRONMENT"
        value = var.environment
      }
      env {
        name  = "ENTRA_TENANT_ID"
        value = var.entra_tenant_id
      }
      env {
        name  = "ENTRA_CLIENT_ID"
        value = var.entra_client_id
      }
      env {
        name  = "VERTEX_AI_PROJECT"
        value = var.project_id
      }
      env {
        name  = "VERTEX_AI_LOCATION"
        value = var.vertex_ai_location
      }
      env {
        name  = "GCS_BUCKET"
        value = google_storage_bucket.pulseboard_uploads.name
      }
      env {
        name  = "REDIS_URL"
        value = "redis://${google_redis_instance.pulseboard.host}:${google_redis_instance.pulseboard.port}/0"
      }
      env {
        name = "DATABASE_URL"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.db_url.secret_id
            version = "latest"
          }
        }
      }
      env {
        name = "ENTRA_CLIENT_SECRET"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.entra_client_secret.secret_id
            version = "latest"
          }
        }
      }

      liveness_probe {
        http_get { path = "/health" }
        initial_delay_seconds = 15
        period_seconds        = 30
      }
    }

    scaling {
      min_instance_count = 1
      max_instance_count = 10
    }
  }
}

resource "google_cloud_run_v2_service_iam_member" "api_public" {
  location = google_cloud_run_v2_service.api.location
  name     = google_cloud_run_v2_service.api.name
  role     = "roles/run.invoker"
  member   = "allUsers"
}

# ─────────────────────────────────────────────
# Cloud Run — Web (Next.js)
# ─────────────────────────────────────────────
resource "google_cloud_run_v2_service" "web" {
  name     = "pulseboard-web"
  location = var.region
  depends_on = [google_project_service.apis]

  template {
    service_account = google_service_account.pulseboard.email

    containers {
      image = var.web_image != "" ? var.web_image : "${var.region}-docker.pkg.dev/${var.project_id}/pulseboard/web:latest"

      resources {
        limits = { cpu = "1", memory = "512Mi" }
      }

      env {
        name  = "NEXT_PUBLIC_API_URL"
        value = google_cloud_run_v2_service.api.uri
      }
      env {
        name  = "NEXT_PUBLIC_ENTRA_CLIENT_ID"
        value = var.entra_client_id
      }
      env {
        name  = "NEXT_PUBLIC_ENTRA_TENANT_ID"
        value = var.entra_tenant_id
      }
    }

    scaling {
      min_instance_count = 0
      max_instance_count = 5
    }
  }
}

resource "google_cloud_run_v2_service_iam_member" "web_public" {
  location = google_cloud_run_v2_service.web.location
  name     = google_cloud_run_v2_service.web.name
  role     = "roles/run.invoker"
  member   = "allUsers"
}

# ─────────────────────────────────────────────
# Cloud Run — Worker
# ─────────────────────────────────────────────
resource "google_cloud_run_v2_service" "worker" {
  name     = "pulseboard-worker"
  location = var.region
  depends_on = [google_project_service.apis]

  template {
    service_account = google_service_account.pulseboard.email

    vpc_access {
      connector = google_vpc_access_connector.pulseboard.id
      egress    = "ALL_TRAFFIC"
    }

    containers {
      image = var.worker_image != "" ? var.worker_image : "${var.region}-docker.pkg.dev/${var.project_id}/pulseboard/worker:latest"

      resources {
        limits = { cpu = "2", memory = "1Gi" }
      }

      env {
        name  = "REDIS_URL"
        value = "redis://${google_redis_instance.pulseboard.host}:${google_redis_instance.pulseboard.port}/0"
      }
      env {
        name  = "CELERY_BROKER_URL"
        value = "redis://${google_redis_instance.pulseboard.host}:${google_redis_instance.pulseboard.port}/1"
      }
      env {
        name = "DATABASE_URL"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.db_url.secret_id
            version = "latest"
          }
        }
      }
    }

    scaling {
      min_instance_count = 1
      max_instance_count = 3
    }
  }
}
