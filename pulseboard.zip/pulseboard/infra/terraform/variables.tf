variable "project_id" {
  description = "GCP Project ID"
  type        = string
}

variable "region" {
  description = "GCP region (e.g. asia-south1)"
  type        = string
  default     = "asia-south1"
}

variable "environment" {
  description = "Deployment environment: dev | staging | production"
  type        = string
  default     = "production"
}

variable "entra_tenant_id" {
  description = "Microsoft Entra ID tenant ID"
  type        = string
}

variable "entra_client_id" {
  description = "Microsoft Entra ID client/app ID"
  type        = string
}

variable "entra_client_secret" {
  description = "Microsoft Entra ID client secret (stored in Secret Manager)"
  type        = string
  sensitive   = true
}

variable "db_tier" {
  description = "Cloud SQL instance tier"
  type        = string
  default     = "db-g1-small"
}

variable "db_name" {
  description = "PostgreSQL database name"
  type        = string
  default     = "pulseboard"
}

variable "db_user" {
  description = "PostgreSQL user"
  type        = string
  default     = "pulseboard"
}

variable "api_image" {
  description = "Full Docker image path for the API service"
  type        = string
  default     = ""
}

variable "web_image" {
  description = "Full Docker image path for the web service"
  type        = string
  default     = ""
}

variable "worker_image" {
  description = "Full Docker image path for the worker service"
  type        = string
  default     = ""
}

variable "vertex_ai_location" {
  description = "Vertex AI / Gemini API location"
  type        = string
  default     = "us-central1"
}
