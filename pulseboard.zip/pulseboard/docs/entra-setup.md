# Entra ID Setup Guide for PulseBoard

**Audience:** Enterprise IT / Identity Admin  
**Time to complete:** 30–45 minutes  
**Prerequisite:** Global Administrator or Application Administrator role in Entra ID.

---

## 1. Register the PulseBoard Application

1. Sign in to the [Azure Portal](https://portal.azure.com) as an Application Administrator.
2. Navigate to **Microsoft Entra ID** → **App registrations** → **New registration**.
3. Fill in:
   - **Name:** `PulseBoard`
   - **Supported account types:** *Accounts in this organizational directory only (Single tenant)*
   - **Redirect URI:** Leave blank for now (we'll add it in Step 2)
4. Click **Register**.
5. Note the following values — you'll need them for deployment:
   - **Application (client) ID** → `ENTRA_CLIENT_ID`
   - **Directory (tenant) ID** → `ENTRA_TENANT_ID`

---

## 2. Configure Redirect URIs

1. In the PulseBoard app registration, go to **Authentication** → **Add a platform** → **Web**.
2. Add the following redirect URIs:

   | Environment | URI |
   |---|---|
   | Production | `https://pulseboard-web-<hash>-<region>.a.run.app/auth/callback` |
   | Local development | `http://localhost:3000/auth/callback` |

   > The production URL is printed by `./scripts/deploy-gcp.sh` after deployment.

3. Under **Implicit grant and hybrid flows**, check:
   - ✅ Access tokens
   - ✅ ID tokens
4. Click **Save**.

---

## 3. Define App Roles

PulseBoard uses three Entra App Roles for authorization:

1. In the app registration, go to **App roles** → **Create app role**.
2. Create each role:

   **Role 1 — Admin:**
   - Display name: `PulseBoard Admin`
   - Allowed member types: Users/Groups
   - Value: `PulseBoard.Admin`
   - Description: Full access — configure integrations, manage users, view all BUs/functions

   **Role 2 — Contributor:**
   - Display name: `PulseBoard Contributor`
   - Allowed member types: Users/Groups
   - Value: `PulseBoard.Contributor`
   - Description: Create and edit AI projects and KPIs; limited to own BU/function

   **Role 3 — Viewer:**
   - Display name: `PulseBoard Viewer`
   - Allowed member types: Users/Groups
   - Value: `PulseBoard.Viewer`
   - Description: Read-only access to projects and KPIs in own BU/function

---

## 4. Assign Entra Security Groups to App Roles

1. Go to **Enterprise Applications** → search for `PulseBoard` → click the app.
2. Click **Users and groups** → **Add user/group**.
3. Select a security group and assign it to the appropriate role:

   | Group | App Role |
   |---|---|
   | `sg-ai-team-admins` | PulseBoard Admin |
   | `sg-ai-project-leads` | PulseBoard Contributor |
   | `sg-bu-heads` | PulseBoard Viewer |
   | `sg-all-employees` | PulseBoard Viewer |

4. Repeat for each group. Users in multiple groups get the highest-privilege role.

---

## 5. Configure API Permissions

1. In the app registration, go to **API permissions** → **Add a permission** → **Microsoft Graph**.
2. Under **Delegated permissions**, add:
   - `User.Read` — read the signed-in user's profile
   - `profile` — read basic profile
   - `email` — read email address
   - `openid` — required for OIDC
3. Under **Application permissions** (for the SCIM sync service account), add:
   - `User.Read.All` — enumerate all users
   - `GroupMember.Read.All` — read group memberships
4. Click **Grant admin consent for [your tenant]** — required for application permissions.

---

## 6. Generate Client Secret

1. Go to **Certificates & secrets** → **New client secret**.
2. Set:
   - Description: `PulseBoard Production`
   - Expires: **24 months** (set a calendar reminder to rotate before expiry)
3. Click **Add**. **Copy the secret value immediately** — it's only shown once.
4. Store the secret in **GCP Secret Manager**:
   ```bash
   gcloud secrets create pulseboard-entra-client-secret \
     --data-file=- <<< "your-secret-value"
   ```
   Or use the Terraform variable `entra_client_secret` in your deployment.

---

## 7. (Optional) Enable SCIM Provisioning

SCIM allows Entra to automatically sync users and groups to PulseBoard when they're added or removed in Entra.

1. In **Enterprise Applications → PulseBoard → Provisioning** → **Automatic**.
2. Set **Tenant URL:** `https://api.pulseboard.app/scim/v2`
3. Set **Secret Token:** generate one from PulseBoard → **Settings → Identity → SCIM Token**.
4. Click **Test Connection** → should show ✅.
5. Under **Mappings**, enable **Provision Azure Active Directory Users**.
6. Set **Provisioning Status** to **On**.

> If you skip SCIM, users are auto-provisioned on first login with the `PulseBoard.Viewer` role. Admins can promote them in **Settings → Users**.

---

## 8. Map Entra Security Groups to PulseBoard BUs/Functions

After deployment, a PulseBoard Admin completes this one-time mapping step:

1. Sign in to PulseBoard as an Admin.
2. Go to **Settings → Identity → Entra Group Mappings**.
3. Click **Add Mapping** for each group:

   | Entra Group ID | Maps to | PulseBoard Entity |
   |---|---|---|
   | `sg-hr-team` object ID | Business Unit | HR Function |
   | `sg-wealth-leads` object ID | Business Unit | Wealth BU |
   | `sg-risk-team` object ID | Function | Risk Function |

4. Once mapped, users in `sg-hr-team` will only see HR-sponsored AI projects (unless they're Admins).

> Get Entra group Object IDs from **Entra ID → Groups → [group name] → Overview → Object ID**.

---

## 9. Conditional Access Compatibility Checklist

PulseBoard is designed to work with standard Conditional Access policies:

| Policy | Compatible? | Notes |
|---|---|---|
| Require MFA | ✅ Yes | PulseBoard never stores passwords; MFA is handled by Entra |
| Require compliant device | ✅ Yes | Enforced by Entra before the token is issued |
| Block legacy authentication | ✅ Yes | PulseBoard uses OIDC only, no legacy protocols |
| Sign-in risk policy | ✅ Yes | Token validation happens before PulseBoard code runs |
| Session token lifetime | ✅ Yes | PulseBoard respects token expiry; refresh happens silently via MSAL |
| Require approved client app | ⚠️ Partial | Works for browser access; not applicable to the API service-to-service flow |

**PulseBoard never:**
- Stores user passwords
- Bypasses MFA
- Issues its own tokens separate from Entra

---

## 10. Troubleshooting Common Entra Errors

### AADSTS65001: User or administrator has not consented
**Cause:** The required Microsoft Graph permissions haven't received admin consent.  
**Fix:** In the app registration, go to **API permissions → Grant admin consent for [tenant]**.

### AADSTS50105: The signed-in user is not assigned to a role
**Cause:** The user's Entra account hasn't been assigned to any PulseBoard App Role.  
**Fix:** In **Enterprise Applications → PulseBoard → Users and groups**, add the user or their group.

### AADSTS700016: Application not found in directory
**Cause:** The `ENTRA_CLIENT_ID` environment variable is wrong, or the app was registered in a different tenant.  
**Fix:** Double-check the Client ID matches the app registration. Verify the tenant ID also matches.

### Token validation failing (403 on API calls)
**Cause:** Usually a mismatch between the Entra tenant ID in the app config and the JWKS issuer.  
**Fix:** Check `ENTRA_TENANT_ID` matches the tenant where the app is registered. Check `ENTRA_AUDIENCE` matches the Client ID or Application ID URI.

### Users not appearing after Entra group assignment
**Cause:** If using SCIM, the sync cycle runs every 40 minutes.  
**Fix:** In **Provisioning → Provision on demand**, enter the user's UPN and click Provision. Or have the user sign in to PulseBoard to trigger auto-provisioning.

### AADSTS9002327: Tokens issued for the 'Single-Page Application' client-type
**Cause:** The app is registered as SPA but PulseBoard's API needs a confidential client.  
**Fix:** In Authentication, ensure the Web platform (not SPA) has the redirect URIs. The SPA platform should only be used if you're using the implicit flow.
