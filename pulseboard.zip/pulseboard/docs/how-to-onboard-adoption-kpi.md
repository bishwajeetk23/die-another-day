# How to Onboard Adoption KPIs into PulseBoard

**Audience:** AI Product Owners and Analytics Leads  
**Time to complete:** 15–30 minutes per KPI  
**Prerequisite:** Your project is at the Pilot or Production stage in PulseBoard.

---

## 1. What Makes a Good Adoption KPI for an AI Product?

Unlike traditional software metrics, AI products require KPIs that capture both **usage** and **quality** — because an AI that's heavily used but gives bad answers is worse than no AI at all.

A good AI adoption KPI is:
- **Measurable** — you can compute it from logs, events, or user feedback
- **Actionable** — a change in the metric drives a specific decision
- **Attributable** — you can tie it to the AI system, not other changes
- **Time-series ready** — you can track it daily or weekly over months

### KPI Categories and Examples

| Category | What it measures | Example KPIs |
|---|---|---|
| **Usage** | How many people are using the AI, how often | DAU, WAU, Invocations/day, Sessions |
| **Quality** | How good the AI's outputs are | CSAT (1–5), Thumbs-up rate, Escalation-to-human rate, Accuracy on golden set |
| **Funnel** | Conversion through adoption stages | Eligible → Activated → Recurring → Power User rates |
| **Value Realization** | Business impact actually delivered | Hours saved/week, Deflection rate, $ saved vs baseline |
| **Health** | System reliability and cost | Error rate, P95 latency, Cost per 1K calls |
| **Trust & Safety** | Harmful outputs and policy compliance | Flagged response rate, Policy override rate |

> **Rule of thumb:** Define at least one KPI from Usage (to track adoption) and one from Quality (to detect drift). If you promised a business case, add a Value Realization KPI.

---

## 2. Choose Your Ingestion Mode

| Mode | Best for | Setup complexity |
|---|---|---|
| **A — Push API** | Your system can call a webhook | Easiest — copy a URL and token |
| **B — Pull API** | You have an existing API PulseBoard can poll | Medium — provide endpoint + auth |
| **C — SQL Pipeline** | Your metric is already in BigQuery / Snowflake | Medium — write a SQL query |
| **D — Manual Upload** | One-time or infrequent data | No setup — paste CSV |

**Decision matrix:**

```
Does your system produce events in real time?
  YES → Can you modify it to POST to a webhook? → YES → Mode A (Push API)
                                                  NO  → Mode B (Pull API)
  NO  → Is the data already in a data warehouse? → YES → Mode C (Pipeline)
                                                   NO  → Mode D (Manual)
```

---

## 3. Mode A — Push API

PulseBoard generates a unique HTTPS endpoint and bearer token for each KPI. Your system POSTs data to it.

### Setup Steps

1. Go to **Onboarding → Define KPI** (or open the KPI wizard from any project's Adoption tab).
2. Choose or define your KPI (e.g., "Weekly Active Users").
3. Select **Push API** as the ingestion mode.
4. Set the target value and direction (Higher is better / Lower is better).
5. Click **Generate Token** — you'll receive:
   - An endpoint: `POST https://api.pulseboard.app/adoption/kpis/{kpi-id}/ingest`
   - A bearer token (shown once — save it in your Secret Manager)

### Send Data

**curl:**
```bash
curl -X POST "https://api.pulseboard.app/adoption/kpis/abc-123/ingest" \
  -H "Authorization: Bearer pb_kpi_xxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "ts": "2024-01-15T10:00:00Z",
    "value": 4287,
    "dimensions": {
      "region": "APAC",
      "employee_grade": "M3",
      "department": "HR"
    }
  }'
```

**Python:**
```python
import httpx
import datetime

ENDPOINT = "https://api.pulseboard.app/adoption/kpis/abc-123/ingest"
TOKEN = "pb_kpi_xxxxxxxxxxxx"

def push_kpi(value: float, dimensions: dict = {}) -> None:
    response = httpx.post(
        ENDPOINT,
        headers={"Authorization": f"Bearer {TOKEN}"},
        json={
            "ts": datetime.datetime.utcnow().isoformat() + "Z",
            "value": value,
            "dimensions": dimensions,
        },
        timeout=10,
    )
    response.raise_for_status()

# Example: send daily active users
push_kpi(4287, {"region": "APAC"})
```

**Node.js:**
```javascript
const axios = require('axios');

const endpoint = 'https://api.pulseboard.app/adoption/kpis/abc-123/ingest';
const token = 'pb_kpi_xxxxxxxxxxxx';

async function pushKPI(value, dimensions = {}) {
  await axios.post(endpoint, {
    ts: new Date().toISOString(),
    value,
    dimensions,
  }, {
    headers: { Authorization: `Bearer ${token}` },
  });
}

pushKPI(4287, { region: 'APAC' });
```

### Payload Schema
```json
{
  "ts": "ISO 8601 timestamp (required)",
  "value": "number (required)",
  "dimensions": {
    "any_key": "any string value (optional)"
  }
}
```

---

## 4. Mode B — Pull API

PulseBoard polls your API on a schedule (minimum: every 30 minutes).

### Setup Steps

1. In the KPI wizard, select **Pull API**.
2. Provide:
   - **Endpoint URL:** the full URL PulseBoard will GET
   - **Auth Type:** None / Bearer Token / Basic Auth / API Key header
   - **Auth credentials** (stored encrypted in Secret Manager)
   - **JMESPath expression** to extract the value from the response

### JMESPath Cheatsheet

| Your API response | JMESPath expression |
|---|---|
| `{"value": 4287}` | `value` |
| `{"metrics": {"wau": 4287}}` | `metrics.wau` |
| `{"data": [{"count": 4287}]}` | `data[0].count` |
| `{"results": [{"metric": "wau", "val": 4287}]}` | `results[?metric=='wau'].val | [0]` |
| `{"stats": {"daily": {"active_users": 4287}}}` | `stats.daily.active_users` |

3. Click **Test** — PulseBoard will make a live request and show you the extracted value.
4. Set the cron schedule (e.g., `0 9 * * *` for 9am UTC daily).

---

## 5. Mode C — SQL Pipeline (BigQuery / Snowflake)

Use this when your metric already lives in a data warehouse.

### Setup Steps

1. Select **SQL Pipeline**.
2. Choose your warehouse: **BigQuery** or **Snowflake**.
3. Provide credentials (stored in GCP Secret Manager):
   - **BigQuery:** Service account JSON key or Workload Identity
   - **Snowflake:** Account, username, password/private key, warehouse, database

4. Write your SQL query. The query **must return two columns:**
   - `value` — the numeric metric value
   - `ts` — the timestamp (TIMESTAMP type)

**Example BigQuery query:**
```sql
SELECT
  COUNT(DISTINCT user_id) AS value,
  TIMESTAMP_TRUNC(CURRENT_TIMESTAMP(), DAY) AS ts
FROM `my-project.analytics.hr_policy_bot_sessions`
WHERE DATE(session_ts) = CURRENT_DATE()
  AND session_type = 'ai_interaction'
```

**Example with dimensions:**
```sql
SELECT
  COUNT(DISTINCT user_id) AS value,
  CURRENT_TIMESTAMP() AS ts,
  region AS dimension_region,
  employee_grade AS dimension_employee_grade
FROM `my-project.analytics.bot_sessions`
WHERE DATE(session_ts) = DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY)
GROUP BY region, employee_grade
```

> Columns prefixed with `dimension_` are automatically parsed as dimensions.

5. Click **Validate Query** — PulseBoard runs the query and shows the result.
6. Set the execution schedule.

---

## 6. Mode D — Manual Upload

For low-frequency or one-off metrics.

1. Select **Manual Upload**.
2. Prepare a CSV with these columns:
   ```
   ts,value,dimension_region,dimension_grade
   2024-01-15T10:00:00Z,4287,APAC,M3
   2024-01-14T10:00:00Z,4100,APAC,M3
   ```
3. Drag-and-drop the CSV into the upload zone.
4. Review the preview and confirm.

You can re-upload at any time — duplicate timestamps will be overwritten.

---

## 7. Defining Target, Direction, and Dimensions

### Target Value
Set a target that represents success. This powers the progress bar on the KPI card.
- For WAU: what weekly active user count means "the product is adopted"?
- For CSAT: what score means users trust the AI's outputs?
- For error rate: what's the maximum acceptable error rate?

### Direction
- **Higher is better:** Usage metrics, CSAT, deflection rate, hours saved
- **Lower is better:** Error rate, latency, escalation rate, cost per call

### Dimensions
Dimensions let you slice the metric by attributes like region, department, or user grade. Define your dimension schema upfront — PulseBoard will use these for cohort analysis and filtering.

Common dimensions:
- `region` (APAC, EMEA, AMER)
- `employee_grade` (IC3, IC4, M1, M2, M3…)
- `department` (HR, Finance, Legal…)
- `channel` (web, mobile, API, Teams bot)

---

## 8. Validating Data Lands Correctly

After sending/configuring data:
1. Go to **Adoption → [Your KPI]**.
2. The time-series chart should show your data points.
3. Check the "Last updated" timestamp on the KPI card — it should match your most recent data point.
4. In the KPI detail page, click **Dimensions** to verify dimension slicing works.

For Push API: send a test POST and wait 60 seconds, then refresh.  
For Pull API: click **"Run Now"** in the pipeline status panel.  
For SQL: click **"Execute Now"** in the pipeline status panel.

---

## 9. Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| 401 Unauthorized on Push API | Token expired or wrong | Regenerate token in KPI settings |
| Pull API returns 200 but no data in PulseBoard | JMESPath expression wrong | Use the JMESPath tester in KPI settings |
| SQL pipeline shows "Query error" | BigQuery permissions or SQL syntax | Check service account has BigQuery Data Viewer on the dataset; validate SQL in BigQuery console first |
| KPI card shows "Stale" | Pipeline hasn't run recently | Check pipeline status panel for last error |
| Values look wrong (e.g. 1000x too high) | Unit mismatch | Check your query returns users, not raw events; check you're not double-counting |
| Dimensions not appearing | Column prefix missing | Add `dimension_` prefix to dimension columns in SQL/CSV |
