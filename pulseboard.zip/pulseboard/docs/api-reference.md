# PulseBoard — REST API Reference

**Base URL:** `https://api.pulseboard.app` (or your Cloud Run API URL)  
**Auth:** All endpoints require `Authorization: Bearer <entra_jwt>` except `/health`.  
**Content-Type:** `application/json` unless noted.  
**Pagination:** List endpoints use `?skip=0&limit=50` cursor pagination.

---

## Authentication

PulseBoard uses Microsoft Entra ID JWTs for all API authentication. The API validates the token against Entra's JWKS endpoint on every request.

```http
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGci...
```

Roles extracted from the JWT `roles` claim:
- `PulseBoard.Admin` — full access
- `PulseBoard.Contributor` — create/edit within own BU/Function
- `PulseBoard.Viewer` — read-only within own BU/Function

---

## Health

### `GET /health`

Returns service health. No auth required.

**Response 200:**
```json
{
  "status": "ok",
  "version": "1.0.0"
}
```

---

## Projects

### `GET /projects`

List AI projects visible to the current user (RBAC-filtered).

**Query Parameters:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `skip` | integer | 0 | Pagination offset |
| `limit` | integer | 50 | Max results (max 200) |
| `stage` | string | — | Filter by lifecycle stage |
| `rag` | string | — | Filter by RAG status: `green`, `amber`, `red` |
| `bu_id` | UUID | — | Filter by Business Unit |
| `function_id` | UUID | — | Filter by Function |
| `search` | string | — | Full-text search on name and description |
| `ai_pattern` | string | — | Filter by AI pattern |

**Response 200:**
```json
{
  "items": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "HR Policy Bot",
      "slug": "hr-policy-bot",
      "ai_pattern": "generative_ai",
      "lifecycle_stage": "production",
      "model_risk_tier": 2,
      "rag_status": "green",
      "rag_reason": null,
      "product_owner": {
        "id": "...",
        "display_name": "Priya Sharma",
        "email": "priya.sharma@company.com"
      },
      "bu": { "id": "...", "name": "Human Resources" },
      "function": null,
      "baseline_end_date": "2024-03-01",
      "forecast_end_date": "2024-03-01",
      "actual_end_date": "2024-03-05",
      "schedule_variance_days": 4,
      "expected_value_amount": "120000.00",
      "expected_value_unit": "hours_saved",
      "created_at": "2024-01-15T10:00:00Z",
      "updated_at": "2024-04-20T14:30:00Z"
    }
  ],
  "total": 40,
  "skip": 0,
  "limit": 50
}
```

---

### `POST /projects`

Create a new AI project. Requires `Contributor` or `Admin` role.

**Request Body:**
```json
{
  "name": "Fraud Detection v2",
  "description": "Real-time transaction fraud scoring using ML",
  "ai_pattern": "predictive_ml",
  "lifecycle_stage": "qualification",
  "model_risk_tier": 1,
  "bu_id": "550e8400-e29b-41d4-a716-446655440001",
  "function_id": null,
  "product_owner_id": "550e8400-e29b-41d4-a716-446655440002",
  "tech_lead_id": "550e8400-e29b-41d4-a716-446655440003",
  "business_sponsor_id": null,
  "baseline_end_date": "2024-12-01",
  "forecast_end_date": "2024-12-01",
  "expected_value_amount": 500000,
  "expected_value_unit": "cost_reduction",
  "tags": ["fraud", "ml", "real-time"]
}
```

**Response 201:** Full project object (same schema as GET item).

**Errors:**
- `400` — Validation error (missing required fields, invalid enum)
- `403` — Contributor trying to create project outside their BU/Function

---

### `GET /projects/{id}`

Get a single project by ID or slug.

**Response 200:** Full project object with nested milestones, risks, and issues arrays.

```json
{
  "id": "...",
  "name": "HR Policy Bot",
  "milestones": [
    {
      "id": "...",
      "title": "Data pipeline live",
      "due_date": "2024-02-01",
      "completed_at": "2024-01-28T09:00:00Z",
      "owner": { "id": "...", "display_name": "Priya Sharma" }
    }
  ],
  "risks": [ ... ],
  "issues": [ ... ]
}
```

---

### `PATCH /projects/{id}`

Partial update. Requires `Contributor` (own BU/Function) or `Admin`.

**Request Body:** Any subset of project fields. Omitted fields are unchanged.

**Response 200:** Updated project object.

---

### `POST /projects/{id}/advance-stage`

Advance the project to the next lifecycle stage. Validates stage gate checklist before advancing.

**Request Body:**
```json
{
  "notes": "All pilot sign-off criteria met. Stakeholder approval received."
}
```

**Response 200:**
```json
{
  "id": "...",
  "previous_stage": "pilot",
  "new_stage": "production",
  "advanced_at": "2024-04-15T11:00:00Z"
}
```

**Errors:**
- `400` — Stage gate checklist items not complete
- `400` — Already at `sunset` (terminal stage)

---

### `POST /projects/{id}/rag-override`

Manually set RAG status with a reason.

**Request Body:**
```json
{
  "rag_status": "amber",
  "reason": "Key engineer on leave for 3 weeks — manageable but worth flagging."
}
```

**Response 200:** Updated project object.

---

### `GET /projects/{id}/history`

Get historical RAG and stage snapshots.

**Query Parameters:** `?days=90` (default 90)

**Response 200:**
```json
{
  "snapshots": [
    {
      "snapshot_date": "2024-04-14",
      "lifecycle_stage": "pilot",
      "rag_status": "amber",
      "schedule_variance_days": 12,
      "open_risks": 2,
      "open_issues": 1
    }
  ]
}
```

---

### Milestones

#### `POST /projects/{id}/milestones`

```json
{
  "title": "Model training complete",
  "due_date": "2024-05-01",
  "owner_id": "..."
}
```

#### `PATCH /projects/{project_id}/milestones/{milestone_id}`

Mark complete: `{ "completed_at": "2024-04-20T09:00:00Z" }`

#### `DELETE /projects/{project_id}/milestones/{milestone_id}`

Soft delete. Returns `204 No Content`.

---

### Risks

#### `POST /projects/{id}/risks`

```json
{
  "title": "Data quality issues in source system",
  "description": "HR HRIS has inconsistent employee grade data...",
  "likelihood": "high",
  "impact": "medium",
  "mitigation": "Agreed data cleansing sprint with HR IT team",
  "owner_id": "..."
}
```

#### `PATCH /projects/{project_id}/risks/{risk_id}`

Update any risk field including `status` (`open` → `mitigated` → `escalated` → `closed`).

---

## Adoption (KPIs)

### `GET /adoption/kpis`

List KPI definitions visible to the current user.

**Query Parameters:** `?project_id=UUID`, `?category=usage`

**Response 200:**
```json
{
  "items": [
    {
      "id": "...",
      "project_id": "...",
      "name": "Weekly Active Users",
      "category": "usage",
      "unit": "users",
      "target_value": 5000,
      "direction": "higher_is_better",
      "ingestion_mode": "push",
      "last_ingested_at": "2024-04-20T09:00:00Z",
      "is_stale": false
    }
  ]
}
```

---

### `POST /adoption/kpis`

Define a new KPI. Requires `Contributor` or `Admin`.

```json
{
  "project_id": "...",
  "name": "CSAT Score",
  "category": "quality",
  "unit": "score (1-5)",
  "target_value": 4.2,
  "direction": "higher_is_better",
  "ingestion_mode": "push",
  "dimension_schema": ["region", "department"]
}
```

**Response 201:** KPI object with `ingest_endpoint` and `ingest_token` (shown once).

```json
{
  "id": "abc-123",
  "ingest_endpoint": "https://api.pulseboard.app/adoption/kpis/abc-123/ingest",
  "ingest_token": "pb_kpi_xxxxxxxxxxxxxxxxxxxx"
}
```

> **Warning:** `ingest_token` is shown exactly once. Store it in your Secret Manager immediately.

---

### `POST /adoption/kpis/{id}/ingest`

Ingest a KPI data point. Auth: Bearer `pb_kpi_*` token (not an Entra JWT).

**Request Body:**
```json
{
  "ts": "2024-04-20T09:00:00Z",
  "value": 4287,
  "dimensions": {
    "region": "APAC",
    "department": "HR"
  }
}
```

**Response 200:**
```json
{
  "status": "ok",
  "id": "...",
  "kpi_id": "abc-123",
  "ts": "2024-04-20T09:00:00Z",
  "value": 4287
}
```

**Errors:**
- `401` — Invalid or expired token
- `422` — Missing `ts` or `value`

---

### `GET /adoption/kpis/{id}/values`

Retrieve time-series data for a KPI.

**Query Parameters:**

| Parameter | Default | Description |
|---|---|---|
| `start` | 90 days ago | ISO 8601 datetime |
| `end` | now | ISO 8601 datetime |
| `granularity` | `day` | `hour`, `day`, `week` |
| `dimension` | — | Pivot by dimension key |

**Response 200:**
```json
{
  "kpi_id": "abc-123",
  "name": "Weekly Active Users",
  "granularity": "day",
  "series": [
    { "ts": "2024-01-15", "value": 4100 },
    { "ts": "2024-01-16", "value": 4287 }
  ],
  "target_value": 5000,
  "current_value": 4287,
  "trend_pct": 4.6
}
```

---

### `GET /adoption/kpis/starter-library`

Returns 15 pre-defined KPI templates grouped by category.

**Response 200:**
```json
{
  "templates": [
    {
      "id": "dau",
      "name": "Daily Active Users",
      "category": "usage",
      "unit": "users",
      "direction": "higher_is_better",
      "description": "Unique users who interacted with the AI on a given day"
    }
  ]
}
```

---

## AI Agent

### `POST /agent/conversations`

Create a new conversation thread.

**Request Body:** `{}` (empty — title is set from first message)

**Response 201:**
```json
{
  "id": "conv-uuid",
  "title": null,
  "created_at": "2024-04-20T10:00:00Z"
}
```

---

### `GET /agent/conversations`

List conversations for the current user.

**Response 200:**
```json
{
  "items": [
    {
      "id": "conv-uuid",
      "title": "Which projects are at risk?",
      "created_at": "2024-04-20T10:00:00Z",
      "message_count": 6
    }
  ]
}
```

---

### `POST /agent/chat`

Send a message and receive a streaming SSE response. Rate limited: **10 requests per minute per user**.

**Request Body:**
```json
{
  "conversation_id": "conv-uuid",
  "message": "Which AI projects are at risk of missing their go-live date this quarter?"
}
```

**Response:** `text/event-stream` (SSE)

Each event is a JSON object:

```
data: {"type": "text_delta", "delta": "Based on"}
data: {"type": "text_delta", "delta": " the current portfolio"}
data: {"type": "tool_call", "name": "query_projects", "args": {"rag_status": "red"}, "call_id": "tc_1"}
data: {"type": "tool_result", "call_id": "tc_1", "result": [...], "duration_ms": 42}
data: {"type": "text_delta", "delta": " [1]"}
data: {"type": "citation", "ref": 1, "text": "Loan Risk Scorer", "source": "projects"}
data: {"type": "done", "conversation_id": "conv-uuid", "message_id": "msg-uuid"}
```

**Event Types:**

| Type | Description |
|---|---|
| `text_delta` | Partial text chunk to append to the response |
| `tool_call` | Agent is calling a tool — show in reasoning panel |
| `tool_result` | Tool returned — show in reasoning panel with duration |
| `citation` | Inline citation reference |
| `chart` | Inline chart data: `{"chart_type": "line", "data": [...], "x_key": "date", "y_key": "value"}` |
| `error` | Error occurred: `{"message": "..."}` |
| `done` | Stream complete |

**Errors:**
- `429` — Rate limit exceeded (10 RPM)
- `403` — No conversation access

---

## Onboarding

### `GET /onboarding/jira/instances`

List connected Jira instances.

### `POST /onboarding/jira/instances`

Connect a new Jira instance.

```json
{
  "name": "Acme Jira",
  "base_url": "https://acme.atlassian.net",
  "auth_email": "admin@acme.com",
  "auth_token": "ATATT3x..."
}
```

**Response 201:** Instance object with `id` and `sync_status: "never"`.

### `POST /onboarding/jira/instances/{id}/test`

Test the connection. Returns `200 {"ok": true, "connected_as": "Admin User"}` or `400 {"ok": false, "error": "401 Unauthorized"}`.

### `GET /onboarding/jira/instances/{id}/projects`

List Jira projects accessible via this instance. Used to populate the project selector in the onboarding wizard.

### `POST /onboarding/upload`

Upload a tracker CSV or XLSX. `Content-Type: multipart/form-data`.

**Form Fields:**
- `file` — the CSV or XLSX file
- `preview_only` — `true` to return parse preview without importing

**Response 200:**
```json
{
  "preview": [
    {
      "name": "HR Policy Bot",
      "ai_pattern": "generative_ai",
      "lifecycle_stage": "production",
      "parse_status": "ok"
    }
  ],
  "total_rows": 12,
  "error_rows": 0
}
```

---

## Governance

### `GET /governance/summary`

Returns portfolio-level governance summary for the Admin/CAIO view.

**Response 200:**
```json
{
  "by_risk_tier": {
    "1": { "total": 5, "red": 1, "amber": 2, "green": 2 },
    "2": { "total": 18, "red": 3, "amber": 6, "green": 9 },
    "3": { "total": 17, "red": 0, "amber": 4, "green": 13 }
  },
  "sunset_candidates": [
    {
      "id": "...",
      "name": "Document OCR Pilot",
      "lifecycle_stage": "pilot",
      "days_in_stage": 187,
      "rag_status": "red"
    }
  ],
  "stale_kpis": 4,
  "total_projects": 40,
  "escalated_risks": 3
}
```

---

## Users & Settings (Admin only)

### `GET /users`

List all users in the organisation. Admin only.

### `GET /users/me`

Returns current user profile.

**Response 200:**
```json
{
  "id": "...",
  "email": "aria.chen@company.com",
  "display_name": "Aria Chen",
  "role": "PulseBoard.Admin",
  "job_title": "Chief AI Officer",
  "last_login_at": "2024-04-20T08:30:00Z"
}
```

### `PATCH /users/{id}/role`

Update a user's role. Admin only.

```json
{ "role": "PulseBoard.Contributor" }
```

### `GET /settings/entra-mappings`

List Entra group → BU/Function mappings.

### `POST /settings/entra-mappings`

Create a new mapping.

```json
{
  "entra_group_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "entra_group_name": "sg-wealth-team",
  "bu_id": "...",
  "function_id": null
}
```

### `DELETE /settings/entra-mappings/{id}`

Remove a mapping. Admin only.

---

## Error Response Schema

All errors follow this schema:

```json
{
  "detail": "Human-readable error message",
  "code": "MACHINE_READABLE_CODE",
  "field": "field_name_if_validation_error"
}
```

**Common HTTP Status Codes:**

| Code | Meaning |
|---|---|
| `400` | Bad request — validation error or business rule violation |
| `401` | Missing or invalid Authorization header |
| `403` | Authenticated but insufficient permissions |
| `404` | Resource not found (or not visible due to RBAC) |
| `409` | Conflict — duplicate slug, etc. |
| `422` | Unprocessable entity — Pydantic validation failure |
| `429` | Rate limit exceeded |
| `500` | Internal server error — check API logs |
