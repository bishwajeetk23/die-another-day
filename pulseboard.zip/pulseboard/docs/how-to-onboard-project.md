# How to Onboard an AI Project into PulseBoard

**Audience:** BU/Function-side AI Project Leads with no engineering background  
**Time to complete:** 10–20 minutes  
**Prerequisite:** Your Entra ID account has been assigned the `PulseBoard.Contributor` role by your IT admin.

---

## 1. Sign In

PulseBoard uses your company's existing Microsoft Entra ID (formerly Azure AD) identity. There is no separate username or password.

1. Open your browser and navigate to the PulseBoard URL (provided by your IT team).
2. Click **"Sign in with Microsoft"**.
3. You'll be redirected to your organisation's standard Microsoft sign-in page. Complete MFA as usual.
4. You'll land on the PulseBoard AI Assistant home page.

> **Troubleshooting:** If you see "AADSTS50105: The signed-in user is not assigned to a role for the application", contact your IT admin — your Entra account needs to be added to the PulseBoard application. See [Entra Setup Guide](./entra-setup.md).

---

## 2. Choose Your Source

Before you start, decide how your project data lives:

| Situation | Recommended Source |
|---|---|
| Your AI project is tracked in a Jira project | **Jira** |
| You have a spreadsheet/CSV tracker | **Manual Upload** |
| Both Jira AND a manual tracker | **Hybrid** (start with Jira, supplement with manual) |
| No tracker at all yet | **Manual** — use the PulseBoard template |

---

## 3. Prerequisites

### For Jira Onboarding
- You need access to the Jira project (or the Jira admin can give you a read-only API token).
- Know your Jira base URL (e.g., `https://mycompany.atlassian.net`).
- Generate an Atlassian API token: go to [https://id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens) → **Create API token** → copy it.

### For Manual Upload
- Download the PulseBoard AI Project Template: **Settings → Templates → Download AI Project Template (.xlsx)**
- Fill in the template (see Section 6 for field guidance).

---

## 4. Step-by-Step: Jira Onboarding

### Step 1 — Connect Your Jira Instance

1. In the left sidebar, click **Onboarding** → **Jira**.
2. Click **"Add Jira Instance"**.
3. Enter:
   - **Base URL:** `https://yourcompany.atlassian.net`
   - **Email:** your Atlassian account email
   - **API Token:** the token you generated in Prerequisites
4. Click **"Test Connection"** — you should see ✅ *"Connected as [your name]"*.
5. Click **Save**.

> If the connection test fails, double-check that your API token hasn't expired and that your Atlassian account has access to the project.

### Step 2 — Select Jira Projects

1. After saving, PulseBoard fetches all Jira projects your account can see.
2. Find your AI project in the list. Use the search box if there are many.
3. Check the box next to your project.
4. Choose: **"Link to existing PulseBoard project"** or **"Create new PulseBoard project"**.
5. Click **Next**.

### Step 3 — Map Fields

PulseBoard will suggest automatic mappings based on common Jira field names. Review them:

| PulseBoard Field | Default Jira Mapping |
|---|---|
| Project Name | Jira Project Name |
| Product Owner | Project Lead |
| Baseline End Date | Fix Version → Due Date |
| Lifecycle Stage | Labels containing "stage:" prefix |
| AI Pattern | Custom field "AI Pattern" (if exists) |

- Adjust any mappings that don't look right.
- Click **"Save & Sync Now"**.
- PulseBoard will pull all issues from the last 90 days and set up a recurring 15-minute sync.

---

## 5. Step-by-Step: Manual Upload

1. In the left sidebar, click **Onboarding** → **Upload Tracker**.
2. If you haven't downloaded the template, click **"Download Template (.xlsx)"**.
3. Fill in your template (see Section 6).
4. Back in PulseBoard, click **"Choose File"** or drag-and-drop your CSV/XLSX.
5. PulseBoard will show a **preview** of the parsed data — review it for errors.
6. Map any columns that weren't auto-detected.
7. Click **"Import"**.
8. Your project(s) will appear in the Portfolio view within seconds.

> You can re-upload at any time. The latest upload wins; previous versions are retained for audit.

---

## 6. Filling Out AI-Specific Fields

These fields are unique to PulseBoard and important for the AI portfolio intelligence to work correctly.

### AI Pattern
Choose the type of AI your project uses:

| Pattern | When to use |
|---|---|
| **Predictive ML** | Model that predicts an outcome (churn, fraud, credit risk, demand) |
| **Generative AI** | LLM-based content generation, summarization, Q&A, code generation |
| **Agentic** | AI that autonomously takes multi-step actions (booking, filing, researching) |
| **Computer Vision** | Image/video analysis, OCR, document extraction |
| **NLP** | Text classification, sentiment analysis, entity extraction (non-LLM) |
| **Recommendation** | Personalised suggestions (products, content, HR matches) |
| **Optimization** | Finds the best solution given constraints (scheduling, routing, pricing) |
| **RPA + AI** | Robotic process automation augmented with AI decision-making |

### Model Risk Tier
Set by your AI Governance team. If unsure, default to Tier 3 and the governance team will review.

| Tier | Meaning |
|---|---|
| **Tier 1** | High-impact model affecting financial decisions, credit, or regulatory compliance |
| **Tier 2** | Medium-impact — affects customer experience or operational efficiency at scale |
| **Tier 3** | Low-risk — internal tools, analytics, non-consequential decisions |

### Lifecycle Stage
Where is your project RIGHT NOW?

| Stage | Meaning |
|---|---|
| **Ideation** | Use-case idea captured; no work started |
| **Qualification** | Assessing feasibility, value, data availability; GO/NO-GO pending |
| **PoC** | Building a small-scale prototype to test the core hypothesis |
| **Pilot** | Running with a limited real user group in production conditions |
| **Production** | Live for the full intended audience |
| **Scale** | Expanding to additional regions, BUs, or use-cases |
| **Sunset** | Actively being decommissioned |

### Baseline Dates & RAG
- **Baseline End Date:** The originally agreed go-live date. **Do not change this after the project starts** — it's your measurement anchor.
- **Forecast End Date:** Your current best estimate of go-live. Update this weekly.
- **RAG Status:** Set Green/Amber/Red based on your judgment. PulseBoard will also auto-calculate RAG from schedule variance, but you can override it with a reason.

### Expected Value
Quantify the business case. Use the unit that's most relevant:
- **Hours Saved / Year** for productivity tools
- **Revenue Uplift ($)** for customer-facing tools
- **Cost Reduction ($)** for operational tools
- **NPS Lift (points)** for experience tools

This is used to compute realized ROI once the project is live.

---

## 7. Setting Owner, Sponsor, and Value Expectation

On the project detail page, fill in:
- **Product Owner** — the central AI team member responsible for delivery
- **Tech Lead** — the AI engineer leading the build
- **Business Sponsor** — the Function Head or BU Head funding/sponsoring the initiative

These people will receive weekly digests and RAG-flip alerts.

---

## 8. Verifying Your First Sync / Import

After onboarding:
1. Navigate to **AI Projects** in the left sidebar.
2. Find your project in the list — it should show with the correct lifecycle stage, RAG status, and AI-stage pipeline.
3. Click into the project and verify the **Overview** tab shows correct dates and owner information.
4. For Jira-linked projects, click the **Jira** tab — you should see live tickets with their current statuses.

---

## 9. Common Errors and Fixes

| Error | Likely Cause | Fix |
|---|---|---|
| "Connection failed: 401 Unauthorized" | API token expired or wrong email | Regenerate the Atlassian API token |
| "No projects found" | Your Atlassian account doesn't have project access | Ask the Jira admin to grant you Viewer access |
| "Column mapping failed: lifecycle_stage not found" | Template column header renamed | Use the exact header names from the downloaded template |
| "Slug already exists" | A project with that name was already onboarded | Rename the project slightly or link to the existing one |
| "Parse status: failed" | File format issue | Ensure the file is .csv or .xlsx; check for merged cells in XLSX |

---

## 10. Frequently Asked Questions

**Q: Can I connect multiple Jira instances?**  
Yes — repeat the Jira onboarding flow for each instance. Each instance can link to multiple PulseBoard projects.

**Q: What if my project spans multiple Jira projects?**  
Link each Jira project separately to the same PulseBoard AI project. PulseBoard will aggregate all tickets.

**Q: Can I change the baseline end date later?**  
You can, but this changes your historical variance calculations. It's strongly recommended to freeze the baseline date at project kick-off and only update the forecast date.

**Q: How often does Jira sync happen?**  
Every 15 minutes automatically. You can trigger an immediate sync from the Jira integration settings.

**Q: Who can see my project?**  
By default, projects are visible to Admins and users mapped to the same Business Unit or Function via Entra group mappings. The Chief AI Officer can see everything.
