# PulseBoard — 2-Minute Demo Script

**Audience:** Chief AI Officer and AI Steering Committee  
**Duration:** 2 minutes (tight — rehearse to pace)  
**Setup:** Open PulseBoard in Chrome, full-screen, seeded demo data loaded (`./scripts/deploy-gcp.sh --demo`). Sign in as `aria.chen@company.com` (Chief AI Officer — sees everything).

---

## Pre-Demo Checklist

- [ ] Demo data seeded (40 projects, 90 days of KPIs)
- [ ] Browser tab open at `<WEB_URL>` — AI Assistant page loaded
- [ ] ⌘K command palette working
- [ ] Second monitor off (present from laptop, clean background)
- [ ] Slack/notifications silenced

---

## Script

### 0:00 — Opening (10 seconds)

> "You have 40 AI initiatives in flight across 8 business units. Today, nobody has a single view of all of them — I'm going to show you one."

*[The AI Assistant home page is visible — dark background, the prompt blinking.]*

---

### 0:10 — AI Assistant: Portfolio Question (30 seconds)

Type in the chat input:

> **"Which AI projects are at risk of missing their go-live date this quarter, and what's causing the delays?"**

*[Hit Enter. Watch the agent stream its response.]*

Wait for the response. While it streams, narrate:

> "PulseBoard's AI assistant is calling our live data right now — it's not searching the internet, it's querying the actual project register."

*[Response appears with citations like [1] Loan Risk Scorer, [2] HR Policy Bot — point to them.]*

> "Every number is cited. If it can't find data, it says so. No hallucinations."

---

### 0:40 — AI Assistant: Adoption Question (20 seconds)

Type:

> **"Show me the weekly active user trend for the HR Policy Bot over the last 60 days."**

*[Agent renders an inline chart directly in the chat — line chart, dark theme, Geist Mono axes.]*

> "The agent doesn't just return a number — it renders a chart inline. This is live adoption data pushed by the HR team's system."

---

### 1:00 — Portfolio View (20 seconds)

Click **AI Projects** in the left sidebar.

> "Here's the full portfolio."

Point to the AI-stage pipeline column:

> "Each dot is a lifecycle stage — Ideation through to Scale. The glowing dot is where the project is today."

Click **RAG** filter → select **Red**.

> "Two projects are red. Let me click into one."

Click **Loan Risk Scorer**.

---

### 1:20 — Project Deep-Dive (20 seconds)

*[Project detail page opens — Overview tab.]*

> "Baseline go-live was March 15th. Current forecast is April 28th — 44 days late. The system calculated this automatically from the Jira sync."

Click **Risks & Issues** tab.

> "Three open risks, one escalated to the steering committee. The project lead added this — it's in the system, not in someone's email."

---

### 1:40 — Governance & Command Palette (15 seconds)

Press **⌘K**.

*[Command palette opens — Raycast-style.]*

Type: `gov`

Click **Governance Overview**.

> "Model Risk Tier 1 projects — the ones that touch financial decisions — are all visible here. Compliance status at a glance."

---

### 1:55 — Close (5 seconds)

> "One platform. Natural language. Live data. That's PulseBoard."

*[Return to AI Assistant page — the chat history still visible.]*

---

## Anticipated Questions & Answers

**"Where does the data come from?"**  
> "Jira syncs every 15 minutes automatically. KPI data is pushed by each product team's system — we give them a single API endpoint and a token. Manual upload also works for teams without automation."

**"Who can see what?"**  
> "Access is controlled by your existing Entra security groups. A Wealth analyst only sees Wealth projects. The Chief AI Officer — and only the Chief AI Officer — sees everything. No extra logins."

**"Can it hallucinate?"**  
> "It can't — it's instructed to only make claims it can cite from the data. If a KPI hasn't been pushed in 30 days, the agent flags it as stale rather than guessing."

**"What's the fallback if Gemini is down?"**  
> "We run Gemma 3 self-hosted on GCP as an automatic fallback. The agent keeps working — responses may be slightly less detailed, and users see a banner."

**"How long to deploy?"**  
> "One command, 15–20 minutes on a fresh GCP project. Your IT team connects Entra, maps your security groups to business units, and it's live."

**"What's the cost?"**  
> "For your scale — roughly 500 projects and 200 users — estimated $700/month on GCP. That includes all compute, storage, and Gemini API calls."

---

## Demo Recovery Moves

| Problem | Recovery |
|---|---|
| AI response is slow | "This is a complex query — it's calling four data sources in parallel. Worth the wait." |
| Chart doesn't render | Reload the page; charts are cached — use the portfolio view as the visual instead |
| No red projects showing | Filter for Amber instead; pivot to "let me show you schedule variance" |
| Command palette doesn't open | Navigate manually to Governance page; skip the ⌘K demo |
| Blank portfolio | Data not seeded — pivot to a live project edit to show the form and fields |
