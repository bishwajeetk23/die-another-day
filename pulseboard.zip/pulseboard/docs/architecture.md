# PulseBoard — System Architecture

## Overview

PulseBoard is a GCP-native, three-tier web application. All services run on Cloud Run and communicate over a private VPC. Authentication is exclusively through Microsoft Entra ID OIDC — no passwords are stored. The AI assistant layer uses Google Vertex AI (Gemini 2.5 Pro) via the Vertex AI SDK, with Gemma 3 as a self-hosted fallback.

---

## High-Level Architecture

```mermaid
graph TB
    subgraph Internet
        Browser["Browser / Client"]
        EntraID["Microsoft Entra ID\n(Identity Provider)"]
        JiraCloud["Jira Cloud\n(Integration)"]
    end

    subgraph GCP["GCP Project (VPC)"]
        subgraph CloudRun["Cloud Run Services"]
            Web["pulseboard-web\nNext.js 14\n(1 vCPU / 512MB)"]
            API["pulseboard-api\nFastAPI + Uvicorn\n(2 vCPU / 1GB)"]
            Worker["pulseboard-worker\nCelery\n(2 vCPU / 1GB)"]
        end

        subgraph Data["Data Stores (Private IP)"]
            CloudSQL["Cloud SQL\nPostgreSQL 15\n(Operational DB)"]
            Redis["Memorystore\nRedis 1GB\n(Celery Broker)"]
            BigQuery["BigQuery\n(KPI Time-Series\nAnalytics)"]
            GCS["Cloud Storage\n(File Uploads)"]
        end

        subgraph AI["AI / ML"]
            VertexAI["Vertex AI\nGemini 2.5 Pro\nGemini 2.0 Flash"]
            GemmaFallback["Cloud Run\nGemma 3\n(GPU, optional)"]
        end

        subgraph Ops["Operations"]
            SecretMgr["Secret Manager\n(Credentials Vault)"]
            CloudTasks["Cloud Tasks\n(Async Jobs)"]
            ArtifactReg["Artifact Registry\n(Docker Images)"]
            CloudBuild["Cloud Build\n(CI/CD)"]
        end
    end

    Browser -->|HTTPS| Web
    Browser -->|OIDC Auth Code + PKCE| EntraID
    EntraID -->|JWT| Browser
    Web -->|REST + JWT| API
    API -->|JWKS validation| EntraID
    API -->|Private IP| CloudSQL
    API -->|Private IP| Redis
    API -->|gRPC / SDK| VertexAI
    API -->|HTTP fallback| GemmaFallback
    API -->|Write KPI data| BigQuery
    API -->|File upload| GCS
    API -->|Read secrets| SecretMgr
    Worker -->|Private IP| CloudSQL
    Worker -->|Private IP| Redis
    Worker -->|Jira REST API| JiraCloud
    Worker -->|Write analytics| BigQuery
    Worker -->|Pull KPI data| BigQuery
    CloudBuild -->|Push images| ArtifactReg
    ArtifactReg -->|Pull images| CloudRun
```

---

## Request Flow: AI Assistant Chat

```mermaid
sequenceDiagram
    participant User as Browser
    participant Web as Next.js Web
    participant API as FastAPI API
    participant Entra as Entra ID
    participant Gemini as Vertex AI (Gemini)
    participant DB as Cloud SQL

    User->>Web: Type message + Submit
    Web->>API: POST /agent/chat (SSE) + Bearer JWT
    API->>Entra: GET JWKS (cached 1hr)
    Entra-->>API: Public keys
    API->>API: Validate JWT, extract roles + groups
    API->>DB: Load conversation history
    API->>Gemini: generate_content_async(stream=True)\nwith tool definitions
    Gemini-->>API: function_call: query_projects(...)
    API->>DB: Execute SQL (RBAC-filtered)
    DB-->>API: Project rows
    API->>Gemini: tool_result: [{...}]
    Gemini-->>API: function_call: query_adoption_metric(...)
    API->>DB: Execute adoption query
    DB-->>API: KPI rows
    API->>Gemini: tool_result: [{...}]
    Gemini-->>API: text_delta: "Here are the..." (streaming)
    API-->>Web: SSE: {"type":"text_delta","delta":"Here"}
    API-->>Web: SSE: {"type":"text_delta","delta":" are"}
    API-->>Web: SSE: {"type":"done"}
    Web-->>User: Rendered response with citations + charts
    API->>DB: Persist AIMessage
```

---

## Request Flow: KPI Data Ingestion (Push API)

```mermaid
sequenceDiagram
    participant Src as Source System\n(e.g. HR Policy Bot)
    participant API as FastAPI API
    participant DB as Cloud SQL
    participant BQ as BigQuery

    Src->>API: POST /adoption/kpis/{id}/ingest\nBearer pb_kpi_xxx
    API->>API: SHA-256 hash token\nLookup AdoptionKPI by hash
    API->>DB: INSERT adoption_kpi_values
    API->>BQ: INSERT adoption_kpi_values\n(streaming insert)
    API-->>Src: 200 OK {"status":"ok","id":"..."}
```

---

## Authentication & Authorisation Flow

```mermaid
flowchart TD
    A[User visits PulseBoard] --> B{Has valid Entra session?}
    B -->|No| C[Redirect to Entra OIDC\nAuthorization Code + PKCE]
    C --> D[User authenticates\nMFA enforced by Entra CA policy]
    D --> E[Entra issues JWT\ncontaining roles claim]
    E --> F[Frontend stores token\nin MSAL cache]
    B -->|Yes| F
    F --> G[API request with\nAuthorization: Bearer JWT]
    G --> H[Backend validates JWT\nagainst JWKS]
    H --> I{roles claim}
    I -->|PulseBoard.Admin| J[Full access\nall BUs / Functions]
    I -->|PulseBoard.Contributor| K[Resolve EntraGroupMapping\nfrom entra_group_ids]
    I -->|PulseBoard.Viewer| K
    K --> L[Build RBACContext\naccessible_bu_ids\naccessible_function_ids]
    L --> M[Filter SQL queries\nWHERE bu_id IN accessible_bu_ids]
```

---

## Data Architecture

### Operational Store — Cloud SQL (PostgreSQL 15)

Stores all transactional data: users, organisations, AI projects, milestones, risks, conversations, KPI definitions.

Key design decisions:
- **UUID primary keys** everywhere — safe for multi-region replication
- **Soft-delete pattern** for projects (`deleted_at` nullable timestamp)
- **Audit events table** — append-only log of all mutations with actor, timestamp, before/after JSON
- **JSONB columns** for flexible metadata (tool_calls_json, citations_json, source_config_json)
- **Alembic async migrations** — version-controlled schema with zero-downtime patterns

### Analytics Store — BigQuery

Stores time-series KPI data separately from operational data:

- `adoption_kpi_values` — partitioned by `ts` (DAY), clustered by `kpi_id`. Receives both real-time Push API inserts and Worker-pulled data.
- `project_history_snapshots` — partitioned by `snapshot_date`. Daily snapshots for trend analysis and the AI agent's "show me historical RAG status" queries.

Design rationale: KPI data can reach millions of rows for large enterprises. BigQuery's columnar storage and partition pruning handle this at a fraction of the cost of PostgreSQL.

### Cache — Memorystore (Redis)

- Celery broker and result backend
- JWKS public key cache (1-hour TTL, application-level)
- Rate-limit sliding window for `/agent/chat` (10 RPM per user, in-memory per instance — acceptable because Cloud Run min=1 for API)

---

## Worker Architecture

```mermaid
flowchart LR
    subgraph Beat["Celery Beat (Scheduler)"]
        S1["Jira Sync\nevery 15 min"]
        S2["Daily Snapshot\nmidnight UTC"]
        S3["RAG Recalculation\nevery hour"]
        S4["Weekly Digest\nMonday 8am"]
        S5["KPI Pull Pipeline\nevery 30 min"]
    end

    subgraph Workers["Celery Workers"]
        W1["sync_jira_all"]
        W2["snapshot_all_projects"]
        W3["recalculate_rag_all"]
        W4["send_weekly_digest"]
        W5["run_kpi_pull_pipelines"]
    end

    subgraph External["External"]
        Jira["Jira Cloud"]
        BQ["BigQuery"]
        Email["Email Provider\n(stub)"]
        SourceAPI["Source APIs\n(Pull mode)"]
    end

    S1 --> W1 --> Jira
    S2 --> W2 --> BQ
    S3 --> W3
    S4 --> W4 --> Email
    S5 --> W5 --> SourceAPI
    S5 --> W5 --> BQ
```

---

## Security Architecture

### Network Security
- Cloud SQL and Redis are **private IP only** — not reachable from the internet
- Cloud Run services connect to private resources via **VPC Access Connector**
- Cloud Armor (WAF + DDoS) can be added in front of Cloud Run for production hardening

### Credential Management
- All secrets (DB connection string, Entra client secret) stored in **GCP Secret Manager**
- Cloud Run services receive secrets as environment variables at deploy time — never baked into images
- Entra client secret rotation documented with 24-month calendar reminder

### Application Security
- **JWT validation** on every API request — stateless, scales to many instances
- **RBAC filtering** at the SQL query level — not just UI gating
- **Rate limiting** on `/agent/chat`: 10 requests per minute per user (sliding window)
- **Input validation** via Pydantic v2 — all request bodies validated before processing
- **Audit log** — all project mutations recorded in `audit_events` with actor and diff

---

## Scalability

| Dimension | Current Config | Scale Path |
|---|---|---|
| API throughput | 1 min instance, scales to 10 | Increase max_instance_count; add Cloud Armor |
| Database | db-g1-small (dev) | Upgrade to db-n1-standard-4; add read replica |
| Redis | 1GB BASIC | Upgrade to STANDARD_HA for HA |
| Gemini | 360 RPM default | Request quota increase via Cloud Console |
| KPI data volume | BigQuery pay-per-query | Reservations for predictable cost at scale |
| Jira sync | 15-min interval | Parallelise per-instance in Worker; add Cloud Tasks |

---

## Directory Structure

```
pulseboard/
├── apps/
│   ├── api/                    # FastAPI backend
│   │   ├── pulseboard/
│   │   │   ├── main.py         # App entrypoint, middleware, routers
│   │   │   ├── config.py       # Pydantic Settings (env vars)
│   │   │   ├── dependencies.py # Auth dependencies (CurrentUser, RBACCtx)
│   │   │   ├── models/         # SQLAlchemy models
│   │   │   ├── routers/        # FastAPI route handlers
│   │   │   ├── services/       # Business logic
│   │   │   ├── auth/           # JWKS validation, RBAC context
│   │   │   ├── agent/          # Orchestrator, tools, prompts
│   │   │   └── integrations/   # Jira client
│   │   ├── alembic/            # Database migrations
│   │   └── Dockerfile
│   ├── web/                    # Next.js 14 frontend
│   │   ├── app/                # App Router pages
│   │   ├── components/         # Shared UI components
│   │   └── Dockerfile
│   └── worker/                 # Celery worker
│       ├── celery_app.py       # Beat schedule + app config
│       ├── tasks/              # Task modules
│       └── Dockerfile
├── infra/
│   └── terraform/              # GCP infrastructure as code
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
├── packages/
│   └── shared-types/           # Shared JSON Schema
├── scripts/
│   ├── deploy-gcp.sh           # One-command deployment
│   └── seed.py                 # Demo data seeder
└── docs/
    ├── architecture.md         # This file
    ├── data-model.md           # ERD and table descriptions
    ├── api-reference.md        # REST API reference
    ├── deploy-gcp.md           # Deployment guide
    ├── entra-setup.md          # Entra ID configuration
    ├── how-to-onboard-project.md
    ├── how-to-onboard-adoption-kpi.md
    ├── demo-script.md          # 2-minute CAIO demo
    └── adr/
        ├── 0001-llm-provider.md
        └── 0002-entra-auth.md
```
