# PulseBoard — Data Model Reference

## Overview

PulseBoard uses two data stores:

1. **Cloud SQL (PostgreSQL 15)** — Operational data: users, projects, KPI definitions, conversations
2. **BigQuery** — Analytical data: KPI time-series values and project history snapshots

All primary keys are UUID v4. Timestamps are stored in UTC.

---

## Entity Relationship Diagram

```mermaid
erDiagram
    organizations ||--o{ users : "has many"
    organizations ||--o{ business_units : "has many"
    organizations ||--o{ functions : "has many"
    organizations ||--o{ entra_group_mappings : "has many"
    organizations ||--o{ adoption_kpis : "has many (via projects)"

    business_units ||--o{ ai_projects : "sponsors"
    functions ||--o{ ai_projects : "sponsors"

    users ||--o{ ai_projects : "owns (product_owner)"
    users ||--o{ ai_projects : "leads (tech_lead)"
    users ||--o{ ai_conversations : "has many"
    users ||--o{ audit_events : "actor"

    ai_projects ||--o{ project_milestones : "has many"
    ai_projects ||--o{ project_risks : "has many"
    ai_projects ||--o{ project_issues : "has many"
    ai_projects ||--o{ project_history_snapshots : "has many"
    ai_projects ||--o{ jira_ticket_cache : "has many"
    ai_projects ||--o{ adoption_kpis : "has many"

    adoption_kpis ||--o{ adoption_kpi_values : "has many (BigQuery)"

    ai_conversations ||--o{ ai_messages : "has many"

    entra_group_mappings }o--o| business_units : "maps to"
    entra_group_mappings }o--o| functions : "maps to"
```

---

## Tables — Cloud SQL

### `organizations`

Root tenant table. One row per enterprise deployment.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `name` | VARCHAR(255) | Display name |
| `entra_tenant_id` | VARCHAR(255) | Unique — drives auto-provisioning |
| `slug` | VARCHAR(100) | URL-safe identifier |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

---

### `users`

Provisioned on first Entra login. Role is extracted from the `roles` JWT claim.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `entra_oid` | VARCHAR(255) | Entra Object ID — immutable, unique |
| `email` | VARCHAR(255) | From `preferred_username` claim |
| `display_name` | VARCHAR(255) | From `name` claim |
| `role` | VARCHAR(50) | `PulseBoard.Admin` / `PulseBoard.Contributor` / `PulseBoard.Viewer` |
| `entra_group_ids` | JSONB | Array of Entra group Object IDs |
| `job_title` | VARCHAR(255) | Optional |
| `department` | VARCHAR(255) | Optional |
| `is_active` | BOOLEAN | Set false on SCIM deprovision |
| `last_login_at` | TIMESTAMPTZ | |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

---

### `business_units`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `name` | VARCHAR(255) | e.g. "Retail Banking", "Wealth" |
| `slug` | VARCHAR(100) | URL-safe |
| `head_user_id` | UUID FK → users | BU head — nullable |
| `created_at` | TIMESTAMPTZ | |

---

### `functions`

Group Functions (HR, Finance, Risk, etc.) — distinct from BUs.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `name` | VARCHAR(255) | e.g. "Human Resources", "Risk" |
| `slug` | VARCHAR(100) | |
| `head_user_id` | UUID FK → users | Nullable |
| `created_at` | TIMESTAMPTZ | |

---

### `entra_group_mappings`

Maps Entra security group Object IDs to PulseBoard BUs or Functions. Drives the RBAC data-scoping layer.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `entra_group_id` | VARCHAR(255) | Entra group Object ID |
| `entra_group_name` | VARCHAR(255) | Display only |
| `bu_id` | UUID FK → business_units | Nullable — either bu_id or function_id set |
| `function_id` | UUID FK → functions | Nullable |
| `created_at` | TIMESTAMPTZ | |
| `created_by` | UUID FK → users | |

---

### `ai_projects`

Core entity. One row per AI initiative tracked in PulseBoard.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `bu_id` | UUID FK → business_units | Nullable — project belongs to a BU or Function |
| `function_id` | UUID FK → functions | Nullable |
| `name` | VARCHAR(255) | Display name |
| `slug` | VARCHAR(100) | URL-safe, unique per org |
| `description` | TEXT | |
| `ai_pattern` | VARCHAR(50) | `predictive_ml`, `generative_ai`, `agentic`, `computer_vision`, `nlp`, `recommendation`, `optimization`, `rpa_ai` |
| `lifecycle_stage` | VARCHAR(50) | `ideation`, `qualification`, `poc`, `pilot`, `production`, `scale`, `sunset` |
| `model_risk_tier` | INTEGER | 1 / 2 / 3 |
| `rag_status` | VARCHAR(10) | `green`, `amber`, `red` |
| `rag_reason` | TEXT | Manual override reason |
| `rag_is_manual` | BOOLEAN | If true, auto-recalc is skipped |
| `product_owner_id` | UUID FK → users | Nullable |
| `tech_lead_id` | UUID FK → users | Nullable |
| `business_sponsor_id` | UUID FK → users | Nullable |
| `baseline_end_date` | DATE | Frozen at kick-off |
| `forecast_end_date` | DATE | Updated weekly |
| `actual_end_date` | DATE | Set when project reaches Production |
| `expected_value_amount` | NUMERIC(14,2) | |
| `expected_value_unit` | VARCHAR(50) | `hours_saved`, `revenue_uplift`, `cost_reduction`, `nps_lift` |
| `jira_instance_id` | UUID FK → jira_instances | Nullable |
| `jira_project_key` | VARCHAR(50) | Nullable |
| `stage_checklist` | JSONB | Per-stage gate items `{stage: {item: bool}}` |
| `tags` | JSONB | Array of strings |
| `deleted_at` | TIMESTAMPTZ | Soft delete |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |
| `created_by` | UUID FK → users | |

**Indexes:** `(org_id, slug)` unique, `(org_id, lifecycle_stage)`, `(org_id, rag_status)`, `(bu_id)`, `(function_id)`

---

### `project_milestones`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `project_id` | UUID FK → ai_projects | |
| `title` | VARCHAR(255) | |
| `due_date` | DATE | |
| `completed_at` | TIMESTAMPTZ | Nullable |
| `owner_id` | UUID FK → users | Nullable |
| `created_at` | TIMESTAMPTZ | |

---

### `project_risks`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `project_id` | UUID FK → ai_projects | |
| `title` | VARCHAR(255) | |
| `description` | TEXT | |
| `likelihood` | VARCHAR(10) | `low`, `medium`, `high` |
| `impact` | VARCHAR(10) | `low`, `medium`, `high` |
| `status` | VARCHAR(20) | `open`, `mitigated`, `escalated`, `closed` |
| `mitigation` | TEXT | |
| `owner_id` | UUID FK → users | Nullable |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

---

### `project_issues`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `project_id` | UUID FK → ai_projects | |
| `title` | VARCHAR(255) | |
| `description` | TEXT | |
| `severity` | VARCHAR(10) | `low`, `medium`, `high`, `critical` |
| `status` | VARCHAR(20) | `open`, `in_progress`, `resolved` |
| `raised_by_id` | UUID FK → users | |
| `assigned_to_id` | UUID FK → users | Nullable |
| `resolved_at` | TIMESTAMPTZ | Nullable |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

---

### `project_history_snapshots`

Point-in-time snapshot of project state. Created daily by the Worker. Also written to BigQuery for long-term analytical queries.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `project_id` | UUID FK → ai_projects | |
| `snapshot_date` | DATE | |
| `lifecycle_stage` | VARCHAR(50) | |
| `rag_status` | VARCHAR(10) | |
| `forecast_end_date` | DATE | |
| `schedule_variance_days` | INTEGER | Positive = late |
| `open_risks` | INTEGER | Count at snapshot time |
| `open_issues` | INTEGER | Count at snapshot time |
| `created_at` | TIMESTAMPTZ | |

---

### `jira_instances`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `name` | VARCHAR(255) | User-supplied label |
| `base_url` | VARCHAR(500) | e.g. `https://acme.atlassian.net` |
| `auth_email` | VARCHAR(255) | |
| `auth_token_encrypted` | TEXT | Encrypted at application layer |
| `last_sync_at` | TIMESTAMPTZ | |
| `sync_status` | VARCHAR(20) | `ok`, `error`, `never` |
| `created_at` | TIMESTAMPTZ | |

---

### `jira_ticket_cache`

Denormalised cache of Jira issues linked to a PulseBoard project.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `project_id` | UUID FK → ai_projects | |
| `jira_instance_id` | UUID FK → jira_instances | |
| `jira_key` | VARCHAR(50) | e.g. `AIPF-123` |
| `summary` | TEXT | |
| `status` | VARCHAR(100) | |
| `issue_type` | VARCHAR(100) | |
| `assignee_name` | VARCHAR(255) | |
| `priority` | VARCHAR(50) | |
| `story_points` | NUMERIC(5,1) | Nullable |
| `due_date` | DATE | Nullable |
| `labels` | JSONB | Array |
| `synced_at` | TIMESTAMPTZ | |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

**Index:** `(project_id, jira_key)` unique

---

### `adoption_kpis`

KPI definition. The actual time-series values live in BigQuery.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `project_id` | UUID FK → ai_projects | |
| `org_id` | UUID FK → organizations | |
| `name` | VARCHAR(255) | e.g. "Weekly Active Users" |
| `category` | VARCHAR(50) | `usage`, `quality`, `funnel`, `value_realization`, `health`, `trust_safety` |
| `unit` | VARCHAR(100) | e.g. "users", "%", "hours" |
| `target_value` | NUMERIC(14,4) | |
| `direction` | VARCHAR(10) | `higher_is_better`, `lower_is_better` |
| `ingestion_mode` | VARCHAR(10) | `push`, `pull`, `sql`, `manual` |
| `source_config_json` | JSONB | Mode-specific config (endpoint, schedule, SQL, token hash) |
| `dimension_schema` | JSONB | Array of dimension key names |
| `last_ingested_at` | TIMESTAMPTZ | |
| `is_stale` | BOOLEAN | Set by Worker if no data in 48h |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

---

### `ai_conversations`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `user_id` | UUID FK → users | |
| `org_id` | UUID FK → organizations | |
| `title` | VARCHAR(500) | First user message (truncated) |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

---

### `ai_messages`

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `conversation_id` | UUID FK → ai_conversations | |
| `role` | VARCHAR(20) | `user`, `assistant`, `tool` |
| `content` | TEXT | Message text |
| `tool_calls_json` | JSONB | Array of `{name, args, result, duration_ms}` |
| `citations_json` | JSONB | Array of `{ref, text, source}` |
| `model_used` | VARCHAR(100) | e.g. `gemini-2.5-pro-002` |
| `tokens_input` | INTEGER | |
| `tokens_output` | INTEGER | |
| `created_at` | TIMESTAMPTZ | |

---

### `audit_events`

Append-only event log. Never updated or deleted.

| Column | Type | Notes |
|---|---|---|
| `id` | UUID PK | |
| `org_id` | UUID FK → organizations | |
| `actor_id` | UUID FK → users | Nullable (system events) |
| `entity_type` | VARCHAR(50) | e.g. `ai_project`, `adoption_kpi` |
| `entity_id` | UUID | |
| `action` | VARCHAR(50) | `create`, `update`, `delete`, `stage_advance`, `rag_override` |
| `before_json` | JSONB | State before change |
| `after_json` | JSONB | State after change |
| `ip_address` | VARCHAR(45) | From request |
| `created_at` | TIMESTAMPTZ | |

**Index:** `(org_id, entity_type, entity_id)`, `(org_id, actor_id)`, `(created_at DESC)`

---

## Tables — BigQuery

### `adoption_kpi_values`

Partitioned by `ts` (DAY), clustered by `kpi_id`.

| Column | Type | Notes |
|---|---|---|
| `id` | STRING | UUID |
| `kpi_id` | STRING | UUID FK (logical) |
| `project_id` | STRING | UUID FK (logical) |
| `org_id` | STRING | UUID FK (logical) |
| `ts` | TIMESTAMP | Partition key |
| `value` | FLOAT64 | |
| `dimensions` | JSON | `{"region": "APAC", ...}` |
| `ingested_at` | TIMESTAMP | When PulseBoard received the data |
| `source` | STRING | `push`, `pull`, `sql`, `manual` |

**Typical queries:**
```sql
-- 90-day trend
SELECT DATE(ts) as date, AVG(value) as avg_value
FROM `{project}.pulseboard.adoption_kpi_values`
WHERE kpi_id = @kpi_id
  AND ts >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 90 DAY)
GROUP BY DATE(ts)
ORDER BY date

-- Dimension pivot
SELECT JSON_VALUE(dimensions, '$.region') as region, AVG(value) as avg_value
FROM `{project}.pulseboard.adoption_kpi_values`
WHERE kpi_id = @kpi_id
GROUP BY region
```

---

### `project_history_snapshots` (BigQuery)

Partitioned by `snapshot_date`. Mirror of the Cloud SQL table for long-term analytical queries.

| Column | Type | Notes |
|---|---|---|
| `project_id` | STRING | |
| `org_id` | STRING | |
| `snapshot_date` | DATE | Partition key |
| `lifecycle_stage` | STRING | |
| `rag_status` | STRING | |
| `schedule_variance_days` | INT64 | |
| `open_risks` | INT64 | |
| `open_issues` | INT64 | |

---

## Key Design Decisions

### UUID Primary Keys
All PKs are UUID v4 (`gen_random_uuid()` in PostgreSQL). This enables safe multi-region replication, external ID exposure without enumeration risk, and consistent ID generation across services.

### JSONB for Flexible Metadata
`source_config_json`, `tool_calls_json`, `citations_json`, `stage_checklist`, `tags` use JSONB. These fields have variable schemas that would require excessive normalization or frequent schema changes as a relational structure.

### Soft Deletes
`ai_projects` uses `deleted_at` rather than hard delete. Deleted projects remain in audit trails and analytics. The application layer filters `WHERE deleted_at IS NULL` on all standard queries.

### Dual-Write KPI Values
KPI values are written to both PostgreSQL (for transactional integrity and the API's metadata reads) and BigQuery (for time-series analytics). The PostgreSQL `adoption_kpis` table stores only metadata (name, target, last_ingested_at). All historical values live in BigQuery.

### Append-Only Audit Log
`audit_events` has no `UPDATE` or `DELETE` paths in the application. It is the source of truth for "who changed what and when." Row-level security prevents even admins from modifying it via the application.
