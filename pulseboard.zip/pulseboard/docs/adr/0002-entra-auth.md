# ADR 0002 — Authentication & Authorisation: Microsoft Entra ID (OIDC + App Roles)

**Status:** Accepted  
**Date:** 2024-01-01  
**Deciders:** AI Platform Team, Enterprise IT Security

---

## Context

PulseBoard is deployed inside an enterprise that already uses Microsoft Entra ID (formerly Azure Active Directory) as its identity provider for all internal applications. The platform must:

- **Authenticate** employees without introducing a separate credential store
- **Authorise** access at three privilege levels: Admin, Contributor, Viewer
- **Scope data** by Business Unit and Function — a Wealth BU analyst should only see Wealth AI projects
- **Support Conditional Access** policies already applied by the enterprise (MFA, compliant device, sign-in risk)
- **Enable SCIM provisioning** so users are automatically deprovisioned when they leave the company
- **Not store passwords** — any credential store is a security liability and a GDPR/regulatory burden

---

## Decision

**Use Microsoft Entra ID as the sole identity provider via OpenID Connect (OIDC).**

- The frontend authenticates users via the MSAL.js library (Authorization Code + PKCE flow)
- The backend validates Entra-issued JWTs on every request using the tenant's published JWKS endpoint
- Three Entra App Roles (`PulseBoard.Admin`, `PulseBoard.Contributor`, `PulseBoard.Viewer`) are assigned to Entra security groups
- Entra security group Object IDs are mapped to PulseBoard BUs and Functions in a `entra_group_mappings` table, enabling row-level data scoping
- No username/password login; no OAuth2 password grant; no API keys for human users

---

## Rationale

### Why Entra ID (not Okta, Auth0, or custom JWT)?

| Factor | Entra ID | Third-party IdP (Okta/Auth0) | Custom JWT |
|---|---|---|---|
| Existing enterprise adoption | ✅ Already deployed org-wide | ❌ Requires new SaaS contract | N/A |
| MFA enforcement | ✅ Existing Conditional Access policies apply automatically | ✅ But requires replicating CA rules | ❌ Must build separately |
| SCIM provisioning | ✅ Native | ✅ But requires configuration | ❌ Must build separately |
| Password storage risk | ✅ Zero — Entra owns credentials | ✅ Zero — IdP owns credentials | ❌ Must hash and store |
| Compliance (SOC2, ISO27001) | ✅ Enterprise already attested | ❌ Adds new vendor to scope | ❌ Adds audit burden |
| GCP integration | ✅ Works via JWKS validation | ✅ Same approach | N/A |
| Developer effort | ✅ Low — MSAL + JWKS only | Medium — IdP SDK + config | High |

### Why App Roles (not custom permission tables)?

Entra App Roles allow the enterprise IT team to manage role assignment in the same tool they already use for all other applications — no PulseBoard-specific admin UI required for basic role management. The three roles map directly to PulseBoard's access model:

- **Admin** — sees everything, configures integrations, manages mappings
- **Contributor** — creates/edits projects in their BU/Function
- **Viewer** — read-only access scoped to their BU/Function

Roles are embedded in the Entra-issued JWT as the `roles` claim — no database lookup required at auth time.

### Why OIDC Authorization Code + PKCE (not Implicit Flow)?

The Implicit Flow was deprecated in OAuth 2.1 because access tokens in the URL fragment are visible in browser history and server logs. PKCE (Proof Key for Code Exchange) provides the same SPA-friendly flow without the security risk. MSAL.js 3.x uses PKCE by default.

### Why BU/Function scoping via database mappings (not Entra claims)?

Option A: Store BU/Function membership in Entra group claims  
Option B: Map Entra group Object IDs to PulseBoard BUs/Functions in a database table

We chose Option B because:
1. Entra group claims have a 200-group limit per token — large enterprises hit this ceiling
2. The mapping between Entra groups and PulseBoard entities is a PulseBoard concern, not an IdP concern
3. A database mapping is auditable (who changed what, when) and reversible without Entra admin access
4. We can enrich mappings with metadata (e.g., "this group maps to Wealth BU AND can see all Production projects")

### JWKS Caching Strategy

The backend fetches the JWKS from `https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys` and caches the key set in-memory for 1 hour. This means:
- Zero external calls on the hot path (JWT validation is local RSA verify)
- A key rotation propagates within 1 hour (Entra rotates keys on a ~6-week cycle)
- Cache is invalidated on key-ID (`kid`) miss — if a token presents an unknown `kid`, we re-fetch immediately

---

## Consequences

**Positive:**
- Zero password management — no credential breach surface area
- Existing enterprise MFA, Conditional Access, and device compliance policies apply to PulseBoard automatically
- SCIM ensures users are deprovisioned the moment they leave the organisation
- IT team manages role assignment in Entra — no PulseBoard admin UI required for day-to-day access management
- JWT validation is stateless — scales to many Cloud Run instances without session-sharing infrastructure

**Negative:**
- Dependency on Microsoft Entra availability — if Entra is down, no one can log in
- Guest/B2B users (contractors from outside the tenant) require explicit Entra B2B invitation before they can access PulseBoard
- The 200-group-per-token limit means BU/Function scoping cannot rely on Entra group claims alone (mitigated by database mapping approach)
- Client secret rotation every 24 months must be tracked; expiry causes a complete authentication failure

**Mitigations:**
- Entra's SLA is 99.9% — acceptable for an internal tool; the fallback is to unblock access via a temporary bypass in an emergency (Admin-only override)
- Guest user onboarding is documented in the Entra Setup Guide
- Secret rotation reminder is built into the deployment guide; GCP Secret Manager supports versioned secrets for zero-downtime rotation

---

## Implementation Notes

### Token Validation (backend)

```python
# pulseboard/auth/entra.py
JWKS_URL = f"https://login.microsoftonline.com/{TENANT_ID}/discovery/v2.0/keys"
_jwks_cache: dict | None = None
_jwks_fetched_at: float = 0
JWKS_CACHE_TTL = 3600  # 1 hour

async def validate_entra_token(token: str) -> dict[str, Any]:
    jwks = await _fetch_jwks()
    header = jwt.get_unverified_header(token)
    key = _find_key(jwks, header["kid"])  # re-fetch on kid miss
    claims = jwt.decode(
        token,
        key,
        algorithms=["RS256"],
        audience=settings.entra_client_id,
        issuer=f"https://login.microsoftonline.com/{settings.entra_tenant_id}/v2.0",
    )
    return claims
```

### Role Extraction

```python
# pulseboard/dependencies.py
async def get_current_user(credentials, db) -> User:
    claims = await validate_entra_token(token)
    roles = claims.get("roles", [])
    if AppRole.admin in roles:
        user.role = AppRole.admin
    elif AppRole.contributor in roles:
        user.role = AppRole.contributor
    else:
        user.role = AppRole.viewer
```

### RBAC Context (BU/Function scoping)

```python
# pulseboard/auth/rbac.py
class RBACContext:
    @classmethod
    async def from_user(cls, user: User, db: AsyncSession) -> "RBACContext":
        if user.role == AppRole.admin:
            return cls(is_admin=True, ...)  # sees everything
        # resolve Entra group → BU/Function mappings
        mappings = await db.execute(
            select(EntraGroupMapping).where(
                EntraGroupMapping.entra_group_id.in_(user.entra_group_ids)
            )
        )
        # collect accessible_bu_ids, accessible_function_ids
```

### Frontend Auth (Next.js + MSAL)

```typescript
// components/layout/providers.tsx
const msalConfig = {
  auth: {
    clientId: process.env.NEXT_PUBLIC_ENTRA_CLIENT_ID!,
    authority: `https://login.microsoftonline.com/${process.env.NEXT_PUBLIC_ENTRA_TENANT_ID}`,
    redirectUri: `${window.location.origin}/auth/callback`,
  },
};
```

---

## Alternatives Rejected

### Okta / Auth0
Would require an additional SaaS vendor contract, additional data-residency controls, and duplication of the Conditional Access policies the enterprise already has in Entra. No meaningful benefit over the native Entra integration.

### AWS Cognito / Firebase Auth
Incompatible with the GCP-first architecture and the existing Entra deployment.

### Custom username/password + internal JWT
Introduces credential storage (GDPR risk), requires building MFA, violates enterprise policy that all internal applications must use SSO, and adds significant ongoing maintenance burden.

---

## Review Date

Revisit if:
- The enterprise migrates to a different IdP
- Entra B2B (guest user) requirements grow significantly
- A multi-tenant SaaS version of PulseBoard is considered (would require OIDC multi-tenancy changes)
