# ADR 0001 — LLM Provider: Gemini-Primary / Gemma-Fallback

**Status:** Accepted  
**Date:** 2024-01-01  
**Deciders:** AI Platform Team

---

## Context

PulseBoard's core value proposition is a conversational AI assistant that answers natural-language questions about an enterprise's AI portfolio. This requires a capable LLM with:

- **Function/tool calling** — the agent must invoke structured tools (query_projects, query_adoption_metric, etc.) and synthesize results
- **Long context** — portfolio summaries, conversation history, and tool results can exceed 20K tokens
- **Low hallucination rate** — factual grounding is the #1 product risk; the agent must cite sources for every claim
- **Streaming** — leaders expect first-token response in < 1.5 seconds
- **Enterprise data residency** — some deployments require data to stay within a specific GCP region

---

## Decision

**Primary:** Google Gemini 2.5 Pro (for reasoning + complex tool use) and Gemini 2.0 Flash (for cheap classification and quick responses), accessed via Vertex AI.

**Fallback:** Gemma 3 (self-hosted on Cloud Run with GPU, or via Vertex AI Model Garden), switchable via environment variable `LLM_PROVIDER=gemini|gemma`.

---

## Rationale

### Why Gemini (Primary)

| Factor | Assessment |
|---|---|
| Function calling | Native, first-class — parallel tool calls, structured outputs |
| Context window | 1M tokens (Pro) — sufficient for any realistic portfolio conversation |
| GCP-native | Zero additional auth — same service account, same VPC, Vertex AI SDK |
| Data residency | Vertex AI supports regional endpoints (us-central1, europe-west1, asia-south1) |
| Cost | Flash for cheap ops (~$0.075/1M input tokens), Pro for reasoning (~$1.25/1M) |
| Streaming | Native SSE streaming via `generate_content_async(stream=True)` |
| Grounding | Gemini 2.5 Pro has strong instruction-following for citation requirements |

### Why Gemma (Fallback)

| Scenario | Why Gemma |
|---|---|
| Air-gapped / offline deployment | No external API calls required |
| Cost sensitivity at extreme scale | Self-hosted cost per token is lower at high volume |
| Regulatory: no data leaves the org | Model runs entirely within the GCP project's VPC |
| Gemini API outage | Automatic failover keeps the product available |

Gemma's limitations (weaker tool-calling, smaller context) are acceptable for the fallback case — users see a disclaimer that responses may be less detailed.

### Why not Claude / GPT-4?

- **Anthropic Claude:** Excellent quality, but requires an external API endpoint outside GCP. Data residency controls are harder. Cost is comparable to Gemini Pro.
- **OpenAI GPT-4o:** Same data residency concern. Adds Azure OpenAI dependency if staying on Microsoft infrastructure — conflicts with our GCP-first architecture.
- **Decision:** We may add Claude as a second provider in v2 if enterprise customers request it. The `LLM_PROVIDER` env var and orchestrator abstraction are designed to make this straightforward.

---

## Consequences

**Positive:**
- Single cloud vendor (GCP) for compute + LLM — simplified IAM, billing, and observability
- Vertex AI SDK handles auth transparently via service account
- Easy model version upgrades (change `gemini_model` env var)

**Negative:**
- GCP vendor lock-in for the LLM layer
- Gemini API quotas may require increase requests for large organisations (>360 RPM)
- Gemma fallback requires GPU Cloud Run instance — adds ~$200–400/month if always-on

**Mitigations:**
- The agent orchestrator is abstracted — swapping providers requires only changes to `orchestrator.py`
- Rate limiting on `/agent/chat` (10 RPM per user) stays well within Gemini quotas for most deployments
- Gemma can be deployed on-demand (min instances = 0) for cost-sensitive setups

---

## Implementation Notes

```python
# config.py
llm_provider: Literal["gemini", "gemma"] = "gemini"
gemini_model: str = "gemini-2.5-pro-002"   # Flash: "gemini-2.0-flash-002"

# orchestrator.py — provider routing
if settings.llm_provider == "gemini":
    async for chunk in self._run_gemini(system, messages, tool_calls_log):
        yield chunk
else:
    result = await self._run_gemma_fallback(system, messages)
    yield {"type": "text_delta", "delta": result}
```

---

## Review Date

Revisit this decision when Gemma 3 tool-calling capabilities are assessed in production (Q3 2025), or when an enterprise customer requires an on-premises LLM.
