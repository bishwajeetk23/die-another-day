# GCP Deployment Guide

## Prerequisites

| Tool | Minimum version | Check |
|---|---|---|
| `gcloud` CLI | 450+ | `gcloud version` |
| `terraform` | 1.5+ | `terraform version` |
| `docker` | 24+ | `docker version` |
| GCP Project | Owner role | `gcloud projects describe $PROJECT_ID` |
| Entra app registered | See [entra-setup.md](./entra-setup.md) | — |

---

## One-Command Deployment

```bash
# Set required environment variables
export PROJECT_ID=my-pulseboard-prod
export REGION=asia-south1            # or us-central1, europe-west1, etc.
export ENTRA_TENANT_ID=<your-entra-tenant-id>
export ENTRA_CLIENT_ID=<your-entra-client-id>
export ENTRA_CLIENT_SECRET=<your-entra-client-secret>

# Deploy (add --demo to load sample data)
./scripts/deploy-gcp.sh

# With demo data:
./scripts/deploy-gcp.sh --demo
```

The script will:
1. Enable all required GCP APIs
2. Provision infrastructure via Terraform (Cloud SQL, BigQuery, Redis, GCS, Cloud Run, Secret Manager)
3. Build and push Docker images via Cloud Build
4. Deploy three Cloud Run services (API, Web, Worker)
5. Run Alembic database migrations
6. (With `--demo`) Seed 40 AI projects, 25 users, 90 days of KPI data

**Estimated time:** 15–20 minutes on a fresh GCP project.

---

## Architecture

```
Internet
  │
  ▼
Cloud Run: pulseboard-web (Next.js)
  │  HTTPS, public
  │
  ├──────────────────────────────────────────────────────────┐
  │                                                          │
  ▼                                                          │
Cloud Run: pulseboard-api (FastAPI)                         │
  │  HTTPS, public (Entra JWT required on all routes)       │
  │                                                          │
  ├── Cloud SQL (PostgreSQL 15) ─── VPC                     │
  ├── Memorystore (Redis) ─────────── VPC                   │
  ├── BigQuery (analytics store)                             │
  ├── Cloud Storage (file uploads)                           │
  ├── Vertex AI / Gemini (LLM)                              │
  └── Secret Manager (credentials)                           │
  │                                                          │
  ▼                                                          │
Cloud Run: pulseboard-worker (Celery)                        │
  │  Internal, VPC-connected                                 │
  └── Jira Cloud API ───────────────────────────────────────┘
      Microsoft Graph API
```

---

## Post-Deployment Steps

After the script completes, you **must** do these before the app works:

### 1. Add Redirect URI in Entra
Copy the **Web URL** printed at the end of deployment, then:
1. Go to [Azure Portal](https://portal.azure.com) → Entra ID → App registrations → PulseBoard
2. Authentication → Add `<WEB_URL>/auth/callback` as a Redirect URI
3. Save

### 2. First Admin Login
1. Open `<WEB_URL>` in your browser
2. Sign in with your Entra account
3. You're automatically the first Admin (the first user to sign in gets Admin if no role mappings exist)

### 3. Map Entra Groups to BUs/Functions
1. Settings → Identity → Entra Group Mappings
2. Map your Entra security groups to PulseBoard BUs and Functions
3. See [entra-setup.md](./entra-setup.md#8-map-entra-security-groups-to-pulseboard-busfunctions)

### 4. Add Jira Integration
1. Settings → Integrations → Add Jira Instance
2. Paste base URL, email, API token → Test & Save

### 5. Push First KPI Data Point
1. Onboarding → Define KPI → Generate Token
2. POST a test value using the curl example
3. Verify it appears in Adoption Analytics

---

## Infrastructure Components

| Service | Purpose | Config |
|---|---|---|
| Cloud Run: API | FastAPI backend | 2 vCPU, 1GB RAM, min 1 instance |
| Cloud Run: Web | Next.js frontend | 1 vCPU, 512MB RAM, min 0 instances |
| Cloud Run: Worker | Celery task queue | 2 vCPU, 1GB RAM, min 1 instance |
| Cloud SQL | PostgreSQL 15 operational DB | `db-g1-small` (dev) / `db-n1-standard-2` (prod) |
| Memorystore | Redis for Celery broker | 1GB BASIC tier |
| BigQuery | Analytics time-series | Pay-per-query |
| Cloud Storage | File uploads | Standard storage, 365-day lifecycle |
| Secret Manager | Credentials vault | Per-secret pricing |
| Artifact Registry | Docker image registry | Docker format |
| Cloud Tasks | Async job queue | Per-operation pricing |

---

## Estimated Monthly Cost

### Small Organisation (~50 AI projects, 100 KPIs, 20 users)

| Service | Monthly Cost (USD) |
|---|---|
| Cloud Run — API (min 1 instance, ~2 vCPU avg) | ~$35 |
| Cloud Run — Web (scales to 0) | ~$5 |
| Cloud Run — Worker (min 1 instance) | ~$35 |
| Cloud SQL db-g1-small (1 vCPU, 1.7GB RAM) | ~$30 |
| Memorystore Redis 1GB | ~$25 |
| BigQuery (storage + queries, small vol.) | ~$5 |
| Cloud Storage (<1GB uploads) | ~$1 |
| Secret Manager (<10 secrets) | ~$1 |
| Vertex AI / Gemini (est. 500 queries/month) | ~$15 |
| Networking / Load Balancer | ~$10 |
| **Total** | **~$162/month** |

### Large Organisation (~500 AI projects, 1000 KPIs, 200 users)

| Service | Monthly Cost (USD) |
|---|---|
| Cloud Run — API (min 2 instances, ~4 vCPU avg) | ~$120 |
| Cloud Run — Web (scales 0–5) | ~$20 |
| Cloud Run — Worker (min 2 instances) | ~$80 |
| Cloud SQL db-n1-standard-4 (4 vCPU, 15GB RAM) | ~$180 |
| Memorystore Redis 5GB | ~$80 |
| BigQuery (50GB storage + 1TB queries/month) | ~$25 |
| Cloud Storage (~50GB uploads) | ~$5 |
| Secret Manager (<20 secrets) | ~$2 |
| Vertex AI / Gemini (est. 5000 queries/month) | ~$150 |
| Cloud Armor (DDoS + WAF) | ~$30 |
| Networking / Load Balancer | ~$20 |
| **Total** | **~$712/month** |

> All costs are estimates in USD. Actual costs vary by query complexity, data volume, and Cloud Run cold start patterns. Enable Cloud Billing budgets and alerts.

---

## Scaling for Production

### Cloud SQL
- Upgrade `db_tier` to `db-n1-standard-2` or higher for >50 concurrent users
- Enable **read replicas** for analytics-heavy workloads
- Enable **automated backups** and **point-in-time recovery** (already in Terraform for `production` environment)

### Cloud Run
- Adjust `min_instance_count` and `max_instance_count` in Terraform
- Set `cpu = "4"` for the API if Gemini tool-calling is CPU-intensive

### Redis
- Upgrade to `STANDARD_HA` tier for high availability in production

### Gemini Rate Limits
- Default Gemini 2.5 Pro quota: 360 RPM (requests per minute)
- For heavy usage, request quota increase via [Google Cloud Console](https://console.cloud.google.com/iam-admin/quotas)

---

## Security Hardening (Production)

1. **Cloud Armor:** Add IP allowlisting if PulseBoard should only be accessible from corporate IPs
2. **VPC Service Controls:** Isolate Cloud SQL and BigQuery from public internet
3. **Binary Authorization:** Require signed container images in Cloud Build
4. **Audit Logging:** Enable Data Access audit logs on Cloud SQL and Secret Manager
5. **Secret Rotation:** Set up automatic rotation for the Entra client secret (expires in 24 months)

---

## Teardown

To completely remove all GCP resources:

```bash
cd infra/terraform
terraform destroy \
  -var="project_id=${PROJECT_ID}" \
  -var="region=${REGION}" \
  -var="entra_tenant_id=${ENTRA_TENANT_ID}" \
  -var="entra_client_id=${ENTRA_CLIENT_ID}" \
  -var="entra_client_secret=${ENTRA_CLIENT_SECRET}"
```

> ⚠️ This permanently deletes all data including Cloud SQL databases and GCS files. Ensure you have backups.
