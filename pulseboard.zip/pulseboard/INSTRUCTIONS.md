# PulseBoard — Complete Reference

PulseBoard is a production-grade AI Project & Adoption Intelligence Platform for enterprise central AI teams. It provides a single source of truth for all AI initiatives across business units and functions, with a conversational AI assistant that answers natural-language questions about the portfolio using live data.

---

## Table of Contents

1. [What PulseBoard Does](#1-what-pulseboard-does)
2. [Architecture Overview](#2-architecture-overview)
3. [Repository Structure](#3-repository-structure)
4. [Technology Stack](#4-technology-stack)
5. [Core Concepts](#5-core-concepts)
6. [Authentication & Access Control](#6-authentication--access-control)
7. [AI Assistant](#7-ai-assistant)
8. [Project Management](#8-project-management)
9. [Adoption Analytics](#9-adoption-analytics)
10. [Governance](#10-governance)
11. [Integrations](#11-integrations)
12. [Background Jobs](#12-background-jobs)
13. [Infrastructure](#13-infrastructure)
14. [Configuration Reference](#14-configuration-reference)
15. [API Quick Reference](#15-api-quick-reference)
16. [Design System](#16-design-system)
17. [Data Model Summary](#17-data-model-summary)
18. [Extending PulseBoard](#18-extending-pulseboard)
19. [Security Notes](#19-security-notes)
20. [Costs](#20-costs)

---

## 1. What PulseBoard Does

**For the Chief AI Officer and AI Steering Committee:**
- Single portfolio view of all AI initiatives across every Business Unit and Function
- Natural-language AI assistant — ask questions like "Which projects are at risk this quarter?" and get cited, data-grounded answers with inline charts
- Weekly automated digest email summarising portfolio health
- Governance dashboard: Tier 1/2/3 model risk status, compliance heatmap, sunset candidates

**For AI Project Leads (Contributors):**
- Track project lifecycle: Ideation → Qualification → PoC → Pilot → Production → Scale → Sunset
- Manage milestones, risks, and issues
- RAG (Red-Amber-Green) status — auto-calculated from schedule variance, or manually overridden
- Connect Jira projects for automatic 15-minute sync

**For Product Owners managing live AI products:**
- Self-serve KPI onboarding: push data via API, pull from your own endpoints, query BigQuery, or upload CSV
- Time-series adoption charts with dimension slicing (by region, department, user grade)
- Target tracking and trend analysis

---

## 2. Architecture Overview

```
Internet
  │
  ├── Cloud Run: pulseboard-web (Next.js 14)
  │     └── Serves the frontend, proxies API calls
  │
  ├── Cloud Run: pulseboard-api (FastAPI + Uvicorn)
  │     ├── Cloud SQL — PostgreSQL 15 (operational data, private IP)
  │     ├── Memorystore — Redis (Celery broker, private IP)
  │     ├── BigQuery (KPI time-series analytics)
  │     ├── Cloud Storage (file uploads)
  │     ├── Vertex AI / Gemini (LLM via SDK)
  │     └── Secret Manager (credentials)
  │
  └── Cloud Run: pulseboard-worker (Celery)
        ├── Jira Cloud API (sync every 15 min)
        ├── BigQuery (KPI pipeline writes)
        └── External KPI source APIs (pull mode)

Identity: Microsoft Entra ID (OIDC — all auth flows)
CI/CD:    Cloud Build → Artifact Registry → Cloud Run
IaC:      Terraform (all GCP resources)
```

**LLM strategy:** Gemini 2.5 Pro (primary, complex reasoning + tool calling) and Gemini 2.0 Flash (cheap classification). Gemma 3 self-hosted on Cloud Run GPU as automatic fallback when Gemini is unavailable.

---

## 3. Repository Structure

```
pulseboard/
├── apps/
│   ├── api/                        Backend — Python / FastAPI
│   │   ├── pulseboard/
│   │   │   ├── main.py             App entrypoint, middleware, router registration
│   │   │   ├── config.py           Pydantic Settings (all env vars)
│   │   │   ├── dependencies.py     Auth dependencies: CurrentUser, RBACCtx
│   │   │   ├── database.py         SQLAlchemy async engine + session factory
│   │   │   ├── models/             SQLAlchemy ORM models
│   │   │   │   ├── base.py         Base, UUIDMixin, TimestampMixin
│   │   │   │   ├── user.py         User, Organization, AIConversation, AIMessage
│   │   │   │   ├── project.py      AIProject, Milestone, Risk, Issue, Snapshot
│   │   │   │   ├── adoption.py     AdoptionKPI
│   │   │   │   ├── organization.py BusinessUnit, Function, EntraGroupMapping
│   │   │   │   ├── jira.py         JiraInstance, JiraTicketCache
│   │   │   │   └── audit.py        AuditEvent
│   │   │   ├── schemas/            Pydantic v2 request/response schemas
│   │   │   ├── routers/            FastAPI route handlers
│   │   │   │   ├── projects.py     CRUD, milestones, risks, stage advance, RAG
│   │   │   │   ├── adoption.py     KPI CRUD, ingest endpoint, time-series values
│   │   │   │   ├── agent.py        SSE chat endpoint, conversation management
│   │   │   │   ├── onboarding.py   Jira wizard, file upload, KPI token generation
│   │   │   │   ├── governance.py   Portfolio summary, compliance data
│   │   │   │   ├── admin.py        User management, Entra mappings
│   │   │   │   └── auth.py         /users/me, auth callback helpers
│   │   │   ├── services/
│   │   │   │   ├── project_service.py  Business logic, RBAC filtering, slugs
│   │   │   │   └── adoption_service.py KPI token hashing, BigQuery writes
│   │   │   ├── auth/
│   │   │   │   ├── entra.py        JWKS-cached JWT validation
│   │   │   │   └── rbac.py         RBACContext — BU/Function data scoping
│   │   │   ├── agent/
│   │   │   │   ├── orchestrator.py Gemini tool loop, SSE streaming, fallback
│   │   │   │   ├── tools.py        9 agent tools: query_projects, drift, etc.
│   │   │   │   └── prompts.py      System prompt with AI lifecycle vocabulary
│   │   │   └── integrations/
│   │   │       └── jira/client.py  Jira REST client with pagination
│   │   ├── alembic/                Database migrations
│   │   │   └── versions/0001_initial.py  All 19 tables, correct dep order
│   │   ├── tests/
│   │   │   ├── conftest.py         Fixtures: in-memory DB, auth mocks, seeds
│   │   │   ├── test_projects.py    30+ project endpoint tests
│   │   │   ├── test_adoption.py    KPI and ingestion tests
│   │   │   ├── test_auth.py        Auth, JWT, RBAC, auto-provisioning tests
│   │   │   └── agent_evals.py      32 agent eval question-answer pairs
│   │   ├── pyproject.toml
│   │   └── Dockerfile
│   │
│   ├── web/                        Frontend — TypeScript / Next.js 14
│   │   ├── app/                    App Router pages
│   │   │   ├── (ai)/page.tsx       AI Assistant home (streaming chat)
│   │   │   ├── projects/
│   │   │   │   ├── page.tsx        Portfolio list view (URL-state filters)
│   │   │   │   ├── [id]/page.tsx   Project deep-dive (tabs: Milestones, Risks, etc.)
│   │   │   │   └── kanban/page.tsx 7-column Kanban board with stage advance
│   │   │   ├── adoption/
│   │   │   │   ├── page.tsx        Adoption overview
│   │   │   │   └── kpis/[id]/page.tsx  KPI detail: chart, dimensions, trend
│   │   │   ├── governance/page.tsx Risk tier summary, compliance heatmap
│   │   │   ├── onboarding/
│   │   │   │   ├── kpi/page.tsx    4-step KPI wizard (Push/Pull/SQL/Manual)
│   │   │   │   ├── jira/page.tsx   3-step Jira wizard (Connect/Select/Map)
│   │   │   │   └── upload/page.tsx Drag-and-drop CSV/XLSX tracker upload
│   │   │   └── settings/page.tsx   Admin: Identity, Integrations, Users
│   │   ├── components/
│   │   │   ├── layout/             Sidebar, topbar, shell, providers
│   │   │   ├── projects/           StagePipeline, RAGIndicator
│   │   │   ├── charts/             InlineChart (Recharts), Sparkline
│   │   │   ├── command-palette/    ⌘K palette with "Ask AI" action
│   │   │   └── ui/                 Shared primitives (Button, Card, etc.)
│   │   ├── lib/
│   │   │   ├── api/                Typed fetch clients for each domain
│   │   │   ├── auth/               MSAL config and auth provider
│   │   │   └── hooks/              React Query hooks
│   │   ├── package.json
│   │   └── Dockerfile
│   │
│   └── worker/                     Background jobs — Python / Celery
│       ├── celery_app.py           Beat schedule + app config
│       ├── tasks/
│       │   ├── jira_sync.py        Sync Jira tickets (every 15 min)
│       │   ├── snapshot.py         Daily project history snapshots
│       │   ├── rag_auto.py         Hourly RAG recalculation from schedule variance
│       │   ├── digest.py           Monday morning portfolio digest email
│       │   └── kpi_pipeline.py     Pull-mode KPI fetch + BigQuery write
│       └── Dockerfile
│
├── infra/
│   ├── terraform/
│   │   ├── main.tf                 All GCP resources (VPC, Cloud SQL, Redis, BQ, etc.)
│   │   ├── variables.tf            Input variables with descriptions
│   │   └── outputs.tf              Printed URLs and next-steps banner
│   └── cloudbuild/
│       └── cloudbuild.yaml         Full CI/CD: test → build → push → migrate → deploy → smoke
│
├── packages/
│   └── shared-types/schema.json    JSON Schema for all domain types
│
├── scripts/
│   ├── deploy-gcp.sh               One-command GCP deployment
│   └── seed.py                     Demo data: 40 projects, 25 users, 90-day KPIs
│
├── docs/
│   ├── architecture.md             System diagrams (Mermaid)
│   ├── data-model.md               ERD and all table definitions
│   ├── api-reference.md            REST endpoint reference
│   ├── deploy-gcp.md               GCP deployment guide
│   ├── entra-setup.md              Entra ID configuration (IT admin guide)
│   ├── demo-script.md              2-minute CAIO demo script
│   ├── how-to-onboard-project.md   Guide for BU project leads
│   ├── how-to-onboard-adoption-kpi.md  Guide for product owners
│   └── adr/
│       ├── 0001-llm-provider.md    Why Gemini-primary / Gemma-fallback
│       └── 0002-entra-auth.md      Why Entra ID OIDC
│
├── docker-compose.yml              Local dev stack
├── INSTALL.md                      Installation and testing guide
└── INSTRUCTIONS.md                 This file
```

---

## 4. Technology Stack

### Backend
| Component | Technology | Version |
|---|---|---|
| API framework | FastAPI | 0.111+ |
| Python runtime | CPython | 3.12 |
| ORM | SQLAlchemy | 2.0 (async) |
| Migrations | Alembic | 1.13+ |
| Data validation | Pydantic | v2 |
| Task queue | Celery | 5.3+ |
| HTTP client | httpx | 0.27+ |
| Structured logging | structlog | 24+ |
| ASGI server | Uvicorn | 0.30+ |

### Frontend
| Component | Technology | Version |
|---|---|---|
| Framework | Next.js | 14 (App Router) |
| Language | TypeScript | 5 (strict) |
| Styling | Tailwind CSS | 3.4+ |
| Animation | Framer Motion | 11+ |
| Charts | Recharts | 2.12+ |
| Data fetching | TanStack Query | 5+ |
| Auth | MSAL.js | 3+ |
| Command palette | cmdk | 1+ |
| Fonts | Geist Sans + Geist Mono | — |

### Infrastructure
| Component | Technology |
|---|---|
| Compute | GCP Cloud Run (3 services) |
| Database | Cloud SQL PostgreSQL 15 |
| Cache / broker | Memorystore Redis |
| Analytics | BigQuery |
| Object storage | Cloud Storage |
| Secrets | Secret Manager |
| IaC | Terraform 1.5+ |
| CI/CD | Cloud Build |
| Container registry | Artifact Registry |
| LLM | Vertex AI (Gemini 2.5 Pro + 2.0 Flash) |
| LLM fallback | Gemma 3 on Cloud Run GPU |

---

## 5. Core Concepts

### AI Lifecycle Stages
Projects move through 7 ordered stages. Advancement requires passing a stage gate checklist.

| Stage | Meaning |
|---|---|
| **Ideation** | Use-case idea captured, no work started |
| **Qualification** | Assessing feasibility, value, data — GO/NO-GO pending |
| **PoC** | Small-scale prototype to test the core hypothesis |
| **Pilot** | Limited real user group in production conditions |
| **Production** | Live for the full intended audience |
| **Scale** | Expanding to more regions, BUs, or use-cases |
| **Sunset** | Being actively decommissioned |

The frontend renders this as a 7-dot connected pipeline (`StagePipeline` component). The current stage pulses with a Framer Motion animation.

### RAG Status
Red-Amber-Green health indicator. Auto-calculated hourly by the Worker from schedule variance:
- **Green:** forecast within 7 days of baseline
- **Amber:** 8–21 days late
- **Red:** >21 days late

Admins and Contributors can manually override with a reason. The override is preserved until explicitly cleared.

### AI Pattern
Eight categories describing the type of AI: `predictive_ml`, `generative_ai`, `agentic`, `computer_vision`, `nlp`, `recommendation`, `optimization`, `rpa_ai`.

### Model Risk Tier
- **Tier 1:** High-impact — financial decisions, credit scoring, regulatory compliance
- **Tier 2:** Medium — customer experience or operational efficiency at scale
- **Tier 3:** Low-risk — internal tools, analytics, non-consequential decisions

---

## 6. Authentication & Access Control

**All authentication is via Microsoft Entra ID OIDC.** There is no username/password.

### Auth Flow
1. User clicks "Sign in with Microsoft" in the Next.js frontend
2. MSAL.js redirects to Entra's Authorization Code + PKCE endpoint
3. Entra issues a JWT containing `roles` and `groups` claims
4. Frontend attaches the JWT as `Authorization: Bearer <token>` on every API call
5. FastAPI validates the JWT against Entra's JWKS (cached 1 hour in-process)
6. User is auto-provisioned in the `users` table on first login

### Roles
Assigned via Entra App Roles:

| Role | Entra value | Access |
|---|---|---|
| Admin | `PulseBoard.Admin` | Everything — all BUs, all functions, all settings |
| Contributor | `PulseBoard.Contributor` | Create/edit projects in own BU or Function |
| Viewer | `PulseBoard.Viewer` | Read-only in own BU or Function |

### Data Scoping (RBAC)
Admins see everything. Non-admins see only projects belonging to Business Units or Functions mapped to their Entra security groups.

The mapping is configured by an Admin in **Settings → Identity → Entra Group Mappings**. A `sg-wealth-team` group → Wealth BU mapping means members of that group only see Wealth projects in list/search views (enforced at the SQL query level, not just the UI).

The `RBACContext` object is built per-request in `auth/rbac.py` and passed to all service methods.

---

## 7. AI Assistant

The AI Assistant is the primary user interface. It is a streaming conversational agent powered by Gemini 2.5 Pro with tool-calling.

### Agent Architecture
```
User message
  → Rate limit check (10 RPM per user)
  → Load conversation history from DB
  → Build system prompt with AI lifecycle vocabulary
  → Send to Gemini with tool definitions
  → Gemini calls tools (parallel execution)
      → query_projects        SQL query, RBAC-filtered
      → query_adoption_metric BigQuery time-series query
      → get_project_baseline_vs_actual  Schedule variance calc
      → get_risk_register     Open/escalated risks
      → get_model_drift_signal  First-half vs second-half KPI avg
      → get_value_realization   Expected vs realised value
      → lookup_owner            User/project ownership
      → render_chart            Returns structured chart data
      → summarize_governance_status  Tier summary counts
  → Tool results fed back to Gemini
  → Gemini generates response (max 5 tool rounds)
  → Streamed as SSE events to browser
  → Persisted as AIMessage with citations and tool call log
```

### SSE Event Types
The chat endpoint (`POST /agent/chat`) returns a `text/event-stream` response. Each event is a JSON object:

| Type | When | Payload |
|---|---|---|
| `text_delta` | Every token | `{delta: "word "}` |
| `tool_call` | Tool invoked | `{name, args, call_id}` |
| `tool_result` | Tool returned | `{call_id, result, duration_ms}` |
| `citation` | Inline `[N]` reference | `{ref, text, source}` |
| `chart` | Inline chart | `{chart_type, data, x_key, y_key}` |
| `error` | Failure | `{message}` |
| `done` | Stream complete | `{conversation_id, message_id}` |

### Citation Rules
The system prompt instructs the agent: every numeric or factual claim must be cited with `[N]` inline. If a tool returns no data, the agent must say so explicitly rather than guessing. "I don't know" is always preferable to hallucination.

### Fallback Mode
If `VERTEX_AI_PROJECT` is not configured: `_mock_response()` returns a placeholder explaining dev mode.
If Gemini is unavailable: `_run_gemma_fallback()` calls the Gemma 3 Cloud Run endpoint. Users see a banner noting responses may be less detailed.

---

## 8. Project Management

### Creating a Project
Projects can be created via:
- **Manual form** in the UI (Onboarding → New Project)
- **CSV/XLSX upload** (Onboarding → Upload Tracker)
- **Jira sync** (creates a PulseBoard project linked to a Jira project)
- **REST API:** `POST /projects`

### Stage Gates
Each stage transition has required checklist items. The `stage_checklist` JSONB column stores completion state per stage. The `advance-stage` endpoint validates all items are checked before allowing advancement. Stage advances are recorded in `project_history_snapshots`.

### Schedule Variance
`schedule_variance_days = (forecast_end_date - baseline_end_date).days`

Positive = late. This is calculated and stored on each history snapshot. The RAG Worker uses it for automatic status recalculation.

**Important:** `baseline_end_date` should be frozen at project kick-off and never changed. Only `forecast_end_date` is updated as the project evolves.

### Jira Integration
When a Jira project is linked, the Worker syncs all issues every 15 minutes into `jira_ticket_cache`. The Project → Jira tab shows live ticket status without leaving PulseBoard.

Field mapping is configurable: Jira project lead → PulseBoard product owner, labels with `stage:` prefix → lifecycle stage, etc.

---

## 9. Adoption Analytics

### KPI Categories
| Category | Examples |
|---|---|
| Usage | DAU, WAU, Sessions, Invocations/day |
| Quality | CSAT (1-5), Thumbs-up rate, Escalation rate |
| Funnel | Eligible → Activated → Recurring → Power User rates |
| Value Realization | Hours saved/week, Revenue uplift, Deflection rate |
| Health | Error rate, P95 latency, Cost per 1K calls |
| Trust & Safety | Flagged response rate, Policy override rate |

### Ingestion Modes

**Mode A — Push API (recommended)**
PulseBoard generates a HTTPS endpoint + bearer token. Your system POSTs data:
```bash
POST /adoption/kpis/{kpi-id}/ingest
Authorization: Bearer pb_kpi_xxxx
{"ts": "2025-01-01T09:00:00Z", "value": 4287, "dimensions": {"region": "APAC"}}
```
Token is SHA-256 hashed and stored — never stored in plaintext.

**Mode B — Pull API**
PulseBoard polls your endpoint on a schedule (minimum 30 minutes). You provide the URL, auth, and a JMESPath expression to extract the value.

**Mode C — SQL Pipeline**
PulseBoard runs a SQL query against your BigQuery or Snowflake warehouse on a schedule. Query must return `value` and `ts` columns; dimension columns use a `dimension_` prefix.

**Mode D — Manual Upload**
CSV upload. Columns: `ts, value, dimension_region, dimension_grade, ...`

### Data Storage
- **KPI metadata** (name, target, direction) → Cloud SQL `adoption_kpis` table
- **Time-series values** → BigQuery `adoption_kpi_values` table, partitioned by `ts` (DAY), clustered by `kpi_id`
- Dual-write ensures transactional consistency for metadata while BigQuery handles analytical queries efficiently

### Dimensions
Define dimension keys upfront (e.g., `region`, `department`, `employee_grade`). Push them with each data point. The KPI detail page lets you pivot the chart by any dimension.

---

## 10. Governance

The Governance page (`/governance`) is visible to all roles but most useful for Admins and the CAIO.

### What it shows
- **By Risk Tier:** Count of projects at each tier, with RAG breakdown within each tier
- **Compliance heatmap:** Tier 1 projects by BU — which BUs have the most high-risk AI
- **Sunset candidates:** Projects that have been in the same stage for >90 days or have been Red for >30 days
- **Escalated risks:** Open risks with `status = escalated` across the portfolio
- **Stale KPIs:** KPIs with no data ingested in the last 48 hours

---

## 11. Integrations

### Microsoft Entra ID
- OIDC for authentication
- App Roles for coarse-grained authorization
- Security group → BU/Function mapping for data scoping
- Optional SCIM provisioning for automatic user lifecycle management
- See `docs/entra-setup.md` for full IT admin setup guide

### Jira Cloud
- Connection per-instance (supports multiple Jira instances)
- API token authentication (email + token)
- Automatic 15-minute sync via Celery beat
- Field mapping: configurable in the onboarding wizard
- Supports multiple Jira projects linked to one PulseBoard project

### BigQuery (analytics)
- KPI time-series written on every push/pull/SQL ingestion
- Project history snapshots written daily
- Partitioned and clustered for cost-efficient queries
- The AI agent's `query_adoption_metric` tool queries BigQuery directly

---

## 12. Background Jobs

All scheduled by Celery Beat (`apps/worker/celery_app.py`):

| Job | Schedule | What it does |
|---|---|---|
| `sync_jira_all` | Every 15 minutes | Syncs all linked Jira projects, upserts ticket cache |
| `snapshot_all_projects` | Daily at midnight UTC | Writes point-in-time snapshots with RAG + schedule variance |
| `recalculate_rag_all` | Every hour | Computes RAG from `forecast_end_date - baseline_end_date`, skips manual overrides |
| `send_weekly_digest` | Monday 8am UTC | Builds portfolio summary, sends digest email (email sender is stubbed — wire up SendGrid/SES) |
| `run_kpi_pull_pipelines` | Every 30 minutes | Fetches KPIs in pull mode (HTTP) and pipeline mode (BigQuery SQL), writes results |

---

## 13. Infrastructure

All GCP resources are defined in `infra/terraform/main.tf` and provisioned via `./scripts/deploy-gcp.sh`.

### Resources created

| Resource | Purpose |
|---|---|
| VPC + Private IP range | Private networking for Cloud SQL and Redis |
| VPC Access Connector | Allows Cloud Run to reach private VPC resources |
| Cloud SQL PostgreSQL 15 | Operational database, private IP, automated backups |
| Memorystore Redis 1GB | Celery broker and result backend |
| BigQuery dataset | Analytics — KPI values + history snapshots |
| Cloud Storage bucket | File uploads (CSV, XLSX), 365-day lifecycle |
| Secret Manager | DB connection string, Entra client secret |
| Artifact Registry | Docker image registry |
| Cloud Run: pulseboard-api | FastAPI backend |
| Cloud Run: pulseboard-web | Next.js frontend |
| Cloud Run: pulseboard-worker | Celery worker |
| Service account | IAM principal for Cloud Run services |
| IAM bindings (8 roles) | aiplatform.user, cloudsql.client, bigquery.dataEditor, etc. |

### CI/CD Pipeline (`infra/cloudbuild/cloudbuild.yaml`)
Triggered on push to main branch:
1. Install + lint Python API
2. Run backend tests (in-memory SQLite)
3. Install + build Next.js frontend
4. Build 3 Docker images in parallel (with layer caching)
5. Push images to Artifact Registry
6. Run Alembic migrations via Cloud Run Job
7. Deploy 3 Cloud Run services
8. Smoke-test the API health endpoint

---

## 14. Configuration Reference

All configuration is via environment variables. In local dev they come from `.env`. In GCP they are set on Cloud Run services and sourced from Secret Manager.

### Required for production

| Variable | Description |
|---|---|
| `DATABASE_URL` | `postgresql+asyncpg://user:pass@host/db` |
| `REDIS_URL` | `redis://host:6379` |
| `ENTRA_TENANT_ID` | Azure AD tenant ID |
| `ENTRA_CLIENT_ID` | PulseBoard app registration Client ID |
| `ENTRA_CLIENT_SECRET` | App registration client secret |
| `ENTRA_AUDIENCE` | Usually same as `ENTRA_CLIENT_ID` |
| `VERTEX_AI_PROJECT` | GCP project ID for Vertex AI |
| `VERTEX_AI_LOCATION` | e.g. `us-central1` |
| `GCS_BUCKET_NAME` | Cloud Storage bucket for uploads |
| `SECRET_KEY` | Random string for internal signing |

### Optional

| Variable | Default | Description |
|---|---|---|
| `ENVIRONMENT` | `production` | Set to `development` to bypass Entra auth locally |
| `LLM_PROVIDER` | `gemini` | `gemini` or `gemma` |
| `GEMINI_MODEL` | `gemini-2.5-pro-002` | Gemini model version |
| `GEMMA_ENDPOINT` | — | URL of Gemma Cloud Run service |
| `BIGQUERY_DATASET` | `pulseboard` | BigQuery dataset name |
| `CORS_ORIGINS` | `*` | Comma-separated allowed origins |
| `LOG_LEVEL` | `INFO` | `DEBUG`, `INFO`, `WARNING`, `ERROR` |

---

## 15. API Quick Reference

**Base URL:** `https://api.pulseboard.app` (or your Cloud Run URL)
**Auth:** `Authorization: Bearer <entra_jwt>` on all endpoints except `/health`

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Service health — no auth |
| GET | `/users/me` | Current user profile |
| GET | `/projects` | List projects (RBAC-filtered, paginated) |
| POST | `/projects` | Create project |
| GET | `/projects/{id}` | Project detail with milestones + risks |
| PATCH | `/projects/{id}` | Update project fields |
| POST | `/projects/{id}/advance-stage` | Advance lifecycle stage |
| POST | `/projects/{id}/rag-override` | Manual RAG status override |
| GET | `/projects/{id}/history` | Historical snapshots |
| POST | `/projects/{id}/milestones` | Create milestone |
| POST | `/projects/{id}/risks` | Create risk |
| GET | `/adoption/kpis` | List KPI definitions |
| POST | `/adoption/kpis` | Create KPI (returns ingest token) |
| POST | `/adoption/kpis/{id}/ingest` | Push KPI data (Bearer pb_kpi_xxx) |
| GET | `/adoption/kpis/{id}/values` | Time-series data |
| GET | `/adoption/kpis/starter-library` | 15 pre-defined KPI templates |
| POST | `/agent/conversations` | Create conversation |
| GET | `/agent/conversations` | List conversations |
| POST | `/agent/chat` | Stream chat (SSE, 10 RPM limit) |
| GET | `/governance/summary` | Portfolio governance overview |
| GET | `/settings/entra-mappings` | List group mappings |
| POST | `/settings/entra-mappings` | Add group mapping |
| GET | `/users` | List all users (Admin only) |
| PATCH | `/users/{id}/role` | Update user role (Admin only) |

Full documentation with request/response schemas: see `docs/api-reference.md` or visit `/docs` on the running API.

---

## 16. Design System

### Colors
| Token | Value | Use |
|---|---|---|
| Background | `#0A0A0F` | Page backgrounds |
| Surface | `#13131A` | Cards, panels, inputs |
| Accent | `#8B5CF6` | Electric violet — CTAs, active states, highlights |
| Accent hover | `#7c3aed` | Darker violet on hover |
| Accent light | `#a78bfa` | Links, secondary accents |
| Border | `rgba(255,255,255,0.08)` | Subtle card borders |
| Text primary | `#ffffff` | Headings |
| Text secondary | `rgba(255,255,255,0.5)` | Body, labels |
| Text muted | `rgba(255,255,255,0.3)` | Metadata, timestamps |

### Typography
- **UI text:** Geist Sans (all sizes)
- **Numbers, IDs, code, chart axes:** Geist Mono

### Key Components
- **`StagePipeline`** — 7 connected dots, current stage glows with Framer Motion pulse, past stages filled, future stages empty
- **`RAGIndicator`** — Pulsing ring animation for amber/red, static for green; always shows text for accessibility
- **`InlineChart`** — Recharts wrapper (line/bar/area), dark theme, Geist Mono axes, gradient fills
- **`CommandPalette`** — ⌘K/Ctrl+K, Raycast-style, always mounted globally, "Ask AI: [query]" appears when search >3 chars
- **`AgentChat`** — SSE streaming display with shimmer cursor, collapsible tool call reasoning panel, citation chips

### Motion
- Spring physics: `stiffness: 400–500, damping: 30–35`
- Page transitions: `opacity 0→1, y 8→0, duration 150ms`
- Stage pipeline connectors: `backgroundColor` transition 400ms
- Framer Motion `layoutId` for sidebar active state and tab indicators

---

## 17. Data Model Summary

### PostgreSQL (operational)
19 tables. Key relationships:

```
organizations
  ├── users (role, entra_oid, entra_group_ids)
  ├── business_units
  ├── functions
  ├── entra_group_mappings (group_id → bu or function)
  └── ai_projects
        ├── project_milestones
        ├── project_risks
        ├── project_issues
        ├── project_history_snapshots
        ├── jira_ticket_cache
        └── adoption_kpis (metadata only)

users
  └── ai_conversations
        └── ai_messages (role, content, tool_calls_json, citations_json)

audit_events (append-only — all mutations logged)
```

### BigQuery (analytics)
2 tables:
- `adoption_kpi_values` — partitioned by `ts` (DAY), clustered by `kpi_id`. All time-series values.
- `project_history_snapshots` — partitioned by `snapshot_date`. Daily project state.

See `docs/data-model.md` for full column definitions and ERD.

---

## 18. Extending PulseBoard

### Adding a new AI tool to the agent

1. Add a method to `AgentTools` in `apps/api/pulseboard/agent/tools.py`
2. Add an entry to `TOOL_REGISTRY` mapping the Gemini function name → `(handler_name, input_schema)`
3. The orchestrator picks it up automatically on next deploy

### Adding a new LLM provider

The orchestrator in `orchestrator.py` is abstracted with `_run_gemini()` and `_run_gemma_fallback()`. Add a new `_run_<provider>()` async generator method and route to it based on `settings.llm_provider`. See ADR `docs/adr/0001-llm-provider.md`.

### Adding a new Entra group mapping type

Currently maps groups to BUs or Functions. To add a new scope type (e.g., project-level access), add a column to `entra_group_mappings` and update `RBACContext.from_user()` in `auth/rbac.py`.

### Adding a new KPI ingestion mode

1. Add the mode to `IngestionMode` enum in schemas
2. Add handling in `tasks/kpi_pipeline.py`
3. Add a configuration UI step in `app/onboarding/kpi/page.tsx`

### Wiring up the digest email

The digest body is built in `tasks/digest.py`. Replace the `# TODO: send email` comment with your provider SDK call (SendGrid, AWS SES, etc.).

---

## 19. Security Notes

- **No passwords stored** — Entra owns all credentials
- **JWT validation** is stateless (JWKS-based) — scales horizontally without session state
- **RBAC at SQL level** — not just UI gating; `accessible_bu_ids` filter is injected into every project query
- **KPI ingest tokens** are SHA-256 hashed before storage — the plaintext is shown once and never stored
- **Secrets** are in GCP Secret Manager, injected at runtime — never baked into Docker images
- **Audit log** (`audit_events`) is append-only — no UPDATE or DELETE paths exist in the application code
- **Rate limiting** on `/agent/chat`: 10 RPM per user (sliding window, per-instance in-memory — acceptable with Cloud Run min=1)
- **VPC isolation**: Cloud SQL and Redis are not internet-accessible — all Cloud Run → data store traffic goes through the VPC connector
- **Entra client secret** expires every 24 months — set a calendar reminder and use Secret Manager versioning for zero-downtime rotation

---

## 20. Costs

### Small organisation (~50 projects, 100 KPIs, 20 users)
~**$162/month** USD

### Large organisation (~500 projects, 1000 KPIs, 200 users)
~**$712/month** USD

Main cost drivers at scale: Cloud SQL tier upgrade, Gemini API calls (est. ~$0.075/1M tokens Flash, ~$1.25/1M tokens Pro), Cloud Run instance count.

Enable GCP Billing budgets and alerts immediately after deployment. All cost estimates are in USD and vary with query complexity and volume.

See `docs/deploy-gcp.md` for a full per-service cost breakdown and scaling guidance.
