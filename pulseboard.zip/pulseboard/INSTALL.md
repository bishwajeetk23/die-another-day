# PulseBoard — Installation & Testing Guide

## System Requirements

| Tool | Minimum Version | Install |
|---|---|---|
| Docker Desktop | 24+ | https://www.docker.com/products/docker-desktop |
| Node.js | 20+ | https://nodejs.org |
| Python | 3.12+ | https://www.python.org |
| Git | any | https://git-scm.com |
| `gcloud` CLI | 450+ | https://cloud.google.com/sdk/docs/install |
| Terraform | 1.5+ | https://developer.hashicorp.com/terraform/install |

GCP deployment also requires a GCP project with Owner or Editor role, and a registered Microsoft Entra ID application.

---

## Option A — Local Development (No Cloud Required)

This runs the full stack on your laptop using Docker. No GCP account or Entra setup needed.

### Step 1 — Clone / Open the project

```bash
cd "/path/to/pulseboard"
```

### Step 2 — Configure environment

Copy the example environment file:

```bash
cp .env.example .env
```

The defaults in `.env.example` work out of the box for local Docker Compose. The only value you may want to change is `SECRET_KEY` — replace it with any random string.

### Step 3 — Start all services

```bash
docker compose up --build
```

This starts:
- **PostgreSQL 15** on port 5432
- **Redis** on port 6379
- **PulseBoard API** (FastAPI) on port 8000
- **PulseBoard Web** (Next.js) on port 3000
- **Celery Worker** (background jobs)

First build takes 3–5 minutes. Subsequent starts take ~15 seconds.

### Step 4 — Run database migrations

In a new terminal tab:

```bash
docker compose exec api alembic upgrade head
```

### Step 5 — Seed demo data (optional but recommended)

```bash
docker compose exec api python /app/scripts/seed.py
```

This loads:
- 40 AI projects across 5 Business Units and 8 Functions
- 25 realistic users with roles
- 90 days of synthetic KPI time-series data
- Project history snapshots, risks, and milestones

### Step 6 — Open the application

- **Frontend:** http://localhost:3000
- **API docs (Swagger):** http://localhost:8000/docs
- **API health:** http://localhost:8000/health

> **Note on authentication:** In local mode (`ENVIRONMENT=development`), Entra SSO is bypassed. A development user with Admin role is auto-injected. To test real Entra auth locally, set `ENTRA_TENANT_ID`, `ENTRA_CLIENT_ID`, and `ENTRA_AUDIENCE` in your `.env` file and add `http://localhost:3000/auth/callback` as a redirect URI in your Entra app registration.

### Step 7 — Stop the stack

```bash
docker compose down          # stops containers, keeps data
docker compose down -v       # stops containers and deletes volumes (fresh start)
```

---

## Option B — GCP Production Deployment

### Prerequisites

1. **GCP Project** with billing enabled
2. **Microsoft Entra ID** app registration (see `docs/entra-setup.md`)
3. `gcloud` CLI authenticated: `gcloud auth login && gcloud auth application-default login`

### Step 1 — Set environment variables

```bash
export PROJECT_ID=your-gcp-project-id
export REGION=asia-south1        # or us-central1, europe-west1
export ENTRA_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
export ENTRA_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
export ENTRA_CLIENT_SECRET=your-client-secret-value
```

### Step 2 — Deploy

```bash
# Standard deployment
./scripts/deploy-gcp.sh

# With demo data (recommended for first deployment)
./scripts/deploy-gcp.sh --demo
```

The script:
1. Enables 12 required GCP APIs
2. Provisions infrastructure via Terraform (~10 min)
3. Builds and pushes 3 Docker images via Cloud Build
4. Deploys 3 Cloud Run services
5. Runs Alembic database migrations
6. (With `--demo`) Seeds 40 projects and 90 days of KPI data
7. Prints the Web URL and API URL

**Estimated time:** 15–20 minutes on a fresh GCP project.

### Step 3 — Post-deployment: Add Redirect URI

1. Copy the **Web URL** printed at deployment end
2. Go to [Azure Portal](https://portal.azure.com) → Entra ID → App registrations → PulseBoard
3. Authentication → Add `<WEB_URL>/auth/callback` as a Redirect URI
4. Save

### Step 4 — First login

Open the Web URL, click **Sign in with Microsoft**, complete MFA. The first user to sign in is automatically granted Admin.

### Tear down (removes all GCP resources and data)

```bash
cd infra/terraform
terraform destroy \
  -var="project_id=${PROJECT_ID}" \
  -var="region=${REGION}" \
  -var="entra_tenant_id=${ENTRA_TENANT_ID}" \
  -var="entra_client_id=${ENTRA_CLIENT_ID}" \
  -var="entra_client_secret=${ENTRA_CLIENT_SECRET}"
```

---

## Running the Automated Test Suite

### Backend tests (Python)

```bash
cd apps/api

# Install dependencies
pip install uv
uv pip install --system -r requirements.txt
uv pip install --system pytest pytest-asyncio httpx aiosqlite

# Run all tests
python -m pytest tests/ -v

# Run specific test files
python -m pytest tests/test_projects.py -v    # Project CRUD and business logic
python -m pytest tests/test_adoption.py -v   # KPI ingestion and retrieval
python -m pytest tests/test_auth.py -v       # Authentication and RBAC

# Run agent evaluation suite (32 eval cases, no LLM required)
python -m pytest tests/agent_evals.py -v

# Print eval summary report
python tests/agent_evals.py
```

Tests use **in-memory SQLite** — no running database needed. Auth is mocked. All tests should pass on a clean install with no environment variables set.

### Frontend type-checking and build

```bash
cd apps/web
npm install

# TypeScript type check (fast — no build output)
npx tsc --noEmit

# Full production build (catches rendering errors)
npm run build
```

### Manual API testing

With the stack running locally:

```bash
# Health check
curl http://localhost:8000/health

# List projects (dev mode — no auth token needed)
curl http://localhost:8000/projects | python -m json.tool

# Filter by RAG status
curl "http://localhost:8000/projects?rag=red" | python -m json.tool

# Filter by lifecycle stage
curl "http://localhost:8000/projects?stage=production" | python -m json.tool

# KPI starter library
curl http://localhost:8000/adoption/kpis/starter-library | python -m json.tool

# Push a KPI data point (replace kpi-id and token)
curl -X POST "http://localhost:8000/adoption/kpis/{kpi-id}/ingest" \
  -H "Authorization: Bearer pb_kpi_xxxx" \
  -H "Content-Type: application/json" \
  -d '{"ts": "2025-01-01T09:00:00Z", "value": 4287, "dimensions": {"region": "APAC"}}'
```

Full interactive API documentation is available at `http://localhost:8000/docs` (Swagger UI).

---

## Testing the AI Agent

The AI assistant is at http://localhost:3000 (the default home page after sign-in).

**Sample questions to try:**

| Question | Tests |
|---|---|
| "Give me a summary of our AI portfolio" | Portfolio overview, tool calling |
| "Which projects are at risk of missing their go-live date?" | Schedule variance query |
| "Show me the weekly active user trend for the HR Policy Bot over the last 60 days" | Adoption metric + inline chart |
| "Which production AI project has the highest CSAT score?" | Cross-project comparison |
| "Are there any signs of model drift in our production systems?" | Drift detection tool |
| "Which AI projects have delivered the most business value?" | Value realization tool |
| "What are the highest-impact open risks?" | Risk register query |
| "Give me a governance summary of Tier 1 model risk projects" | Governance tool |

> **Without GCP/Vertex AI configured:** The agent returns a mock response explaining it's in development mode. To enable real Gemini responses, set `VERTEX_AI_PROJECT` and `VERTEX_AI_LOCATION` in your `.env` file and ensure your machine has Application Default Credentials (`gcloud auth application-default login`).

---

## Common Issues

### `docker compose up` fails with port conflict

```bash
# Find what's using port 8000 or 3000
lsof -i :8000
lsof -i :3000
# Kill the process or change ports in docker-compose.yml
```

### Migrations fail: "relation does not exist"

The API started before Postgres was ready. Run migrations manually:
```bash
docker compose exec api alembic upgrade head
```

### Seed script fails with "org already exists"

The database already has data. Either drop and recreate:
```bash
docker compose down -v && docker compose up -d
docker compose exec api alembic upgrade head
docker compose exec api python /app/scripts/seed.py
```

### Frontend shows blank page / auth error

In local mode, ensure `NEXT_PUBLIC_API_URL=http://localhost:8000` is set in `apps/web/.env.local`.

### GCP deployment fails at Terraform step

Ensure all required APIs are enabled:
```bash
gcloud services enable run.googleapis.com sql-component.googleapis.com \
  sqladmin.googleapis.com redis.googleapis.com bigquery.googleapis.com \
  storage.googleapis.com secretmanager.googleapis.com \
  aiplatform.googleapis.com cloudbuild.googleapis.com \
  artifactregistry.googleapis.com servicenetworking.googleapis.com \
  cloudtasks.googleapis.com vpcaccess.googleapis.com \
  --project=$PROJECT_ID
```

### Agent returns "mock response" on GCP

Set `VERTEX_AI_PROJECT` environment variable on the Cloud Run API service:
```bash
gcloud run services update pulseboard-api \
  --set-env-vars="VERTEX_AI_PROJECT=${PROJECT_ID}" \
  --region="${REGION}"
```
